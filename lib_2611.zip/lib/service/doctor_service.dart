import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../domain/doctor.dart';

class DoctorService {
  static const _fetchDoctorsEndpoint = 'http://18.190.132.79:9092/api/doctors';
  static final _headers = {'Content-Type': 'application/json'};

  Future<List<Doctor>> fetchDoctors() async {
    try {
      // final response =
      //     await http.post(_fetchDoctorsEndpoint, headers: _headers);
      // List<Doctor> doctorsResponse = _fromJson(response.body);

      String json =
          '{\r\n  \"response\": {\r\n    \"ListDoctorsResponse\": {\r\n      \"doctors\": [\r\n        {\r\n          \"fullName\": \"Meda Adams\",\r\n          \"gender\": \"female\",\r\n          \"speciality\": \"et\",\r\n          \"active\": 1,\r\n          \"createdOn\": \"2019-09-29 20:04:35.0\",\r\n          \"modifiedOn\": \"2019-09-11 16:01:55.0\"\r\n        },\r\n        {\r\n          \"fullName\": \"Nicholas Rutherford\",\r\n          \"gender\": \"male\",\r\n          \"speciality\": \"est\",\r\n          \"active\": 1,\r\n          \"createdOn\": \"2019-10-02 14:56:56.0\",\r\n          \"modifiedOn\": \"2019-09-30 18:31:14.0\"\r\n        }\r\n      ]\r\n    }\r\n  },\r\n  \"apiResponseError\": null\r\n}';

      List<Doctor> doctorsResponse = _fromJson(json);
      return doctorsResponse;
    } catch (e) {
      print('Server Exception');
      print(e);
      return null;
    }
  }

  Doctor _fromJsonMap(Map<String, dynamic> map) {
    String fullName = map['fullName'];
    String gender = map['gender'];
    String speciality = map['speciality'];
    String active = map['active'].toString();

    Doctor doctor = Doctor();
    doctor.fullName = fullName;
    doctor.gender = gender;
    doctor.speciality = speciality;
    doctor.active = active;
    return doctor;
  }

  List<Doctor> _fromJson(String json) {
    Map<String, dynamic> map = jsonDecode(json);
    List<dynamic> doctorsDynamic =
        map['response']['ListDoctorsResponse']['doctors'];
    List<Doctor> doctors = List<Doctor>();
    doctorsDynamic.forEach((doc) {
      Doctor doctor = _fromJsonMap(doc);
      doctors.add(doctor);
    });
    return doctors;
  }
}
