import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

import '../domain/patient_registration.dart';

class PatientRegistrationService {
  static const _patientRegistration =
      'http://18.190.132.79:9092/api/register-patient';
  static final _headers = {'Content-Type': 'application/json'};

  Future<PatientRegistration> createPatientRegistration(
      PatientRegistration patientRegistration) async {
    try {
      String _json = _toJson(patientRegistration);
      final response =
          await http.post(_patientRegistration, headers: _headers, body: _json);
      var patientRegistrationResponse = _fromJson(response.body);
      return patientRegistrationResponse;
    } catch (e) {
      print('Server Exception');
      print(e);
      return null;
    }
  }

  PatientRegistration _fromJson(String json) {
    Map<String, dynamic> map = jsonDecode(json);

    var patientRegistration = PatientRegistration();
    patientRegistration.medicalRecordNumber = map['response']
        ['RegisterPatientResponse']['patientRegistrationDTO']['mrn'];
    print(patientRegistration.medicalRecordNumber);
    return patientRegistration;
  }

  String _toJson(PatientRegistration patientRegistration) {
    var mapData = Map();
    mapData['firstName'] = patientRegistration.firstName;
    mapData['lastName'] = patientRegistration.lastName;
    mapData['gender'] = patientRegistration.gender;
    mapData['dateOfBirth'] =
        DateFormat.yMd().format(patientRegistration.dateofBirth);
    mapData['maritalStatus'] = patientRegistration.maritalStatus;
    mapData['idProofType'] = patientRegistration.idProofType;
    mapData['idProofNumber'] = patientRegistration.idProofNumber;
    mapData['mobileNumber'] = patientRegistration.mobile;
    mapData['address'] = patientRegistration.address;
    mapData['pinCode'] = patientRegistration.pinCode;

    String json = jsonEncode(mapData);

    return json;
  }
}
