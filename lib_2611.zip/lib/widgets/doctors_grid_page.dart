import 'package:care_record_app/widgets/doctor_entry_page.dart';
import 'package:flutter/material.dart';
import '../service/doctor_service.dart';
import '../domain/doctor.dart';

GlobalKey<ScaffoldState> _scaffoldState = GlobalKey<ScaffoldState>();

class DoctorsDataGridPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldState,
      appBar: AppBar(
        title: Text('Doctors Data Grid'),
        actions: <Widget>[
          GestureDetector(
            onTap: () {
              Navigator.push(_scaffoldState.currentContext,
                  MaterialPageRoute(builder: (BuildContext context) {
                return DoctorEntryPage();
              }));
            },
            child: Padding(
                padding: const EdgeInsets.only(right: 16.0),
                child: Icon(
                  Icons.add,
                  color: Colors.white,
                )),
          )
        ],
      ),
      body: _DoctorsDataWidget(),
    );
  }
}

class _DoctorsDataWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _DoctorDataState();
  }
}

class _DoctorDataState extends State<_DoctorsDataWidget> {
  DoctorService _doctorService;
  @override
  void initState() {
    super.initState();
    _doctorService = DoctorService();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FutureBuilder(
          future: _doctorService.fetchDoctors(),
          builder:
              (BuildContext context, AsyncSnapshot<List<Doctor>> snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('Something went wrong!'));
            } else if (snapshot.connectionState == ConnectionState.done) {
              List<Doctor> doctors = snapshot.data;
              return _buildListView(doctors);
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          }),
    );
  }

  Widget _buildListView(List<Doctor> doctors) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: ListView.builder(
        itemBuilder: (context, index) {
          Doctor doctor = doctors[index];
          return Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Card(
              elevation: 8,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      doctor.fullName,
                      style: Theme.of(context).textTheme.title,
                    ),
                    Text(doctor.speciality),
                    Text(doctor.gender),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        FlatButton(
                          onPressed: () {},
                          child: Text(
                            "Delete",
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                        FlatButton(
                          onPressed: () {},
                          child: Text(
                            'Edit',
                            style: TextStyle(color: Colors.blue),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        },
        itemCount: doctors.length,
      ),
    );
  }
}
