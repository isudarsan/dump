import 'package:flutter/material.dart';
import '../widgets/admin_dashboard_page.dart';
import '../domain/login.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _LoginWidget();
  }
}

class _LoginWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _LoginWidgetState();
  }
}

class _LoginWidgetState extends State<_LoginWidget> {
  final GlobalKey<FormState> _loginFormKey = new GlobalKey<FormState>();
  Login _login = Login();

  void _submitLogin() {
    final FormState _loginForm = _loginFormKey.currentState;
    _loginForm.save();
    print(_login.userName);
    print(_login.password);

    if (_login.userName.length == 0 || _login.userName == null) {
      return;
    }

    if (_login.password.length == 0 || _login.password == null) {
      return;
    }

    if ("admin" == _login.userName && "admin" == _login.password) {
      print('login Success');
      _navigateToAdminDashBoard(context);
    } else {
      print('Invalid Login');
      _showErrorDialog();
    }
  }

  Future _navigateToAdminDashBoard(context) async {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => AdminDashBoardPage()));
  }

  void _showErrorDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Authentication Failure', style: TextStyle(color: Colors.red),),
            content: Text('Invalid User ID / Password.'),
            actions: <Widget>[
              FlatButton(
                child: Text('Close'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Form(
          autovalidate: true,
          key: _loginFormKey,
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: <Widget>[
                TextFormField(
                  decoration: InputDecoration(
                      labelText: 'User ID',
                      hintText: 'Enter User ID',
                      icon: Icon(Icons.person)),
                  validator: (val) =>
                      val.isEmpty ? 'User ID is required' : null,
                  onSaved: (val) {
                    setState(() {
                      _login.userName = val;
                    });
                  },
                ),
                TextFormField(
                  obscureText: true,
                  decoration: InputDecoration(
                      labelText: 'Password',
                      hintText: 'Enter Password',
                      icon: Icon(Icons.security)),
                  validator: (val) =>
                      val.isEmpty ? 'Password is required' : null,
                  onSaved: (val) {
                    setState(() {
                      _login.password = val;
                    });
                  },
                ),
                Container(
                  padding: const EdgeInsets.only(left: 40.0, top: 20.0),
                  child: RaisedButton(
                    color: Colors.blue,
                    child: Text(
                      'Login',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      _submitLogin();
                    },
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
