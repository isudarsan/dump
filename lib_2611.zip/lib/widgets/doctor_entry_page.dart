import 'package:flutter/material.dart';
import '../domain/doctor.dart';

class DoctorEntryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Doctor'),
      ),
      body: _DoctorEntryWidget(),
    );
  }
}

class _DoctorEntryWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _DoctorEntryWidgetState();
  }
}

class _DoctorEntryWidgetState extends State<_DoctorEntryWidget> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Add Doctor here'),
    );
  }
}
