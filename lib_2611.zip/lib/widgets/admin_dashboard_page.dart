import 'package:flutter/material.dart';
import '../widgets/patient_registartion_page.dart';
import '../service/doctor_service.dart';
import '../widgets/doctors_grid_page.dart';

class AdminDashBoardPage extends StatelessWidget {
  Future navigateToPatientRegistrationPage(context) async {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => PatientRegistrationPage()));
  }

  Future navigateToDoctorsDataGridPage(context) async {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => DoctorsDataGridPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            RaisedButton(
              child: Text('List Doctors'),
              onPressed: () {
                navigateToDoctorsDataGridPage(context);
              },
            ),
            Container(
              child: RaisedButton(
                color: Colors.blue,
                child: Text(
                  'Patient Registration',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  navigateToPatientRegistrationPage(context);
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
