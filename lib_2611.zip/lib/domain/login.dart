class Login {
  String userName;
  String password;
  Login();
}
