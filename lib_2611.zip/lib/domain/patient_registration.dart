class PatientRegistration {
  String firstName;
  String lastName;
  String gender;
  DateTime dateofBirth;
  String mobile;
  String idProofType;
  String idProofNumber;
  String maritalStatus;
  String pinCode;
  String address;
  String medicalRecordNumber;

  PatientRegistration();
}