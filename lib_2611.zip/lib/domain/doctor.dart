class Doctor {
  String fullName;
  String speciality;
  String gender;
  String active;

  Doctor();
}
