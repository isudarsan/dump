package com.nissan.danswer.batchtest;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.runtime.StatefulKnowledgeSession;

import test.DealerAllocationTest;
import test.StockCoverTest;

import com.nissan.danswer.helper.HelperConstants;
import com.nissan.danswer.helper.KnowledgeService;
import com.nissan.danswer.model.dealerallocation.DealerAllocationResultList;
import com.nissan.danswer.model.dealerallocation.DealerList;
import com.nissan.danswer.model.dealerallocation.EndItemList;
import com.nissan.danswer.model.stockcover.InOrderList;
import com.nissan.danswer.model.stockcover.OCFDailyList;
import com.nissan.danswer.model.stockcover.OutOrderList;
import com.nissan.danswer.model.stockcover.SpecOCFList;

public class StockCoverPerformanceTest {

    // ------- data for Stock Cover ------- //
    // changeset.xml
    public final static String CS_NAME = "cs_stockCover.xml";
    // ãƒ†ã‚¹ãƒˆãƒ‡ãƒ¼ã‚¿æ ¼ç´�å ´æ‰€
    public final static String DATAPATH = "../d-answer-testdata/data/stockcover";
    // flowID
    public final static String FLOW_ID = "com.nissan.danswer.flow.stockcover";
    // ãƒ¡ã‚½ãƒƒãƒ‰å��
    public final static String TEST_METHOD = "stockcover";

    // knowledge service
    private static KnowledgeService kservice;
    // knowledgeBase
    private static KnowledgeBase kbase;
    // knowledge session
    private static StatefulKnowledgeSession ksession;
    // logger
    private static KnowledgeRuntimeLogger logger = null;

    // test method invoke
    public static void main(String[] args) throws Exception {

//        // ã‚½ãƒ¼ã‚¹èª­ã�¿è¾¼ã�¿
//        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
//        kbuilder.add(ResourceFactory.newClassPathResource("InventoryAlloc.drl"), ResourceType.DRL);
//        kbuilder.add(ResourceFactory.newClassPathResource("InventoryAlloc.rf"), ResourceType.DRF);
//        kbase = KnowledgeBaseFactory.newKnowledgeBase();
//        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

        // ãƒ‘ãƒƒã‚±ãƒ¼ã‚¸èª­ã�¿è¾¼ã�¿
        kservice = new KnowledgeService();
        kbase = kservice.getKnowledgeBase(CS_NAME);

        ksession = kbase.newStatefulKnowledgeSession();
        StockCoverPerformanceTest test = new StockCoverPerformanceTest();
//      logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/" + TEST_METHOD);
        test.getClass().getDeclaredMethod(TEST_METHOD).invoke(null);

        if (logger != null) logger.close();
        ksession.dispose();
        if (kservice != null) kservice.destroy();
    }

    /**
     * åœ¨åº«è£œå¡«
     * 
     * @throws Exception
     */
    public static void stockcover() throws Exception {
        // input Fact list
//        final String testcase = "test99";
//        final String testcase = "test98";
//        final String testcase = "test97"; // E/I = 138
//        final String testcase = "test96"; // E/I = 56
//        final String testcase = "test93"; // OCF.MAX = 1
//        final String testcase = "test92"; // OCF.MAX = 25
//        final String testcase = "test91"; // OCF.MAX = 50
        final String testcase = "test90"; // OCF.MAX = 100

        InOrderList orderList = StockCoverTest.readCSV_EI_ALLOC(DATAPATH + "/" + testcase + "/order.csv");
        SpecOCFList specList = StockCoverTest.readCSV_SPEC_OCF(DATAPATH + "/" + testcase + "/spec_ocf.csv");
        OCFDailyList ocfList = StockCoverTest.readCSV_OCF_DAILY(DATAPATH + "/" + testcase + "/ocf.csv");
        OutOrderList result = new OutOrderList();
        
        ksession.insert(orderList);
        ksession.insert(specList);
        ksession.insert(ocfList);
        ksession.insert(result);
        
        ksession.startProcess(FLOW_ID);
        Date startDate = new Date();
        // fire
        int fireCnt = ksession.fireAllRules();

        Date endDate = new Date();
        System.out.println("====> run end");

        // system out
        sysOut(startDate, endDate, fireCnt,
                HelperConstants.FIRE_LIMIT_STOCK_COVER);
    }

    /**
     * å…±é€šãƒ­ã‚°ï¼ˆå‡¦ç�†å¾Œï¼‰
     * 
     * @param startDate
     * @param endDate
     * @param fireCnt
     * @param maxCnt
     */
    private static void sysOut(Date startDate, Date endDate, int fireCnt,
            int maxCnt) {

        BigDecimal bdTime = new BigDecimal(endDate.getTime()
                - startDate.getTime());

        System.out.println("start : " + startDate);
        System.out.println("end   : " + endDate);
        System.out.println("time  : "
                        + bdTime.divide(new BigDecimal(1000.0), 2,
                                RoundingMode.HALF_UP) + "s");
        System.out.println("fireCnt : " + fireCnt);

        if (fireCnt >= maxCnt) {
            System.out.println("WARNING! rule loops");
        }
    }
}
