package com.nissan.danswer.batchtest;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.runtime.StatefulKnowledgeSession;

import test.DealerAllocationTest;

import com.nissan.danswer.helper.HelperConstants;
import com.nissan.danswer.helper.KnowledgeService;
import com.nissan.danswer.model.dealerallocation.DealerAllocationResultList;
import com.nissan.danswer.model.dealerallocation.DealerList;
import com.nissan.danswer.model.dealerallocation.EndItemList;

public class DealerAllocationPerformanceTest {

    // ------- data for ColorBreakdownImport ------- //
    // changeset.xml
    public static String CS_NAME = "cs_dealerAllocation.xml";
    // テストデータ格納場所
    public static String DATAPATH = "../d-answer-testdata/data/dealerallocation";
    // flowID
    public static String FLOW_ID = "com.nissan.danswer.flow.dealerallocation";
    // メソッド名
    public static String TEST_METHOD = "allocate";

    // knowledge service
    private static KnowledgeService kservice;
    // knowledgeBase
    private static KnowledgeBase kbase;
    // knowledge session
    private static StatefulKnowledgeSession ksession;
    // logger
    private static KnowledgeRuntimeLogger logger = null;

    // test method invoke
    public static void main(String[] args) throws Exception {

//        // ソース読み込み
//        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
//        kbuilder.add(ResourceFactory.newClassPathResource("InventoryAlloc.drl"), ResourceType.DRL);
//        kbuilder.add(ResourceFactory.newClassPathResource("InventoryAlloc.rf"), ResourceType.DRF);
//        kbase = KnowledgeBaseFactory.newKnowledgeBase();
//        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

        // パッケージ読み込み
        kservice = new KnowledgeService();
        kbase = kservice.getKnowledgeBase(CS_NAME);

        ksession = kbase.newStatefulKnowledgeSession();
        DealerAllocationPerformanceTest test = new DealerAllocationPerformanceTest();
//      logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/" + TEST_METHOD);
        test.getClass().getDeclaredMethod(TEST_METHOD).invoke(null);

        if (logger != null) logger.close();
        ksession.dispose();
        if (kservice != null) kservice.destroy();
    }

    /**
     * 在庫引当
     * 
     * @throws Exception
     */
    public static void allocate() throws Exception {
        // input Fact list
//        final String testcase = "test99";
        final String testcase = "test98";
//        final String testcase = "test97";
//        final String testcase = "test96";

        DealerAllocationTest dt = new DealerAllocationTest();
        EndItemList eiList = dt.makeEndItemList(DATAPATH + "/" + testcase + "/enditem.csv");
        DealerList dealerList = dt.makeDealerList(DATAPATH + "/" + testcase + "/dealer.csv");
        
        ksession.insert(eiList);
        ksession.insert(dealerList);
        ksession.insert(new DealerAllocationResultList());
        
        ksession.startProcess(FLOW_ID);
        Date startDate = new Date();
        // fire
        int fireCnt = ksession.fireAllRules();

        Date endDate = new Date();
        System.out.println("====> run end");

        // system out
        sysOut(startDate, endDate, fireCnt,
                HelperConstants.FIRE_LIMIT_INVENTORY_ALLOCATION);
    }

    /**
     * 共通ログ（処理後）
     * 
     * @param startDate
     * @param endDate
     * @param fireCnt
     * @param maxCnt
     */
    private static void sysOut(Date startDate, Date endDate, int fireCnt,
            int maxCnt) {

        BigDecimal bdTime = new BigDecimal(endDate.getTime()
                - startDate.getTime());

        System.out.println("start : " + startDate);
        System.out.println("end   : " + endDate);
        System.out.println("time  : "
                        + bdTime.divide(new BigDecimal(1000.0), 2,
                                RoundingMode.HALF_UP) + "s");
        System.out.println("fireCnt : " + fireCnt);

        if (fireCnt >= maxCnt) {
            System.out.println("WARNING! rule loops");
        }
    }
}
