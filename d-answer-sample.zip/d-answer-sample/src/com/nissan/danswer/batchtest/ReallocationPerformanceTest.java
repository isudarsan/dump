package com.nissan.danswer.batchtest;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.runtime.StatefulKnowledgeSession;

import test.ReAllocationTest;

import com.nissan.danswer.helper.HelperConstants;
import com.nissan.danswer.helper.KnowledgeService;
import com.nissan.danswer.model.reallocation.FactoryLine;
import com.nissan.danswer.model.reallocation.FactoryLineList;

public class ReallocationPerformanceTest {

    /* テストをしたいルールごとに、以下の値を適宜変えて実行する */

    // ------- data for ColorBreakdownImport ------- //
    // changeset.xml
    public static String CS_NAME = "./cs_reAllocation.xml";
    // テストデータ格納場所
    public static String DATAPATH = "../d-answer-testdata/data/endItemRealloc";
    // flowID
    public static String FLOW_ID = "com.nissan.danswer.flow.reallocation";
    // メソッド名
    public static String TEST_METHOD = "reallocate";

    // knowledge service
    private static KnowledgeService kservice;
    // knowledgeBase
    private static KnowledgeBase kbase;
    // knowledge session
    private static StatefulKnowledgeSession ksession;
    // logger
    private static KnowledgeRuntimeLogger logger = null;

    // test method invoke
    public static void main(String[] args) throws Exception {

        // パッケージ読み込み
        kservice = new KnowledgeService();
        kbase = kservice.getKnowledgeBase(CS_NAME);

        // パッケージ読み込みでは、エラーが出て実行ができなくて、とりあえず↓で実行しています。
        // ソース読み込み
//        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
//        kbuilder.add(ResourceFactory.newClassPathResource("ReAllocation.drl"), ResourceType.DRL);
//        kbuilder.add(ResourceFactory.newClassPathResource("ReAllocation.rf"), ResourceType.DRF);
//        kbase = KnowledgeBaseFactory.newKnowledgeBase();
//        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

        ksession = kbase.newStatefulKnowledgeSession();
//      logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/" + TEST_METHOD);
        ReallocationPerformanceTest test = new ReallocationPerformanceTest();

        test.getClass().getDeclaredMethod(TEST_METHOD).invoke(null);

        if (logger != null) {
            logger.close();
        }
        ksession.dispose();
        kservice.destroy();
    }

    /**
     * 再引当
     * 
     * @throws Exception
     */
    public static void reallocate() throws Exception {
        // input Fact list
//        final String testcase = "TestCasePF4";
//        final String testcase = "TestCasePF5";
        final String testcase = "TestCasePF6";
//        final String testcase = "TestCasePF7";
        com.nissan.danswer.model.reallocation.EndItemReAllocList eiList = ReAllocationTest.readCSV_EI_ALLOC(DATAPATH + "/" + testcase + "/order.csv");
        com.nissan.danswer.model.reallocation.SpecOCFList specList = ReAllocationTest.readCSV_SPEC_OCF(DATAPATH + "/" + testcase + "/spec_ocf.csv");
        com.nissan.danswer.model.reallocation.OCFDailyList ocfList = ReAllocationTest.readCSV_OCF_DAILY(DATAPATH + "/" + testcase + "/ocf.csv");

        com.nissan.danswer.model.reallocation.FactoryLineList flList = makeFactoryLineSortList();

        ksession.insert(eiList);    // IN/OUT
        ksession.insert(specList);  // IN
        ksession.insert(flList);    // IN/OUT
        ksession.insert(ocfList);   // IN

        ksession.startProcess(FLOW_ID);
        Date startDate = new Date();
        // fire
        int fireCnt = ksession.fireAllRules();

        Date endDate = new Date();
        System.out.println("====> run end");

        // system out
        sysOut(startDate, endDate, fireCnt,
                HelperConstants.FIRE_LIMIT_COLOR_BREAKDOWN_NATIONAL);
    }

    /**
     * 共通ログ（処理後）
     * 
     * @param startDate
     * @param endDate
     * @param fireCnt
     * @param maxCnt
     */
    private static void sysOut(Date startDate, Date endDate, int fireCnt,
            int maxCnt) {

        BigDecimal bdTime = new BigDecimal(endDate.getTime()
                - startDate.getTime());

        System.out.println("start : " + startDate);
        System.out.println("end   : " + endDate);
        System.out
                .println("time  : "
                        + bdTime.divide(new BigDecimal(1000.0), 2,
                                RoundingMode.HALF_UP) + "s");
        System.out.println("fireCnt : " + fireCnt);

        if (fireCnt >= maxCnt) {
            System.out.println("WARNING! rule loops");
        }

    }
    
    // 生産未確定車引当て用工場/ラインテーブル
    private static FactoryLineList makeFactoryLineSortList() {
        FactoryLineList l = new FactoryLineList();
        l.add(new FactoryLine("Factory#1", "lineA")); // A工場、Aライン
        l.add(new FactoryLine("Factory#1", "lineB")); // A工場、Bライン
        l.add(new FactoryLine("Factory#2", "lineA")); // B工場、Dライン
        l.add(new FactoryLine("Factory#2", "lineB")); // B工場、Eライン
        return l;
    }
}
