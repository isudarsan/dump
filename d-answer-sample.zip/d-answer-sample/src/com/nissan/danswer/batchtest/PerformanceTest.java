package com.nissan.danswer.batchtest;
import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.runtime.StatefulKnowledgeSession;

import test.ColorBreakdown_ImportTest;
import test.ColorBreakdown_NationalTest;
import test.EndItemBreakdownTest;
import test.OcfSlottingTest;
import test.ScheduleCheckTest;

import com.nissan.danswer.helper.HelperConstants;
import com.nissan.danswer.helper.KnowledgeService;
import com.nissan.danswer.model.DanswerConstant;
import com.nissan.danswer.model.colorbreakdown.ColorBreakdownResultList;
import com.nissan.danswer.model.colorbreakdown.ColorRatio;
import com.nissan.danswer.model.colorbreakdown.ColorRatioList;
import com.nissan.danswer.model.colorbreakdown.RecommendedOrder;
import com.nissan.danswer.model.colorbreakdown.RecommendedOrderList;
import com.nissan.danswer.model.eibreakdown.EndItemSlottingResultList;
import com.nissan.danswer.model.schedulecheck.MatchingResultList;
import com.nissan.danswer.model.schedulecheck.OrderOnlyList;
import com.nissan.danswer.model.schedulecheck.ScheduleOnlyList;

/**
 * PKG化したルールを呼び出して、パフォーマンス測定をするためのテスト<br>
 * ルール呼び出しからルール実行終了までの時間を計測
 * @author matsuda
 *
 */
public class PerformanceTest {

	/* テストをしたいルールごとに、以下の値を適宜変えて実行する */
	
	// ------- data for EndItemBreakdown -------- //
	// changeset.xml
//	public static String CS_NAME = "cs_endItemBreakdown.xml";
////	// テストデータ格納場所
//	public static String DATAPATH = "../d-answer-testdata/data/eibreakdown";
////	// flowID
//	public static String FLOW_ID = "com.nissan.danswer.flow.enditembreakdown";
////	// メソッド名
//	public static String TEST_METHOD = "endItemBreakdown";

	// ------- data for OCFSlotting -------- //
	// changeset.xml
//	public static String CS_NAME = "cs_ocfSlotting.xml";
//	// テストデータ格納場所
//	public static String DATAPATH = "../d-answer-testdata/data/ocfslotting";
//	// flowID
//	public static String FLOW_ID = "com.nissan.danswer.flow.ocfslotting";
//	// メソッド名
//	public static String TEST_METHOD = "ocfSlotting";
	
	// ------- data for SheduleCheck ------- //
	// changeset.xml
	public static String CS_NAME = "cs_scheduleCheck.xml";
	// テストデータ格納場所
	public static String DATAPATH = "../d-answer-testdata/data/schedulecheck";
	// flowID
	public static String FLOW_ID = "com.nissan.danswer.flow.schedulecheck";
	// メソッド名
	public static String TEST_METHOD = "scheduleCheck";
	
	// ------- data for ColorBreakdownImport ------- //
	// changeset.xml
//	public static String CS_NAME = "cs_colorBreakdownImport.xml";
//	// テストデータ格納場所
//	public static String DATAPATH = "../d-answer-testdata/data/colorbd_import";
//	// flowID
//	public static String FLOW_ID = "com.nissan.danswer.flow.colorbreakdownimport";
//	// メソッド名
//	public static String TEST_METHOD = "colorBdImport";
	
	// ------- data for ColorBreakdownNational ------- //
	// changeset.xml
//	public static String CS_NAME = "cs_colorBreakdownNational.xml";
//	// テストデータ格納場所
//	public static String DATAPATH = "../d-answer-testdata/data/colorbd_national";
//	// flowID
//	public static String FLOW_ID = "com.nissan.danswer.flow.colorbreakdownnational";
//	// メソッド名
//	public static String TEST_METHOD = "colorBdNational";
	
	// knowledge service
	private static KnowledgeService kservice;
	// knowledgeBase
	private static KnowledgeBase kbase;	
	// knowledge session
	private static StatefulKnowledgeSession ksession;
	// logger
	private static KnowledgeRuntimeLogger logger = null;
	
	// test method invoke
	public static void main(String[] args) throws Exception {
		
		try {
		kservice = new KnowledgeService();
		kbase = kservice.getKnowledgeBase(CS_NAME);
		ksession = kbase.newStatefulKnowledgeSession();

		//		logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/" + TEST_METHOD);
		
		PerformanceTest test = new PerformanceTest();
		
		test.getClass().getDeclaredMethod(TEST_METHOD).invoke(null);
		
//		TestAThread testA = test.new TestAThread();
//		TestBThread testB = test.new TestBThread();
//		
//		testA.start();
//		testB.start();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (logger != null) {
				logger.close();
			}
			if (ksession != null) {
				ksession.dispose();
			}
			if (kservice != null) {
				kservice.destroy();
			}
		}
		
		System.out.println("====> 1 end");
		
	}
	
//	class TestAThread extends Thread {
//
//		@Override
//		public void run() {
//			KnowledgeService kservice = new KnowledgeService();
//			KnowledgeBase kbase = kservice.getKnowledgeBase(CS_NAME);
//			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
//			
//			try {
//			EndItemBreakdownResultList bdList = OcfSlottingTest.makeEIBreakdownList(DATAPATH + "/performanceTest/breakdown_result.csv");
//			com.nissan.danswer.model.ocfslotting.MonthlyOCFList ocfList = OcfSlottingTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf.csv");
//			com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList specList = OcfSlottingTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");	
//			com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList slotList = new com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList();	
//			
//			ksession.insert(bdList);	// IN
//			ksession.insert(ocfList);	// IN/OUT
//			ksession.insert(specList);	// IN
//			ksession.insert(slotList);	// OUT
//			
//			ksession.startProcess(FLOW_ID);
//			Date startDate = new Date();
//			// fire
//			int fireCnt = ksession.fireAllRules();
//
//			Date endDate = new Date();
//			System.out.println("====> run end");
//			
//			// system out
//			sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_OCF_SLOTTING);
//			
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			ksession.dispose();
//			kservice.destroy();
//		}
//		
//	}
//	
//	class TestBThread extends Thread {
//
//		@Override
//		public void run() {
//			KnowledgeService kservice = new KnowledgeService();
//			KnowledgeBase kbase = kservice.getKnowledgeBase(CS_NAME);
//			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
//			
//			try {
//			EndItemBreakdownResultList bdList = OcfSlottingTest.makeEIBreakdownList(DATAPATH + "/performanceTest/breakdown_result.csv");
//			com.nissan.danswer.model.ocfslotting.MonthlyOCFList ocfList = OcfSlottingTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf.csv");
//			com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList specList = OcfSlottingTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");	
//			com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList slotList = new com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList();	
//			
//			ksession.insert(bdList);	// IN
//			ksession.insert(ocfList);	// IN/OUT
//			ksession.insert(specList);	// IN
//			ksession.insert(slotList);	// OUT
//			
//			ksession.startProcess(FLOW_ID);
//			Date startDate = new Date();
//			// fire
//			int fireCnt = ksession.fireAllRules();
//
//			Date endDate = new Date();
//			System.out.println("====> run end");
//			
//			// system out
//			sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_OCF_SLOTTING);
//			
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			ksession.dispose();
//			kservice.destroy();
//		}
//		
//		
//	}
	
	//	class TestAThread extends Thread {
	//
	//		@Override
	//		public void run() {
	//			KnowledgeService kservice = new KnowledgeService();
	//			KnowledgeBase kbase = kservice.getKnowledgeBase(CS_NAME);
	//			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
	//			
	//			try {
	//			EndItemBreakdownResultList bdList = OcfSlottingTest.makeEIBreakdownList(DATAPATH + "/performanceTest/breakdown_result.csv");
	//			com.nissan.danswer.model.ocfslotting.MonthlyOCFList ocfList = OcfSlottingTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf.csv");
	//			com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList specList = OcfSlottingTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");	
	//			com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList slotList = new com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList();	
	//			
	//			ksession.insert(bdList);	// IN
	//			ksession.insert(ocfList);	// IN/OUT
	//			ksession.insert(specList);	// IN
	//			ksession.insert(slotList);	// OUT
	//			
	//			ksession.startProcess(FLOW_ID);
	//			Date startDate = new Date();
	//			// fire
	//			int fireCnt = ksession.fireAllRules();
	//
	//			Date endDate = new Date();
	//			System.out.println("====> run end");
	//			
	//			// system out
	//			sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_OCF_SLOTTING);
	//			
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//			ksession.dispose();
	//			kservice.destroy();
	//		}
	//		
	//	}
	//	
	//	class TestBThread extends Thread {
	//
	//		@Override
	//		public void run() {
	//			KnowledgeService kservice = new KnowledgeService();
	//			KnowledgeBase kbase = kservice.getKnowledgeBase(CS_NAME);
	//			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
	//			
	//			try {
	//			EndItemBreakdownResultList bdList = OcfSlottingTest.makeEIBreakdownList(DATAPATH + "/performanceTest/breakdown_result.csv");
	//			com.nissan.danswer.model.ocfslotting.MonthlyOCFList ocfList = OcfSlottingTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf.csv");
	//			com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList specList = OcfSlottingTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");	
	//			com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList slotList = new com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList();	
	//			
	//			ksession.insert(bdList);	// IN
	//			ksession.insert(ocfList);	// IN/OUT
	//			ksession.insert(specList);	// IN
	//			ksession.insert(slotList);	// OUT
	//			
	//			ksession.startProcess(FLOW_ID);
	//			Date startDate = new Date();
	//			// fire
	//			int fireCnt = ksession.fireAllRules();
	//
	//			Date endDate = new Date();
	//			System.out.println("====> run end");
	//			
	//			// system out
	//			sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_OCF_SLOTTING);
	//			
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//			ksession.dispose();
	//			kservice.destroy();
	//		}
	//		
	//		
	//	}
		
	/**
	 * カラー配分（国内生産車）
	 * @throws Exception
	 */
	public static void colorBdNational() throws Exception {
		
		int dealerCnt = 250;
//		int dealerCnt = 100;
		
		// input Fact list
		com.nissan.danswer.model.colorbreakdown.ColorRatioList ratioList = makeColorRatioList(DATAPATH + "/performanceTest/coloratio.csv", dealerCnt);
		com.nissan.danswer.model.colorbreakdown.RecommendedOrderList recommendedList = makeRecommendedList(DATAPATH + "/performanceTest/recommended.csv", dealerCnt);
		com.nissan.danswer.model.colorbreakdown.MonthlySpecOCFList specList = ColorBreakdown_NationalTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");
		com.nissan.danswer.model.colorbreakdown.ColorBreakdownResultList resultList = new ColorBreakdownResultList();
		// OCF超過なし
//		com.nissan.danswer.model.colorbreakdown.MonthlyOCFList ocfList = ColorBreakdown_NationalTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf.csv");
		// OCF超過少数
//		com.nissan.danswer.model.colorbreakdown.MonthlyOCFList ocfList = ColorBreakdown_NationalTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf_exceed_small.csv");
		// OCF超過多数
		com.nissan.danswer.model.colorbreakdown.MonthlyOCFList ocfList = ColorBreakdown_NationalTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf_exceed_big.csv");
		
		ksession.insert(ratioList);			// IN
		ksession.insert(recommendedList);	// IN
		ksession.insert(specList);			// IN
		ksession.insert(ocfList);			// IN/OUT
		ksession.insert(resultList);		// OUT
		
		ksession.startProcess(FLOW_ID);
		Date startDate = new Date();
		// fire
		int fireCnt = ksession.fireAllRules();

		Date endDate = new Date();
		System.out.println("====> run end");
		
		// system out
		sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_COLOR_BREAKDOWN_NATIONAL);
	}

	/**
	 * カラー配分（輸入車）
	 * @throws Exception 
	 */
	public static void colorBdImport() throws Exception {
		int dealerCnt = 250;
		// input Fact list
		com.nissan.danswer.model.colorbreakdown.ColorRatioList ratioList = makeColorRatioList(DATAPATH + "/performanceTest/coloratio_10.csv", dealerCnt);
		com.nissan.danswer.model.colorbreakdown.RecommendedOrderList recommendedList = makeRecommended_importList(DATAPATH + "/performanceTest/recommended_10.csv", dealerCnt, 2);
		com.nissan.danswer.model.colorbreakdown.ProductionOrderImportList orderList = ColorBreakdown_ImportTest.makeOrderImportList(DATAPATH + "/performanceTest/order_import_10.csv");

//		com.nissan.danswer.model.colorbreakdown.ColorRatioList ratioList = makeColorRatioList(DATAPATH + "/performanceTest/coloratio.csv", dealerCnt);
//		com.nissan.danswer.model.colorbreakdown.RecommendedOrderList recommendedList = makeRecommended_importList(DATAPATH + "/performanceTest/recommended.csv", dealerCnt, 20);
//		com.nissan.danswer.model.colorbreakdown.ProductionOrderImportList orderList = ColorBreakdown_ImportTest.makeOrderImportList(DATAPATH + "/performanceTest/order_import.csv");
		com.nissan.danswer.model.colorbreakdown.ColorBreakdownResultList resultList = new ColorBreakdownResultList();
			
		ksession.insert(ratioList);			// IN
		ksession.insert(recommendedList);	// IN
		ksession.insert(orderList);			// IN
		ksession.insert(resultList);		// OUT
		
		ksession.startProcess(FLOW_ID);
		Date startDate = new Date();
		// fire
		int fireCnt = ksession.fireAllRules();

		Date endDate = new Date();
		System.out.println("====> run end");
		
		// system out
		sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_COLOR_BREAKDOWN_IMPORT);
	}
	
	/**
	 * ScheduleCheck テスト
	 * _5cs:5基準車系用のCSV、何もついてないのは1基準車系のみ
	 * @throws Exception 
	 */
	public static void scheduleCheck() throws Exception {
		com.nissan.danswer.model.schedulecheck.OrderList orderList = ScheduleCheckTest.makeOrderList(DATAPATH + "/performanceTest/order.csv");
		com.nissan.danswer.model.schedulecheck.ScheduleList scheduleList = ScheduleCheckTest.makeScheduleList(DATAPATH + "/performanceTest/schedule.csv");
		com.nissan.danswer.model.schedulecheck.DailyOCFList ocfList = ScheduleCheckTest.makeDailyOcfList(DATAPATH + "/performanceTest/daily_ocf.csv");
		com.nissan.danswer.model.schedulecheck.SpecOCFList specList = ScheduleCheckTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");

//		com.nissan.danswer.model.schedulecheck.OrderList orderList = ScheduleCheckTest.makeOrderList(DATAPATH + "/performanceTest/order_5cs.csv");
//		com.nissan.danswer.model.schedulecheck.ScheduleList scheduleList = ScheduleCheckTest.makeScheduleList(DATAPATH + "/performanceTest/schedule_5cs.csv");
//		com.nissan.danswer.model.schedulecheck.DailyOCFList ocfList = ScheduleCheckTest.makeDailyOcfList(DATAPATH + "/performanceTest/daily_ocf_5cs.csv");
//		com.nissan.danswer.model.schedulecheck.SpecOCFList specList = ScheduleCheckTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf_5cs.csv");
		
		com.nissan.danswer.model.schedulecheck.MatchingResultList resultList = new MatchingResultList();
		com.nissan.danswer.model.schedulecheck.OrderOnlyList orderOnly = new OrderOnlyList();
		com.nissan.danswer.model.schedulecheck.ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();
		
		ksession.insert(orderList);		// IN/OUT
		ksession.insert(scheduleList);	// IN/OUT
		ksession.insert(specList);		// IN
		ksession.insert(ocfList);		// IN/OUT
		ksession.insert(resultList);	// OUT
		ksession.insert(orderOnly);		// OUT
		ksession.insert(scheduleOnly);	// OUT
		
		ksession.startProcess(FLOW_ID);
		Date startDate = new Date();
		// fire
		int fireCnt = ksession.fireAllRules();

		Date endDate = new Date();
		System.out.println("====> run end");
		
		// system out
		sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_PRODUCTION_SCHEDULE_CHECK);
		
	}
	
	/**
	 * OCFSlotting テスト
	 * @throws Exception 
	 */
	public static void ocfSlotting() throws Exception {
//		com.nissan.danswer.model.ocfslotting.EndItemBreakdownResultList bdList = OcfSlottingTest.makeEIBreakdownList(DATAPATH + "/performanceTest/breakdown_result_05.csv");
//		com.nissan.danswer.model.ocfslotting.MonthlyOCFList ocfList = OcfSlottingTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf_05.csv");
//		com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList specList = OcfSlottingTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf_05.csv");	

		com.nissan.danswer.model.ocfslotting.EndItemBreakdownResultList bdList = OcfSlottingTest.makeEIBreakdownList(DATAPATH + "/performanceTest/breakdown_result.csv");
		com.nissan.danswer.model.ocfslotting.MonthlyOCFList ocfList = OcfSlottingTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/monthly_ocf.csv");
		com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList specList = OcfSlottingTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");	
		com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList slotList = new com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList();	
		
		ksession.insert(bdList);	// IN
		ksession.insert(ocfList);	// IN/OUT
		ksession.insert(specList);	// IN
		ksession.insert(slotList);	// OUT
		
		ksession.startProcess(FLOW_ID);
		Date startDate = new Date();
		// fire
		int fireCnt = ksession.fireAllRules();

		Date endDate = new Date();
		System.out.println("====> run end");
		
		// system out
		sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_OCF_SLOTTING);
		
	}
	
	/**
	 * EndItemBreakdown テスト
	 * @throws Exception 
	 */
	public static void endItemBreakdown() throws Exception {

		com.nissan.danswer.model.eibreakdown.MonthlyOCFList ocfList = EndItemBreakdownTest.makeMonthlyOcfList(DATAPATH + "/performanceTest/ocf_monthly.csv");
		com.nissan.danswer.model.eibreakdown.EndItemRatioList ratioList = EndItemBreakdownTest.makeEIRatioList(DATAPATH + "/performanceTest/ei_ratio.csv");
		com.nissan.danswer.model.eibreakdown.MonthlySpecOCFList specList = EndItemBreakdownTest.makeSpecOcfList(DATAPATH + "/performanceTest/spec_ocf.csv");
		com.nissan.danswer.model.eibreakdown.EndItemSlottingResultList slotList = new EndItemSlottingResultList();
		
		ksession.insert(ratioList);	// 1.
		ksession.insert(ocfList);	// 2.
		ksession.insert(specList);	// 3.
		ksession.insert(slotList);	// 4.
		ksession.insert(EndItemBreakdownTest.makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
		
		ksession.startProcess(FLOW_ID);
		Date startDate = new Date();
		// fire
//		int fireCnt = ksession.fireAllRules(HelperConstants.FIRE_LIMIT_EI_BREAKDOWN);
		int fireCnt = ksession.fireAllRules();

		Date endDate = new Date();
		System.out.println("====> run end");
		
		// system out
		sysOut(startDate, endDate, fireCnt, HelperConstants.FIRE_LIMIT_EI_BREAKDOWN);
		
	}
	
	/**
	 * 共通ログ（処理後）
	 * @param startDate
	 * @param endDate
	 * @param fireCnt
	 * @param maxCnt
	 */
	private static void sysOut(Date startDate, Date endDate, int fireCnt, int maxCnt) {
		
		BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
		
		System.out.println("start : " + startDate);
		System.out.println("end   : " + endDate);
		System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
		System.out.println("fireCnt : " + fireCnt);
		
		if (fireCnt >= maxCnt) {
			System.out.println("WARNING! rule loops");
		}
		
	}
	
	public static ColorRatioList makeColorRatioList(String filename, int dealerCnt) throws Exception {
		String data[]=new String[8];
		ColorRatioList list = new ColorRatioList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			String dealer;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				for (int i = 1; i < dealerCnt + 1; i++) {
					// DEALER250社
					dealer = editDealerCode(i); 
					list.add(setColorRatio(
						data[0], data[1], data[2], data[3],
						dealer, data[5], data[6], Double.valueOf(data[7]).doubleValue()));
				}
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}
	
	private static String editDealerCode(int idx) {
		
		StringBuffer dealer = new StringBuffer();
		dealer.append("D");
		
		for (int i = 3 - String.valueOf(idx).length(); i > 0; i--) {
			dealer.append("0");
		}
		
		dealer.append(String.valueOf(idx));
		
		return dealer.toString();
	}

	public static ColorRatio setColorRatio(String ym, String car,
			String por, String family, String dealer, String model,
			String color, double ratio) {
		
		ColorRatio colorRatio = new ColorRatio();
		colorRatio.setPlanYearMonth(ym);
		colorRatio.setCarSeries(car);
		colorRatio.setPorCode(por);
		colorRatio.setProductionFamilyCode(family);
		colorRatio.setDealerCode(dealer);
		colorRatio.setEndItemModelCode(model);
		colorRatio.setEndItemColorCode(color);
		colorRatio.setRatio(ratio);
		
		return colorRatio;
	}
	
	public static RecommendedOrderList makeRecommended_importList(String filename, int dealerCnt, int lineCnt) throws Exception {
		String data[]=new String[7];
		RecommendedOrderList list = new RecommendedOrderList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			String dealer;
			int i = 1;	// CSV行数
			int k = 0;	// 20行ずつインクリメント(E/I_MODELの種類数)
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				if (i % lineCnt == 1) {
					k++;
				}
				// 5ずつインクリメント
				for (int j = k; j < dealerCnt + 1; j = j+5) {
					dealer = editDealerCode(j); 
					list.add(setRecommended(
						data[0], data[1], data[2], data[3],
						dealer, data[5], Integer.valueOf(data[6]).intValue()));
				}
				i++;
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}
	
	public static RecommendedOrderList makeRecommendedList(String filename, int dealerCnt) throws Exception {
		String data[]=new String[7];
		RecommendedOrderList list = new RecommendedOrderList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			String dealer;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				for (int i = 1; i < dealerCnt + 1; i++) {
					dealer = editDealerCode(i); 
					list.add(setRecommended(
						data[0], data[1], data[2], data[3],
						dealer, data[5], Integer.valueOf(data[6]).intValue()));
				}
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	public static RecommendedOrder setRecommended(String ym, String car,
			String por, String family, String dealer, String model,
			int qty) {
		
		RecommendedOrder order = new RecommendedOrder();
		order.setPlanYearMonth(ym);
		order.setCarSeries(car);
		order.setPorCode(por);
		order.setProductionFamilyCode(family);
		order.setDealerCode(dealer);
		order.setEndItemModelCode(model);
		order.setQty(qty);
		
		return order;
	}
}
