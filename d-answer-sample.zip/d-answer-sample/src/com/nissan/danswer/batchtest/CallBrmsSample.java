package com.nissan.danswer.batchtest;

import java.math.BigDecimal;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.runtime.StatefulKnowledgeSession;

import com.nissan.danswer.helper.HelperConstants;
import com.nissan.danswer.helper.KnowledgeService;

/**
 * call brms sample
 * @author SCSK
 *
 */
public class CallBrmsSample {

	// 再引当
	private static final String changesetXML = "cs_reAllocation.xml";
	private static final String flowID = "com.nissan.danswer.flow.reallocation";
	// E/Iばらし
//	private static final String changesetXML = "cs_endItemBreakdown.xml";
//	private static final String flowID = "com.nissan.danswer.flow.enditembreakdown";
	// 在庫引当
//	private static final String changesetXML = "cs_inventoryAlloc.xml";
//	private static final String flowID = "com.nissan.danswer.flow.inventoryallocation";
	// OCFスロッティング
//	private static final String changesetXML = "cs_ocfSlotting.xml";
//	private static final String flowID = "com.nissan.danswer.flow.ocfslotting";
	// スケジュールチェック
//	private static final String changesetXML = "cs_scheduleCheck.xml";
//	private static final String flowID = "com.nissan.danswer.flow.schedulecheck";
	// 在庫補填
//	private static final String changesetXML = "cs_stockCover.xml";
//	private static final String flowID = "com.nissan.danswer.flow.stockcover";
	// 販社配分
//	private static final String changesetXML = "cs_dealerAllocation.xml";
//	private static final String flowID = "com.nissan.danswer.flow.dealerallocation";
	// カラー配分（輸入車）
//	private static final String changesetXML = "cs_colorBreakdownImport.xml";
//	private static final String flowID = "com.nissan.danswer.flow.colorbreakdownimport";
	// カラー配分（国内生産車）
//	private static final String changesetXML = "cs_colorBreakdownNational.xml";
//	private static final String flowID = "com.nissan.danswer.flow.colorbreakdownnational";
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		/* Batch processing */
		// ・・・・
		
		/* declare facts and set data */
//		MonthlyOCFList ocfList;
//		EndItemSlottingResultList slotList;
//		EndItemRatioList ratioList;
//		MonthlySpecOCFList specList;
//		
//		ocfList = getMonthlyOCF();
//		ratioList = getRatio();
//		specList = getSpecOCF();
//		slotList = new EndItemSlottingResultList();
		
		/* get KnowledgeSession */
		KnowledgeService kservice = new KnowledgeService();
		KnowledgeBase kbase = kservice.getKnowledgeBase(changesetXML);
		StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
		
		/* insert facts */
//		ksession.insert(ocfList);
//		ksession.insert(slotList);
//		ksession.insert(ratioList);
//		ksession.insert(specList);
		
		int fireCnt = 0;
		Date startDate = new Date();
		
		try {
			ksession.startProcess(flowID);
			/* execute rule */
			fireCnt = ksession.fireAllRules(HelperConstants.FIRE_LIMIT_EI_BREAKDOWN);
		} catch (Exception e) {
			// TODO write code on error
			System.out.println("An exception occurred for rule run time.");
			e.printStackTrace();
		} finally {
			/* dispose */
			ksession.dispose();
			kservice.destroy();
		}
		
		/* if rule process loops, print out error log */
		if (fireCnt == HelperConstants.FIRE_LIMIT_EI_BREAKDOWN) {
			// TODO print out 'error' log
			System.out.println("A rule process might do a loop.");
		}
		
		/* info log */
		Date endDate = new Date();		
		BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());		
		// TODO print out 'info' log
		System.out.println("start : " + startDate);
		System.out.println("end   : " + endDate);
		System.out.println("fireCnt : " + fireCnt);

		/* verification of result */
		// ・・・・
	}
}
