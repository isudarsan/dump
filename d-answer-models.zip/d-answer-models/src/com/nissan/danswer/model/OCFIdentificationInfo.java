package com.nissan.danswer.model;


/**
 * OCFIdentificationInfo
 * @author SCSK
 *
 */
public class OCFIdentificationInfo extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	/** FRAME_SORT_CODE */
	private String frameSortCode;
	
	/** OCF_CLASSIFICATION_CODE */
	private String ocfClassificationCode;
	
	/** LOCATION_IDENTIFICATION_CODE */
	private String locationIdentificationCode;
	
	/** CAR_GROUP */
	private String carGroup;
	
	/** FRAME_CODE */
	private String frameCode;

	public String getFrameSortCode() {
		return frameSortCode;
	}

	public void setFrameSortCode(String frameSortCode) {
		this.frameSortCode = frameSortCode;
	}

	public String getOcfClassificationCode() {
		return ocfClassificationCode;
	}

	public void setOcfClassificationCode(String ocfClassificationCode) {
		this.ocfClassificationCode = ocfClassificationCode;
	}

	public String getLocationIdentificationCode() {
		return locationIdentificationCode;
	}

	public void setLocationIdentificationCode(String locationIdentificationCode) {
		this.locationIdentificationCode = locationIdentificationCode;
	}

	public String getCarGroup() {
		return carGroup;
	}

	public void setCarGroup(String carGroup) {
		this.carGroup = carGroup;
	}

	public String getFrameCode() {
		return frameCode;
	}

	public void setFrameCode(String frameCode) {
		this.frameCode = frameCode;
	}

	@Override
	public String toString() {
		return "OCFIdentificationInfo [frameSortCode=" + frameSortCode
				+ ", ocfClassificationCode=" + ocfClassificationCode
				+ ", locationIdentificationCode=" + locationIdentificationCode
				+ ", carGroup=" + carGroup + ", frameCode=" + frameCode + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carGroup == null) ? 0 : carGroup.hashCode());
		result = prime * result
				+ ((frameCode == null) ? 0 : frameCode.hashCode());
		result = prime * result
				+ ((frameSortCode == null) ? 0 : frameSortCode.hashCode());
		result = prime
				* result
				+ ((locationIdentificationCode == null) ? 0
						: locationIdentificationCode.hashCode());
		result = prime
				* result
				+ ((ocfClassificationCode == null) ? 0 : ocfClassificationCode
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OCFIdentificationInfo other = (OCFIdentificationInfo) obj;
		if (carGroup == null) {
			if (other.carGroup != null)
				return false;
		} else if (!carGroup.equals(other.carGroup))
			return false;
		if (frameCode == null) {
			if (other.frameCode != null)
				return false;
		} else if (!frameCode.equals(other.frameCode))
			return false;
		if (frameSortCode == null) {
			if (other.frameSortCode != null)
				return false;
		} else if (!frameSortCode.equals(other.frameSortCode))
			return false;
		if (locationIdentificationCode == null) {
			if (other.locationIdentificationCode != null)
				return false;
		} else if (!locationIdentificationCode
				.equals(other.locationIdentificationCode))
			return false;
		if (ocfClassificationCode == null) {
			if (other.ocfClassificationCode != null)
				return false;
		} else if (!ocfClassificationCode.equals(other.ocfClassificationCode))
			return false;
		return true;
	}

}
