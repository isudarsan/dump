package com.nissan.danswer.model.inventoryallocation;

import com.nissan.danswer.model.BaseModel;

public class StorageYardPriorityByDealerForClearFlag extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String dealerCode;
	private String storageYardCode;
	private String priority;
    
    private String allocated; // 内部利用
    
    public String getDealerCode() {
        return dealerCode;
    }
    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }
    public String getStorageYardCode() {
        return storageYardCode;
    }
    public void setStorageYardCode(String storageYardCode) {
        this.storageYardCode = storageYardCode;
    }
    public String getPriority() {
        return priority;
    }
    public void setPriority(String priority) {
        this.priority = priority;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((allocated == null) ? 0 : allocated.hashCode());
        result = prime * result
                + ((dealerCode == null) ? 0 : dealerCode.hashCode());
        result = prime * result
                + ((priority == null) ? 0 : priority.hashCode());
        result = prime * result
                + ((storageYardCode == null) ? 0 : storageYardCode.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        StorageYardPriorityByDealerForClearFlag other = (StorageYardPriorityByDealerForClearFlag) obj;
        if (allocated == null) {
            if (other.allocated != null)
                return false;
        } else if (!allocated.equals(other.allocated))
            return false;
        if (dealerCode == null) {
            if (other.dealerCode != null)
                return false;
        } else if (!dealerCode.equals(other.dealerCode))
            return false;
        if (priority == null) {
            if (other.priority != null)
                return false;
        } else if (!priority.equals(other.priority))
            return false;
        if (storageYardCode == null) {
            if (other.storageYardCode != null)
                return false;
        } else if (!storageYardCode.equals(other.storageYardCode))
            return false;
        return true;
    }
    public String getAllocated() {
        return allocated;
    }
    public void setAllocated(String allocated) {
        this.allocated = allocated;
    }
    @Override
    public String toString() {
        return "StorageYardPriorityByDealer [dealerCode=" + dealerCode
                + ", storageYardCode=" + storageYardCode + ", priority="
                + priority + ", allocated=" + allocated + "]";
    }
}
