package com.nissan.danswer.model.inventoryallocation;

import java.util.ArrayList;

/**
 * OrderList
 * <pre>
 * 返却用Orderリスト
 * </pre>
 * @author SCSK
 *
 */
public class OutOrderList extends ArrayList<Order> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

}
