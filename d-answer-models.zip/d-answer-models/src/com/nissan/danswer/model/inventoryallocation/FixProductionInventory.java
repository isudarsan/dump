package com.nissan.danswer.model.inventoryallocation;

import java.math.BigDecimal;

import com.nissan.danswer.model.BaseModel;

public class FixProductionInventory extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String productionYear="";
	public String getProductionYear() {
		return productionYear;
	}
	public void setProductionYear(String productionYear) {
		this.productionYear = productionYear;
	}
	private String vinNo;
	private String endItemModelCode;
	private String endItemColorCode;
	private String factoryCode;
	private String lineClass;
	private String actualFinalOkDate;
	private String actualOfflineDate;
	private String planFinalOkDate;
	private String planOfflineDate;
	private BigDecimal sortNo;
	private String actualFinalOkDateForSortNo;
	private String actualOfflineDateForSortNo;
	private String planFinalOkDateForSortNo;
	private String planOfflineDateForSortNo;
    
    public String getVinNo() {
        return vinNo;
    }
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }
    public String getEndItemModelCode() {
        return endItemModelCode;
    }
    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }
    public String getEndItemColorCode() {
        return endItemColorCode;
    }
    public void setEndItemColorCode(String endItemColorCode) {
        this.endItemColorCode = endItemColorCode;
    }
    public String getFactoryCode() {
        return factoryCode;
    }
    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }
    public String getLineClass() {
        return lineClass;
    }
    public void setLineClass(String lineClass) {
        this.lineClass = lineClass;
    }
    public String getActualFinalOkDate() {
        return actualFinalOkDate;
    }
    public void setActualFinalOkDate(String actualFinalOkDate) {
        this.actualFinalOkDate = actualFinalOkDate;
    }
    public String getActualOfflineDate() {
        return actualOfflineDate;
    }
    public void setActualOfflineDate(String actualOfflineDate) {
        this.actualOfflineDate = actualOfflineDate;
    }
    public String getPlanFinalOkDate() {
        return planFinalOkDate;
    }
    public void setPlanFinalOkDate(String planFinalOkDate) {
        this.planFinalOkDate = planFinalOkDate;
    }
    public String getPlanOfflineDate() {
        return planOfflineDate;
    }
    public void setPlanOfflineDate(String planOfflineDate) {
        this.planOfflineDate = planOfflineDate;
    }
    @Override
	public String toString() {
		return "FixProductionInventory [productionYear=" + productionYear
				+ ", vinNo=" + vinNo + ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode + ", factoryCode="
				+ factoryCode + ", lineClass=" + lineClass
				+ ", actualFinalOkDate=" + actualFinalOkDate
				+ ", actualOfflineDate=" + actualOfflineDate
				+ ", planFinalOkDate=" + planFinalOkDate + ", planOfflineDate="
				+ planOfflineDate + ", sortNo=" + sortNo
				+ ", actualFinalOkDateForSortNo=" + actualFinalOkDateForSortNo
				+ ", actualOfflineDateForSortNo=" + actualOfflineDateForSortNo
				+ ", planFinalOkDateForSortNo=" + planFinalOkDateForSortNo
				+ ", planOfflineDateForSortNo=" + planOfflineDateForSortNo
				+ "]";
	}
    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", 
        	 vinNo,
        	 endItemModelCode,
        	 endItemColorCode,
        	 factoryCode,
        	 lineClass,
        	 actualFinalOkDate,
        	 actualOfflineDate,
        	 planFinalOkDate,
        	 planOfflineDate,productionYear);
    }
    public String getActualFinalOkDateForSortNo() {
        return actualFinalOkDateForSortNo;
    }
    public void setActualFinalOkDateForSortNo(String actualFinalOkDateForSortNo) {
        this.actualFinalOkDateForSortNo = actualFinalOkDateForSortNo;
    }
    public String getActualOfflineDateForSortNo() {
        return actualOfflineDateForSortNo;
    }
    public void setActualOfflineDateForSortNo(String actualOfflineDateForSortNo) {
        this.actualOfflineDateForSortNo = actualOfflineDateForSortNo;
    }
    public String getPlanFinalOkDateForSortNo() {
        return planFinalOkDateForSortNo;
    }
    public void setPlanFinalOkDateForSortNo(String planFinalOkDateForSortNo) {
        this.planFinalOkDateForSortNo = planFinalOkDateForSortNo;
    }
    public String getPlanOfflineDateForSortNo() {
        return planOfflineDateForSortNo;
    }
    public void setPlanOfflineDateForSortNo(String planOfflineDateForSortNo) {
        this.planOfflineDateForSortNo = planOfflineDateForSortNo;
    }
    public BigDecimal getSortNo() {
        return sortNo;
    }
    public void setSortNo(BigDecimal sortNo) {
        this.sortNo = sortNo;
    }
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((actualFinalOkDate == null) ? 0 : actualFinalOkDate
						.hashCode());
		result = prime
				* result
				+ ((actualFinalOkDateForSortNo == null) ? 0
						: actualFinalOkDateForSortNo.hashCode());
		result = prime
				* result
				+ ((actualOfflineDate == null) ? 0 : actualOfflineDate
						.hashCode());
		result = prime
				* result
				+ ((actualOfflineDateForSortNo == null) ? 0
						: actualOfflineDateForSortNo.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result
				+ ((factoryCode == null) ? 0 : factoryCode.hashCode());
		result = prime * result
				+ ((lineClass == null) ? 0 : lineClass.hashCode());
		result = prime * result
				+ ((planFinalOkDate == null) ? 0 : planFinalOkDate.hashCode());
		result = prime
				* result
				+ ((planFinalOkDateForSortNo == null) ? 0
						: planFinalOkDateForSortNo.hashCode());
		result = prime * result
				+ ((planOfflineDate == null) ? 0 : planOfflineDate.hashCode());
		result = prime
				* result
				+ ((planOfflineDateForSortNo == null) ? 0
						: planOfflineDateForSortNo.hashCode());
		result = prime * result
				+ ((productionYear == null) ? 0 : productionYear.hashCode());
		result = prime * result + ((sortNo == null) ? 0 : sortNo.hashCode());
		result = prime * result + ((vinNo == null) ? 0 : vinNo.hashCode());
		return result;
	}
    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FixProductionInventory other = (FixProductionInventory) obj;
		if (actualFinalOkDate == null) {
			if (other.actualFinalOkDate != null)
				return false;
		} else if (!actualFinalOkDate.equals(other.actualFinalOkDate))
			return false;
		if (actualFinalOkDateForSortNo == null) {
			if (other.actualFinalOkDateForSortNo != null)
				return false;
		} else if (!actualFinalOkDateForSortNo
				.equals(other.actualFinalOkDateForSortNo))
			return false;
		if (actualOfflineDate == null) {
			if (other.actualOfflineDate != null)
				return false;
		} else if (!actualOfflineDate.equals(other.actualOfflineDate))
			return false;
		if (actualOfflineDateForSortNo == null) {
			if (other.actualOfflineDateForSortNo != null)
				return false;
		} else if (!actualOfflineDateForSortNo
				.equals(other.actualOfflineDateForSortNo))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (factoryCode == null) {
			if (other.factoryCode != null)
				return false;
		} else if (!factoryCode.equals(other.factoryCode))
			return false;
		if (lineClass == null) {
			if (other.lineClass != null)
				return false;
		} else if (!lineClass.equals(other.lineClass))
			return false;
		if (planFinalOkDate == null) {
			if (other.planFinalOkDate != null)
				return false;
		} else if (!planFinalOkDate.equals(other.planFinalOkDate))
			return false;
		if (planFinalOkDateForSortNo == null) {
			if (other.planFinalOkDateForSortNo != null)
				return false;
		} else if (!planFinalOkDateForSortNo
				.equals(other.planFinalOkDateForSortNo))
			return false;
		if (planOfflineDate == null) {
			if (other.planOfflineDate != null)
				return false;
		} else if (!planOfflineDate.equals(other.planOfflineDate))
			return false;
		if (planOfflineDateForSortNo == null) {
			if (other.planOfflineDateForSortNo != null)
				return false;
		} else if (!planOfflineDateForSortNo
				.equals(other.planOfflineDateForSortNo))
			return false;
		if (productionYear == null) {
			if (other.productionYear != null)
				return false;
		} else if (!productionYear.equals(other.productionYear))
			return false;
		if (sortNo == null) {
			if (other.sortNo != null)
				return false;
		} else if (!sortNo.equals(other.sortNo))
			return false;
		if (vinNo == null) {
			if (other.vinNo != null)
				return false;
		} else if (!vinNo.equals(other.vinNo))
			return false;
		return true;
	}
}
