package com.nissan.danswer.model.inventoryallocation;

import com.nissan.danswer.model.BaseModel;

public class Inventory1 extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String productionYear="";
	public String getProductionYear() {
		return productionYear;
	}
	public void setProductionYear(String productionYear) {
		this.productionYear = productionYear;
	}
	private String vinNo;
	private String endItemModelCode;
	private String endItemColorCode;
	private String storageYardCode;
	private String date; // 8bytes(YYYYMMDD format)
	private int allocated;
    
    public String getVinNo() {
        return vinNo;
    }
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }
    public String getEndItemModelCode() {
        return endItemModelCode;
    }
    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }
    public String getEndItemColorCode() {
        return endItemColorCode;
    }
    public void setEndItemColorCode(String endItemColorCode) {
        this.endItemColorCode = endItemColorCode;
    }
    public String getStorageYardCode() {
        return storageYardCode;
    }
    public void setStorageYardCode(String storageYardCode) {
        this.storageYardCode = storageYardCode;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s", 
                vinNo,
                endItemModelCode,
                endItemColorCode,
                storageYardCode,
                date); // 8bytes(YYYYMMDD format)
    }
    public int getAllocated() {
        return allocated;
    }
    public void setAllocated(int allocated) {
        this.allocated = allocated;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + allocated;
        result = prime * result + ((date == null) ? 0 : date.hashCode());
        result = prime
                * result
                + ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
        result = prime
                * result
                + ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
        result = prime * result
                + ((storageYardCode == null) ? 0 : storageYardCode.hashCode());
        result = prime * result + ((vinNo == null) ? 0 : vinNo.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Inventory1 other = (Inventory1) obj;
        if (allocated != other.allocated)
            return false;
        if (date == null) {
            if (other.date != null)
                return false;
        } else if (!date.equals(other.date))
            return false;
        if (endItemColorCode == null) {
            if (other.endItemColorCode != null)
                return false;
        } else if (!endItemColorCode.equals(other.endItemColorCode))
            return false;
        if (endItemModelCode == null) {
            if (other.endItemModelCode != null)
                return false;
        } else if (!endItemModelCode.equals(other.endItemModelCode))
            return false;
        if (storageYardCode == null) {
            if (other.storageYardCode != null)
                return false;
        } else if (!storageYardCode.equals(other.storageYardCode))
            return false;
        if (vinNo == null) {
            if (other.vinNo != null)
                return false;
        } else if (!vinNo.equals(other.vinNo))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "Inventory1 [vinNo=" + vinNo + ", endItemModelCode="
                + endItemModelCode + ", endItemColorCode=" + endItemColorCode
                + ", storageYardCode=" + storageYardCode + ", date=" + date
                + ", allocated=" + allocated + "]";
    }
}
