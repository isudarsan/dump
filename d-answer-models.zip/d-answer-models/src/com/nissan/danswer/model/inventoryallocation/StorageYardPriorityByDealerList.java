package com.nissan.danswer.model.inventoryallocation;

import java.util.ArrayList;

/**
 * OrderList
 * @author SCSK
 *
 */
public class StorageYardPriorityByDealerList extends ArrayList<StorageYardPriorityByDealer> {

    private static final long serialVersionUID = 8690707643263435316L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted StorageYardPriorityByDealer Data(csv format) --------%n");
        out.append("#DEALER_CODE,STORAGE_YARD_CODE,PRIORITY%n");

        for (StorageYardPriorityByDealer stock : this) {
            out.append(stock.toCSV());
            out.append("%n");
        }

        out.append("--------------------------------------------------------------");
        
        return out.toString();
    }
}
