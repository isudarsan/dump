package com.nissan.danswer.model.inventoryallocation;

import java.util.ArrayList;

/**
 * InventoryList
 * <pre>
 * Inventory情報はこのクラスにセットされた形でルールに渡され、ルール内で展開する
 * </pre>
 * @author SCSK
 *
 */
public class InventoryList extends ArrayList<Inventory> {

    private static final long serialVersionUID = -5863839516554514250L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted Inventory Data(csv format) --------%n");
        out.append("#VIN_NO,END_ITEM_MODEL_CODE,END_ITEM_COLOR_CODE,STORAGE_YARD_CODE,DATE%n");

        for (Inventory ei : this) {
            out.append(ei.toCSV());
            out.append("%n");
        }

        out.append("--------------------------------------------");

        return out.toString();
    }
}
