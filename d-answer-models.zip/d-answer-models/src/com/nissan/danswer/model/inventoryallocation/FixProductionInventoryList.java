package com.nissan.danswer.model.inventoryallocation;

import java.util.ArrayList;

/**
 * InventoryList
 * <pre>
 * Inventory情報はこのクラスにセットされた形でルールに渡され、ルール内で展開する
 * </pre>
 * @author SCSK
 *
 */
public class FixProductionInventoryList extends ArrayList<FixProductionInventory> {

    private static final long serialVersionUID = -8888178660641833565L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted FixProductionInventory Data(csv format) --------%n");
        out.append("#VIN_NO,END_ITEM_MODEL_CODE,END_ITEM_COLOR_CODE,FACTORY_CODE,LINE_CLASS,ACTUAL_FINAL_OK_DATE,ACTUAL_OFFLINE_DATE,PLAN_FINAL_OK_DATE,PLAN_OFFLINE_DATE%n");

        for (FixProductionInventory ei : this) {
            out.append(ei.toCSV());
            out.append("%n");
        }

        out.append("---------------------------------------------------------");
        
        return out.toString();
    }
}
