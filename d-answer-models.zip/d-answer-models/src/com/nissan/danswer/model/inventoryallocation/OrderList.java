package com.nissan.danswer.model.inventoryallocation;

import java.util.ArrayList;

/**
 * OrderList
 * @author SCSK
 *
 */
public class OrderList extends ArrayList<Order> {

    private static final long serialVersionUID = -6265968845342097591L;
    
    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted Order Data(csv format) --------%n");
        out.append("#VEHICLE_SEQ_ID,DEALER_CODE,END_ITEM_MODEL_CODE,END_ITEM_COLOR_CODE,ORDER_TYPE,OFFLINE_DATE,REALLOCATION_PRIORITY_NO,INPUT_DATE_OF_ORDER,WEEK_OF_DUE_DATE_FOR_DELOVERY,DEALER_REPLY_FLG,RANDOM_NO,BOLSA_OR_NOT%n");

        for (Order ei : this) {
            out.append(ei.toCSV());
            out.append("%n");
        }

        out.append("----------------------------------------");
        
        return out.toString();
    }
}
