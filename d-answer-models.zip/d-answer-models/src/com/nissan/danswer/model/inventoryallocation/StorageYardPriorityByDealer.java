package com.nissan.danswer.model.inventoryallocation;

import com.nissan.danswer.model.BaseModel;

public class StorageYardPriorityByDealer extends BaseModel {
    private static final long serialVersionUID = -2760690658508165325L;
    private String dealerCode;
	private String storageYardCode;
	private String priority;
    
    private int allocated; // for intenal use
    
    public String getDealerCode() {
        return dealerCode;
    }
    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }
    public String getStorageYardCode() {
        return storageYardCode;
    }
    public void setStorageYardCode(String storageYardCode) {
        this.storageYardCode = storageYardCode;
    }
    public String getPriority() {
        return priority;
    }
    public void setPriority(String priority) {
        this.priority = priority;
    }
    @Override
    public String toString() {
        return "StorageYardPriorityByDealer [dealerCode=" + dealerCode
                + ", storageYardCode=" + storageYardCode + ", priority="
                + priority + ", allocated=" + allocated + "]";
    }
    public String toCSV() {
        return String.format("%s,%s,%s", 
                dealerCode,
                storageYardCode,
                priority);
    }
    public int getAllocated() {
        return allocated;
    }
    public void setAllocated(int allocated) {
        this.allocated = allocated;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + allocated;
        result = prime * result
                + ((dealerCode == null) ? 0 : dealerCode.hashCode());
        result = prime * result
                + ((priority == null) ? 0 : priority.hashCode());
        result = prime * result
                + ((storageYardCode == null) ? 0 : storageYardCode.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        StorageYardPriorityByDealer other = (StorageYardPriorityByDealer) obj;
        if (allocated != other.allocated)
            return false;
        if (dealerCode == null) {
            if (other.dealerCode != null)
                return false;
        } else if (!dealerCode.equals(other.dealerCode))
            return false;
        if (priority == null) {
            if (other.priority != null)
                return false;
        } else if (!priority.equals(other.priority))
            return false;
        if (storageYardCode == null) {
            if (other.storageYardCode != null)
                return false;
        } else if (!storageYardCode.equals(other.storageYardCode))
            return false;
        return true;
    }
}
