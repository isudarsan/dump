package com.nissan.danswer.model.inventoryallocation;

import java.math.BigDecimal;

import com.nissan.danswer.model.BaseModel;

public class Order extends BaseModel {
    private static final long serialVersionUID = -6565012978910370522L;
    
    private String productionYear="";
	public String getProductionYear() {
		return productionYear;
	}
	public void setProductionYear(String productionYear) {
		this.productionYear = productionYear;
	}
    private String vehicleSeqId;
	private String dealerCode;
	private String endItemModelCode;
	private String endItemColorCode;
	private String orderType;
	private String offlineDate;
	private String reallocationPriorityNo;
	private String inputDateOfOrder;
	private String weekOfDueDateForDelivery;
	private String dealerReplyFlg;
	private String randomNo;
	private String bolsaOrNot;
	private String vinNo;
	private String storageYardCode;
	private String factoryCode;
	private String lineClass;
	private String actualFinalOkDate;
	private String actualOfflineDate;
	private String planFinalOkDate;
	private String planOfflineDate;
    
    // for internal use
	private BigDecimal sortNo;
    private String offlineDateForSortNo;
    private String dsOrder;
    private String dealer;
    private String bolsaForSortNo;
    private int execute;
    private int appliedInventory;

    public String getVehicleSeqId() {
        return vehicleSeqId;
    }
    public void setVehicleSeqId(String vehicleSeqId) {
        this.vehicleSeqId = vehicleSeqId;
    }
    public String getDealerCode() {
        return dealerCode;
    }
    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }
    public String getEndItemModelCode() {
        return endItemModelCode;
    }
    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }
    public String getEndItemColorCode() {
        return endItemColorCode;
    }
    public void setEndItemColorCode(String endItemColorCode) {
        this.endItemColorCode = endItemColorCode;
    }
    public String getOrderType() {
        return orderType;
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getOfflineDate() {
        return offlineDate;
    }
    public void setOfflineDate(String offlineDate) {
        this.offlineDate = offlineDate;
    }
    public String getReallocationPriorityNo() {
        return reallocationPriorityNo;
    }
    public void setReallocationPriorityNo(String reallocationPriorityNo) {
        this.reallocationPriorityNo = reallocationPriorityNo;
    }
    public String getInputDateOfOrder() {
        return inputDateOfOrder;
    }
    public void setInputDateOfOrder(String inputDateOfOrder) {
        this.inputDateOfOrder = inputDateOfOrder;
    }
    public String getWeekOfDueDateForDelivery() {
        return weekOfDueDateForDelivery;
    }
    public void setWeekOfDueDateForDelivery(String weekOfDueDateForDelovery) {
        this.weekOfDueDateForDelivery = weekOfDueDateForDelovery;
    }
    public String getDealerReplyFlg() {
        return dealerReplyFlg;
    }
    public void setDealerReplyFlg(String dealerReplyFlg) {
        this.dealerReplyFlg = dealerReplyFlg;
    }
    public String getRandomNo() {
        return randomNo;
    }
    public void setRandomNo(String randomNo) {
        this.randomNo = randomNo;
    }

    /**
     * returns zero padded random no
     * @return
     */
    public String getRandomNoZeroPadding() {
        final String paddedNo = "0000000000" + this.randomNo;
        return paddedNo.substring(paddedNo.length() - 10, paddedNo.length());
    }
    
    public String getVinNo() {
        return vinNo;
    }
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }
    public String getStorageYardCode() {
        return storageYardCode;
    }
    public void setStorageYardCode(String storageYardCode) {
        this.storageYardCode = storageYardCode;
    }
    public String getFactoryCode() {
        return factoryCode;
    }
    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }
    public String getLineClass() {
        return lineClass;
    }
    public void setLineClass(String lineClass) {
        this.lineClass = lineClass;
    }
    public String getActualFinalOkDate() {
        return actualFinalOkDate;
    }
    public void setActualFinalOkDate(String actualFinalOkDate) {
        this.actualFinalOkDate = actualFinalOkDate;
    }
    public String getActualOfflineDate() {
        return actualOfflineDate;
    }
    public void setActualOfflineDate(String actualOfflineDate) {
        this.actualOfflineDate = actualOfflineDate;
    }
    public String getPlanFinalOkDate() {
        return planFinalOkDate;
    }
    public void setPlanFinalOkDate(String planFinalOkDate) {
        this.planFinalOkDate = planFinalOkDate;
    }
    public String getPlanOfflineDate() {
        return planOfflineDate;
    }
    public void setPlanOfflineDate(String planOfflineDate) {
        this.planOfflineDate = planOfflineDate;
    }
    public String getBolsaOrNot() {
        return bolsaOrNot;
    }
    public void setBolsaOrNot(String bolsaOrNot) {
        this.bolsaOrNot = bolsaOrNot;
    }

    public String getOfflineDateForSortNo() {
        return offlineDateForSortNo;
    }
    public void setOfflineDateForSortNo(String offlineDateForSortNo) {
        this.offlineDateForSortNo = offlineDateForSortNo;
    }
    public String getDsOrder() {
        return dsOrder;
    }
    public void setDsOrder(String dsOrder) {
        this.dsOrder = dsOrder;
    }
    public String getDealer() {
        return dealer;
    }
    public void setDealer(String dealer) {
        this.dealer = dealer;
    }
    public String getBolsaForSortNo() {
        return bolsaForSortNo;
    }
    public void setBolsaForSortNo(String bolsaForSortNo) {
        this.bolsaForSortNo = bolsaForSortNo;
    }
    public BigDecimal getSortNo() {
        return sortNo;
    }
    public void setSortNo(BigDecimal sortNo) {
        this.sortNo = sortNo;
    }
    public void setExecute(int execute) {
        this.execute = execute;
    }
    public void setAppliedInventory(int appliedInventory) {
        this.appliedInventory = appliedInventory;
    }
    public String getTrimmedOrderType() {
        return orderType.trim();
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((actualFinalOkDate == null) ? 0 : actualFinalOkDate
						.hashCode());
		result = prime
				* result
				+ ((actualOfflineDate == null) ? 0 : actualOfflineDate
						.hashCode());
		result = prime * result + appliedInventory;
		result = prime * result
				+ ((bolsaForSortNo == null) ? 0 : bolsaForSortNo.hashCode());
		result = prime * result
				+ ((bolsaOrNot == null) ? 0 : bolsaOrNot.hashCode());
		result = prime * result + ((dealer == null) ? 0 : dealer.hashCode());
		result = prime * result
				+ ((dealerCode == null) ? 0 : dealerCode.hashCode());
		result = prime * result
				+ ((dealerReplyFlg == null) ? 0 : dealerReplyFlg.hashCode());
		result = prime * result + ((dsOrder == null) ? 0 : dsOrder.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result + execute;
		result = prime * result
				+ ((factoryCode == null) ? 0 : factoryCode.hashCode());
		result = prime
				* result
				+ ((inputDateOfOrder == null) ? 0 : inputDateOfOrder.hashCode());
		result = prime * result
				+ ((lineClass == null) ? 0 : lineClass.hashCode());
		result = prime * result
				+ ((offlineDate == null) ? 0 : offlineDate.hashCode());
		result = prime
				* result
				+ ((offlineDateForSortNo == null) ? 0 : offlineDateForSortNo
						.hashCode());
		result = prime * result
				+ ((orderType == null) ? 0 : orderType.hashCode());
		result = prime * result
				+ ((planFinalOkDate == null) ? 0 : planFinalOkDate.hashCode());
		result = prime * result
				+ ((planOfflineDate == null) ? 0 : planOfflineDate.hashCode());
		result = prime * result
				+ ((productionYear == null) ? 0 : productionYear.hashCode());
		result = prime * result
				+ ((randomNo == null) ? 0 : randomNo.hashCode());
		result = prime
				* result
				+ ((reallocationPriorityNo == null) ? 0
						: reallocationPriorityNo.hashCode());
		result = prime * result + ((sortNo == null) ? 0 : sortNo.hashCode());
		result = prime * result
				+ ((storageYardCode == null) ? 0 : storageYardCode.hashCode());
		result = prime * result
				+ ((vehicleSeqId == null) ? 0 : vehicleSeqId.hashCode());
		result = prime * result + ((vinNo == null) ? 0 : vinNo.hashCode());
		result = prime
				* result
				+ ((weekOfDueDateForDelivery == null) ? 0
						: weekOfDueDateForDelivery.hashCode());
		return result;
	}
    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (actualFinalOkDate == null) {
			if (other.actualFinalOkDate != null)
				return false;
		} else if (!actualFinalOkDate.equals(other.actualFinalOkDate))
			return false;
		if (actualOfflineDate == null) {
			if (other.actualOfflineDate != null)
				return false;
		} else if (!actualOfflineDate.equals(other.actualOfflineDate))
			return false;
		if (appliedInventory != other.appliedInventory)
			return false;
		if (bolsaForSortNo == null) {
			if (other.bolsaForSortNo != null)
				return false;
		} else if (!bolsaForSortNo.equals(other.bolsaForSortNo))
			return false;
		if (bolsaOrNot == null) {
			if (other.bolsaOrNot != null)
				return false;
		} else if (!bolsaOrNot.equals(other.bolsaOrNot))
			return false;
		if (dealer == null) {
			if (other.dealer != null)
				return false;
		} else if (!dealer.equals(other.dealer))
			return false;
		if (dealerCode == null) {
			if (other.dealerCode != null)
				return false;
		} else if (!dealerCode.equals(other.dealerCode))
			return false;
		if (dealerReplyFlg == null) {
			if (other.dealerReplyFlg != null)
				return false;
		} else if (!dealerReplyFlg.equals(other.dealerReplyFlg))
			return false;
		if (dsOrder == null) {
			if (other.dsOrder != null)
				return false;
		} else if (!dsOrder.equals(other.dsOrder))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (execute != other.execute)
			return false;
		if (factoryCode == null) {
			if (other.factoryCode != null)
				return false;
		} else if (!factoryCode.equals(other.factoryCode))
			return false;
		if (inputDateOfOrder == null) {
			if (other.inputDateOfOrder != null)
				return false;
		} else if (!inputDateOfOrder.equals(other.inputDateOfOrder))
			return false;
		if (lineClass == null) {
			if (other.lineClass != null)
				return false;
		} else if (!lineClass.equals(other.lineClass))
			return false;
		if (offlineDate == null) {
			if (other.offlineDate != null)
				return false;
		} else if (!offlineDate.equals(other.offlineDate))
			return false;
		if (offlineDateForSortNo == null) {
			if (other.offlineDateForSortNo != null)
				return false;
		} else if (!offlineDateForSortNo.equals(other.offlineDateForSortNo))
			return false;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		if (planFinalOkDate == null) {
			if (other.planFinalOkDate != null)
				return false;
		} else if (!planFinalOkDate.equals(other.planFinalOkDate))
			return false;
		if (planOfflineDate == null) {
			if (other.planOfflineDate != null)
				return false;
		} else if (!planOfflineDate.equals(other.planOfflineDate))
			return false;
		if (productionYear == null) {
			if (other.productionYear != null)
				return false;
		} else if (!productionYear.equals(other.productionYear))
			return false;
		if (randomNo == null) {
			if (other.randomNo != null)
				return false;
		} else if (!randomNo.equals(other.randomNo))
			return false;
		if (reallocationPriorityNo == null) {
			if (other.reallocationPriorityNo != null)
				return false;
		} else if (!reallocationPriorityNo.equals(other.reallocationPriorityNo))
			return false;
		if (sortNo == null) {
			if (other.sortNo != null)
				return false;
		} else if (!sortNo.equals(other.sortNo))
			return false;
		if (storageYardCode == null) {
			if (other.storageYardCode != null)
				return false;
		} else if (!storageYardCode.equals(other.storageYardCode))
			return false;
		if (vehicleSeqId == null) {
			if (other.vehicleSeqId != null)
				return false;
		} else if (!vehicleSeqId.equals(other.vehicleSeqId))
			return false;
		if (vinNo == null) {
			if (other.vinNo != null)
				return false;
		} else if (!vinNo.equals(other.vinNo))
			return false;
		if (weekOfDueDateForDelivery == null) {
			if (other.weekOfDueDateForDelivery != null)
				return false;
		} else if (!weekOfDueDateForDelivery
				.equals(other.weekOfDueDateForDelivery))
			return false;
		return true;
	}
    public int getExecute() {
        return execute;
    }
    public int getAppliedInventory() {
        return appliedInventory;
    }
    @Override
	public String toString() {
		return "Order [productionYear=" + productionYear + ", vehicleSeqId="
				+ vehicleSeqId + ", dealerCode=" + dealerCode
				+ ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode + ", orderType="
				+ orderType + ", offlineDate=" + offlineDate
				+ ", reallocationPriorityNo=" + reallocationPriorityNo
				+ ", inputDateOfOrder=" + inputDateOfOrder
				+ ", weekOfDueDateForDelivery=" + weekOfDueDateForDelivery
				+ ", dealerReplyFlg=" + dealerReplyFlg + ", randomNo="
				+ randomNo + ", bolsaOrNot=" + bolsaOrNot + ", vinNo=" + vinNo
				+ ", storageYardCode=" + storageYardCode + ", factoryCode="
				+ factoryCode + ", lineClass=" + lineClass
				+ ", actualFinalOkDate=" + actualFinalOkDate
				+ ", actualOfflineDate=" + actualOfflineDate
				+ ", planFinalOkDate=" + planFinalOkDate + ", planOfflineDate="
				+ planOfflineDate + ", sortNo=" + sortNo
				+ ", offlineDateForSortNo=" + offlineDateForSortNo
				+ ", dsOrder=" + dsOrder + ", dealer=" + dealer
				+ ", bolsaForSortNo=" + bolsaForSortNo + ", execute=" + execute
				+ ", appliedInventory=" + appliedInventory + "]";
	}

    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", 
                vehicleSeqId,
                dealerCode,
                endItemModelCode,
                endItemColorCode,
                orderType,
                offlineDate,
                reallocationPriorityNo,
                inputDateOfOrder,
                weekOfDueDateForDelivery,
                dealerReplyFlg,
                randomNo,
                bolsaOrNot,productionYear);
    }
}
