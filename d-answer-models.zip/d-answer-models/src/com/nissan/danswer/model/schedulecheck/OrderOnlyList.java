package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * OrderOnlyList
 * @author SCSK
 *
 */
public class OrderOnlyList extends ArrayList<Order> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
