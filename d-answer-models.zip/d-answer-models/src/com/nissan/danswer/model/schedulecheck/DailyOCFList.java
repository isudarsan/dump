package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * DailyOCFList
 * <pre>
 * IN / OUT
 * </pre>
 * @author SCSK
 *
 */
public class DailyOCFList extends ArrayList<DailyOCF> {
	
	private static final long serialVersionUID = 1L;
	
	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (DailyOCF element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
