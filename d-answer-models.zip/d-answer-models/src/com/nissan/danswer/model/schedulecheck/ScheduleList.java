package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * ScheduleList
 * @author matsuda
 *
 */
public class ScheduleList extends ArrayList<Schedule> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (Schedule element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
