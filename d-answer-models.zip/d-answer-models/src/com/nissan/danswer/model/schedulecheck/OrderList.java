package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * OrderList
 * @author SCSK
 *
 */
public class OrderList extends ArrayList<Order> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (Order element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
