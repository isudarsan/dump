package com.nissan.danswer.model.schedulecheck;

import com.nissan.danswer.model.BaseModel;

/**
 * Order
 * <pre>
 * オーダー情報（月次・週次・日次）
 * </pre>
 * @author SCSK
 *
 */
public class Order extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;
	
	/** POR_CODE */
	private String porCode;
	
	/** PRODUCTION_FAMILY_CODE */
	private String productionFamilyCode;
	
	/** END_ITEM_MODEL_CODE */
	private String endItemModelCode;

	/** 
	 * END_ITEM_COLOR_CODE<br>
	 */
	private String endItemColorCode;
	
	/** PRODUCTION_ORDER_NO */
	private String productionOrderNo;
	
	/** DEALER_CODE */
	private String dealerCode;
	
	/**
	 * ORDER_TYPE
	 */
	private String orderType;
	
	/** ACCOUNT_NO */
	private String accountNo;
	
	/** ALLOCATION_PRIORITY */
	private String allocationPriority;
	
	/** 
	 * INPUT_DATE_OF_ORDER<BR>
	 * yyyyMMddHHMM
	 */
	private String inputDateOfOrder;
	
	/** WEEK_OF_DUE_DATE_FOR_DELIVERY */
	private String weekOfDueDateForDelivery;
	
	/** 
	 * DEALER_REPLY_FLG<br>
	 * <lo>
	 * <li>Accept:A
	 * <li>Change:C
	 * <li>Hold:H
	 * </lo>
	 */
	private String dealerReplyFlg;

	/** RANDOM_NO */
	private long randomNo;
	
	/** DISTRIBUTION_NO */
	private String distributionNo;
	
	/**
	 * WEEK_NO
	 * <lo>
	 * <li>Re-monthly:null
	 * <li>Weekly:not null
	 * <li>Daily:not null
	 * </lo>
	 */
	private String weekNo;
	
	/**
	 * DAY<br>
	 * yyyyMMdd
	 * <lo>
	 * <li>Re-monthly:null
	 * <li>Weekly:null
	 * <li>Daily(unfix):null,(fix):not null
	 * </lo>
	 */
	private String day;
	
	
	// for rule use below
	/** WEEK_NO_FOR_SORT */
	private String weekNoSort;
	
	/** DAY_FOR_SORT */
	private String daySort;
	
	/** WEEK_OF_DUE_DATE_FOR_DELIVERY_FOR_SORT */
	private String weekOfDueDateSort;
	
	/** INPUT_DATE_OF_ORDER_FOR_SORT */
	private String inputDateSort;
	
	/** DEALER_REPLY_FLG_FOR_SORT */
	private String dealerReplySort;
	
	/** SORT_KEY */
	private String sortKey;
	
	/** MIN_FLG */
	private boolean minFlg = false;
	
	/** ALLOCATION_NG_FLG */
	private boolean ngFlg = false;
	
	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public String getPorCode() {
		return porCode;
	}

	public void setPorCode(String porCode) {
		this.porCode = porCode;
	}

	public String getProductionFamilyCode() {
		return productionFamilyCode;
	}

	public void setProductionFamilyCode(String productionFamilyCode) {
		this.productionFamilyCode = productionFamilyCode;
	}

	public String getEndItemModelCode() {
		return endItemModelCode;
	}

	public void setEndItemModelCode(String endItemModelCode) {
		this.endItemModelCode = endItemModelCode;
	}

	public String getEndItemColorCode() {
		return endItemColorCode;
	}

	public void setEndItemColorCode(String endItemColorCode) {
		this.endItemColorCode = endItemColorCode;
	}

	public String getOrderType() {
		return orderType;
	}
	
	/**
	 * trimをかけてOrderTypeを返却
	 * @return
	 */
	public String getOrderTypeTrim() {
		return orderType.trim();
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getProductionOrderNo() {
		return productionOrderNo;
	}

	public void setProductionOrderNo(String productionOrderNo) {
		this.productionOrderNo = productionOrderNo;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAllocationPriority() {
		return allocationPriority;
	}

	public void setAllocationPriority(String allocationPriority) {
		this.allocationPriority = allocationPriority;
	}

	public String getInputDateOfOrder() {
		return inputDateOfOrder;
	}

	public void setInputDateOfOrder(String inputDateOfOrder) {
		this.inputDateOfOrder = inputDateOfOrder;
	}

	public String getWeekOfDueDateForDelivery() {
		return weekOfDueDateForDelivery;
	}

	public void setWeekOfDueDateForDelivery(String weekOfDueDateForDelivery) {
		this.weekOfDueDateForDelivery = weekOfDueDateForDelivery;
	}

	public String getDealerReplyFlg() {
		return dealerReplyFlg;
	}

	public void setDealerReplyFlg(String dealerReplyFlg) {
		this.dealerReplyFlg = dealerReplyFlg;
	}

	public long getRandomNo() {
		return randomNo;
	}

	public void setRandomNo(long randomNo) {
		this.randomNo = randomNo;
	}

	/**
	 * 頭ゼロ埋め10桁編集
	 * @return
	 */
	public String getRandomNoZeroPadding() {
		StringBuffer zeroSb = new StringBuffer();
		for (int i = 10 - String.valueOf(randomNo).length(); i > 0; i--) {
			zeroSb.append("0");
		}
		return zeroSb.toString() + randomNo;
	}
	
	public String getDistributionNo() {
		return distributionNo;
	}

	public void setDistributionNo(String distributionNo) {
		this.distributionNo = distributionNo;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getWeekNoSort() {
		return weekNoSort;
	}

	public void setWeekNoSort(String weekNoSort) {
		this.weekNoSort = weekNoSort;
	}

	public String getDaySort() {
		return daySort;
	}

	public void setDaySort(String daySort) {
		this.daySort = daySort;
	}

	public String getWeekOfDueDateSort() {
		return weekOfDueDateSort;
	}

	public void setWeekOfDueDateSort(String weekOfDueDateSort) {
		this.weekOfDueDateSort = weekOfDueDateSort;
	}

	public String getInputDateSort() {
		return inputDateSort;
	}

	public void setInputDateSort(String inputDateSort) {
		this.inputDateSort = inputDateSort;
	}

	public String getDealerReplySort() {
		return dealerReplySort;
	}

	public void setDealerReplySort(String dealerReplySort) {
		this.dealerReplySort = dealerReplySort;
	}

	public String getSortKey() {
		return sortKey;
	}

	public void setSortKey(String sortKey) {
		this.sortKey = sortKey;
	}

	public boolean isMinFlg() {
		return minFlg;
	}

	public void setMinFlg(boolean minFlg) {
		this.minFlg = minFlg;
	}

	public boolean isNgFlg() {
		return ngFlg;
	}

	public void setNgFlg(boolean ngFlg) {
		this.ngFlg = ngFlg;
	}
	
	@Override
	public String toString() {
		return "Order [planYearMonth=" + planYearMonth + ", carSeries="
				+ carSeries + ", porCode=" + porCode
				+ ", productionFamilyCode=" + productionFamilyCode
				+ ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode
				+ ", productionOrderNo=" + productionOrderNo + ", dealerCode="
				+ dealerCode + ", orderType=" + orderType + ", accountNo="
				+ accountNo + ", allocationPriority=" + allocationPriority
				+ ", inputDateOfOrder=" + inputDateOfOrder
				+ ", weekOfDueDateForDelivery=" + weekOfDueDateForDelivery
				+ ", dealerReplyFlg=" + dealerReplyFlg + ", randomNo="
				+ randomNo + ", distributionNo=" + distributionNo + ", weekNo="
				+ weekNo + ", day=" + day + ", weekNoSort=" + weekNoSort
				+ ", daySort=" + daySort + ", weekOfDueDateSort="
				+ weekOfDueDateSort + ", inputDateSort=" + inputDateSort
				+ ", dealerReplySort=" + dealerReplySort + ", sortKey="
				+ sortKey + ", minFlg=" + minFlg + ", ngFlg=" + ngFlg + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accountNo == null) ? 0 : accountNo.hashCode());
		result = prime
				* result
				+ ((allocationPriority == null) ? 0 : allocationPriority
						.hashCode());
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result + ((day == null) ? 0 : day.hashCode());
		result = prime * result + ((daySort == null) ? 0 : daySort.hashCode());
		result = prime * result
				+ ((dealerCode == null) ? 0 : dealerCode.hashCode());
		result = prime * result
				+ ((dealerReplyFlg == null) ? 0 : dealerReplyFlg.hashCode());
		result = prime * result
				+ ((dealerReplySort == null) ? 0 : dealerReplySort.hashCode());
		result = prime * result
				+ ((distributionNo == null) ? 0 : distributionNo.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime
				* result
				+ ((inputDateOfOrder == null) ? 0 : inputDateOfOrder.hashCode());
		result = prime * result
				+ ((inputDateSort == null) ? 0 : inputDateSort.hashCode());
		result = prime * result + (minFlg ? 1231 : 1237);
		result = prime * result + (ngFlg ? 1231 : 1237);
		result = prime * result
				+ ((orderType == null) ? 0 : orderType.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
		result = prime
				* result
				+ ((productionFamilyCode == null) ? 0 : productionFamilyCode
						.hashCode());
		result = prime
				* result
				+ ((productionOrderNo == null) ? 0 : productionOrderNo
						.hashCode());
		result = prime * result + (int) (randomNo ^ (randomNo >>> 32));
		result = prime * result + ((sortKey == null) ? 0 : sortKey.hashCode());
		result = prime * result + ((weekNo == null) ? 0 : weekNo.hashCode());
		result = prime * result
				+ ((weekNoSort == null) ? 0 : weekNoSort.hashCode());
		result = prime
				* result
				+ ((weekOfDueDateForDelivery == null) ? 0
						: weekOfDueDateForDelivery.hashCode());
		result = prime
				* result
				+ ((weekOfDueDateSort == null) ? 0 : weekOfDueDateSort
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (accountNo == null) {
			if (other.accountNo != null)
				return false;
		} else if (!accountNo.equals(other.accountNo))
			return false;
		if (allocationPriority == null) {
			if (other.allocationPriority != null)
				return false;
		} else if (!allocationPriority.equals(other.allocationPriority))
			return false;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (day == null) {
			if (other.day != null)
				return false;
		} else if (!day.equals(other.day))
			return false;
		if (daySort == null) {
			if (other.daySort != null)
				return false;
		} else if (!daySort.equals(other.daySort))
			return false;
		if (dealerCode == null) {
			if (other.dealerCode != null)
				return false;
		} else if (!dealerCode.equals(other.dealerCode))
			return false;
		if (dealerReplyFlg == null) {
			if (other.dealerReplyFlg != null)
				return false;
		} else if (!dealerReplyFlg.equals(other.dealerReplyFlg))
			return false;
		if (dealerReplySort == null) {
			if (other.dealerReplySort != null)
				return false;
		} else if (!dealerReplySort.equals(other.dealerReplySort))
			return false;
		if (distributionNo == null) {
			if (other.distributionNo != null)
				return false;
		} else if (!distributionNo.equals(other.distributionNo))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (inputDateOfOrder == null) {
			if (other.inputDateOfOrder != null)
				return false;
		} else if (!inputDateOfOrder.equals(other.inputDateOfOrder))
			return false;
		if (inputDateSort == null) {
			if (other.inputDateSort != null)
				return false;
		} else if (!inputDateSort.equals(other.inputDateSort))
			return false;
		if (minFlg != other.minFlg)
			return false;
		if (ngFlg != other.ngFlg)
			return false;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (porCode == null) {
			if (other.porCode != null)
				return false;
		} else if (!porCode.equals(other.porCode))
			return false;
		if (productionFamilyCode == null) {
			if (other.productionFamilyCode != null)
				return false;
		} else if (!productionFamilyCode.equals(other.productionFamilyCode))
			return false;
		if (productionOrderNo == null) {
			if (other.productionOrderNo != null)
				return false;
		} else if (!productionOrderNo.equals(other.productionOrderNo))
			return false;
		if (randomNo != other.randomNo)
			return false;
		if (sortKey == null) {
			if (other.sortKey != null)
				return false;
		} else if (!sortKey.equals(other.sortKey))
			return false;
		if (weekNo == null) {
			if (other.weekNo != null)
				return false;
		} else if (!weekNo.equals(other.weekNo))
			return false;
		if (weekNoSort == null) {
			if (other.weekNoSort != null)
				return false;
		} else if (!weekNoSort.equals(other.weekNoSort))
			return false;
		if (weekOfDueDateForDelivery == null) {
			if (other.weekOfDueDateForDelivery != null)
				return false;
		} else if (!weekOfDueDateForDelivery
				.equals(other.weekOfDueDateForDelivery))
			return false;
		if (weekOfDueDateSort == null) {
			if (other.weekOfDueDateSort != null)
				return false;
		} else if (!weekOfDueDateSort.equals(other.weekOfDueDateSort))
			return false;
		return true;
	}
	
	public String outCSV() {
		StringBuffer sb = new StringBuffer(64);

		sb.append(System.getProperty("line.separator"));
		sb.append(planYearMonth).append(",");
		sb.append(carSeries).append(",");
		sb.append(porCode).append(",");
		sb.append(productionFamilyCode).append(",");
		sb.append(endItemModelCode).append(",");
		sb.append(endItemColorCode).append(",");
		sb.append(productionOrderNo).append(",");
		sb.append(dealerCode).append(",");
		sb.append(orderType).append(",");
		sb.append(accountNo).append(",");
		sb.append(allocationPriority).append(",");
		sb.append(inputDateOfOrder).append(",");
		sb.append(weekOfDueDateForDelivery).append(",");
		sb.append(dealerReplyFlg).append(",");
		sb.append(randomNo).append(",");
		sb.append(distributionNo).append(",");
		sb.append(weekNo).append(",");
		sb.append(day);
		
		return sb.toString();
	}
}
