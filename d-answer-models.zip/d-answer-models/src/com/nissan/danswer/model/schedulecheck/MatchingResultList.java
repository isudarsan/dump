package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * MatchingResultList
 * @author matsuda
 *
 */
public class MatchingResultList extends ArrayList<MatchingResult> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
