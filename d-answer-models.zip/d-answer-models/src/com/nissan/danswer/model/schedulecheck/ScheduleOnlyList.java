package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * ScheduleOnlyList
 * @author matsuda
 *
 */
public class ScheduleOnlyList extends ArrayList<Schedule> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
