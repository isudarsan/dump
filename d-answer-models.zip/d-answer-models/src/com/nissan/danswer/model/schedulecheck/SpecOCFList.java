package com.nissan.danswer.model.schedulecheck;

import java.util.ArrayList;

/**
 * SpecOCFList
 * @author SCSK
 *
 */
public class SpecOCFList extends ArrayList<SpecOCF> {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (SpecOCF element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
