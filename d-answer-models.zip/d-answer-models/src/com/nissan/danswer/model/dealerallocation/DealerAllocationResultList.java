package com.nissan.danswer.model.dealerallocation;

import java.util.ArrayList;

public class DealerAllocationResultList extends ArrayList<DealerAllocationResult> {
    private static final long serialVersionUID = 7815788412121194289L;
}
