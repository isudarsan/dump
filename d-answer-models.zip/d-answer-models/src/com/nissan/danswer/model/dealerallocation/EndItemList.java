package com.nissan.danswer.model.dealerallocation;

import java.util.ArrayList;

public class EndItemList extends ArrayList<EndItem> {

    private static final long serialVersionUID = -2209184620941263169L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted EndItem Data(csv format) --------%n");
        out.append("#PLAN_YEAR_MONTH,CAR_SERIES,POR_CODE,END_ITEM_MODEL_CODE,PRODUCTION_FAMILY_CODE,QTY%n");

        for (EndItem ei : this) {
            out.append(ei.toCSV());
            out.append("%n");
        }

        out.append("------------------------------------------");
        
        return out.toString();
    }
}
