package com.nissan.danswer.model.dealerallocation;

import com.nissan.danswer.model.BaseModel;

public class Dealer extends BaseModel {
    private static final long serialVersionUID = 249210965693171177L;

    public Dealer() {}

    private String planYearMonth;
	private String carSeries;
	private String porCode;
	private String endItemModelCode;
	private String productionFamilyCode;
	private String dealerCode;
	private double daysSupply;
	private double targetDaysSupply;
    private double dailyRetail;
	
    @Override
    public String toString() {
        return "Dealer "
                +  "[planYearMonth=" + planYearMonth
                + ", carSeries=" + carSeries
                + ", porCode=" + porCode
                + ", endItemModelCode=" + endItemModelCode
                + ", productionFamilyCode=" + productionFamilyCode
                + ", dealerCode=" + dealerCode
                + ", daysSupply=" + daysSupply
                + ", targetDaysSupply=" + targetDaysSupply
                + ", dailyRetail=" + dailyRetail
                + "]";
    }
    
    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s,%s,%.2f,%.2f,%.2f", 
                planYearMonth,
                carSeries,
                porCode,
                endItemModelCode,
                productionFamilyCode,
                dealerCode,
                daysSupply,
                targetDaysSupply,
                dailyRetail);
    }

    public String getPlanYearMonth() {
        return planYearMonth;
    }

    public void setPlanYearMonth(String planYearMonth) {
        this.planYearMonth = planYearMonth;
    }

    public String getCarSeries() {
        return carSeries;
    }

    public void setCarSeries(String carSeries) {
        this.carSeries = carSeries;
    }

    public String getPorCode() {
        return porCode;
    }

    public void setPorCode(String porCode) {
        this.porCode = porCode;
    }

    public String getEndItemModelCode() {
        return endItemModelCode;
    }

    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }

    public String getProductionFamilyCode() {
        return productionFamilyCode;
    }

    public void setProductionFamilyCode(String productionFamilyCode) {
        this.productionFamilyCode = productionFamilyCode;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public double getDaysSupply() {
        return daysSupply;
    }

    public void setDaysSupply(double daysSupply) {
        this.daysSupply = daysSupply;
    }

    public double getTargetDaysSupply() {
        return targetDaysSupply;
    }

    public void setTargetDaysSupply(double targetDaysSupply) {
        this.targetDaysSupply = targetDaysSupply;
    }

    public double getDailyRetail() {
        return dailyRetail;
    }

    public void setDailyRetail(double dailyRetail) {
        this.dailyRetail = dailyRetail;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((carSeries == null) ? 0 : carSeries.hashCode());
        long temp;
        temp = Double.doubleToLongBits(dailyRetail);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(daysSupply);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result
                + ((dealerCode == null) ? 0 : dealerCode.hashCode());
        result = prime
                * result
                + ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
        result = prime * result
                + ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
        result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
        result = prime
                * result
                + ((productionFamilyCode == null) ? 0 : productionFamilyCode
                        .hashCode());
        temp = Double.doubleToLongBits(targetDaysSupply);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Dealer other = (Dealer) obj;
        if (carSeries == null) {
            if (other.carSeries != null)
                return false;
        } else if (!carSeries.equals(other.carSeries))
            return false;
        if (Double.doubleToLongBits(dailyRetail) != Double
                .doubleToLongBits(other.dailyRetail))
            return false;
        if (Double.doubleToLongBits(daysSupply) != Double
                .doubleToLongBits(other.daysSupply))
            return false;
        if (dealerCode == null) {
            if (other.dealerCode != null)
                return false;
        } else if (!dealerCode.equals(other.dealerCode))
            return false;
        if (endItemModelCode == null) {
            if (other.endItemModelCode != null)
                return false;
        } else if (!endItemModelCode.equals(other.endItemModelCode))
            return false;
        if (planYearMonth == null) {
            if (other.planYearMonth != null)
                return false;
        } else if (!planYearMonth.equals(other.planYearMonth))
            return false;
        if (porCode == null) {
            if (other.porCode != null)
                return false;
        } else if (!porCode.equals(other.porCode))
            return false;
        if (productionFamilyCode == null) {
            if (other.productionFamilyCode != null)
                return false;
        } else if (!productionFamilyCode.equals(other.productionFamilyCode))
            return false;
        if (Double.doubleToLongBits(targetDaysSupply) != Double
                .doubleToLongBits(other.targetDaysSupply))
            return false;
        return true;
    }
}
