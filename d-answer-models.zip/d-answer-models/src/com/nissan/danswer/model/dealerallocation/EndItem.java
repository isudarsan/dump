package com.nissan.danswer.model.dealerallocation;

import com.nissan.danswer.model.BaseModel;

public class EndItem extends BaseModel {
    private static final long serialVersionUID = -1556997903353250560L;

    public EndItem() {}

    private String planYearMonth;
	private String carSeries;
	private String porCode;
	private String endItemModelCode;
	private String productionFamilyCode;
	private int qty;
    
//	private int lineno;
	
    @Override
    public String toString() {
        return "EndItem " // + (lineno - 1)
                + "[planYearMonth=" + planYearMonth
                + ", carSeries=" + carSeries
                + ", porCode=" + porCode
                + ", endItemModelCode=" + endItemModelCode
                + ", qty=" + qty
                + "]";
    }

    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s,%d", 
                planYearMonth,
                carSeries,
                porCode,
                endItemModelCode,
                productionFamilyCode,
                qty);
    }

    public String getPlanYearMonth() {
        return planYearMonth;
    }

    public void setPlanYearMonth(String planYearMonth) {
        this.planYearMonth = planYearMonth;
    }

    public String getCarSeries() {
        return carSeries;
    }

    public void setCarSeries(String carSeries) {
        this.carSeries = carSeries;
    }

    public String getEndItemModelCode() {
        return endItemModelCode;
    }

    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }

    public String getProductionFamilyCode() {
        return productionFamilyCode;
    }

    public void setProductionFamilyCode(String productionFamilyCode) {
        this.productionFamilyCode = productionFamilyCode;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

//    public int getLineno() {
//        return lineno;
//    }
//
//    public void setLineno(int lineno) {
//        this.lineno = lineno;
//    }

    public String getPorCode() {
        return porCode;
    }

    public void setPorCode(String porCode) {
        this.porCode = porCode;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((carSeries == null) ? 0 : carSeries.hashCode());
        result = prime
                * result
                + ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
        result = prime * result
                + ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
        result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
        result = prime
                * result
                + ((productionFamilyCode == null) ? 0 : productionFamilyCode
                        .hashCode());
        result = prime * result + qty;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EndItem other = (EndItem) obj;
        if (carSeries == null) {
            if (other.carSeries != null)
                return false;
        } else if (!carSeries.equals(other.carSeries))
            return false;
        if (endItemModelCode == null) {
            if (other.endItemModelCode != null)
                return false;
        } else if (!endItemModelCode.equals(other.endItemModelCode))
            return false;
        if (planYearMonth == null) {
            if (other.planYearMonth != null)
                return false;
        } else if (!planYearMonth.equals(other.planYearMonth))
            return false;
        if (porCode == null) {
            if (other.porCode != null)
                return false;
        } else if (!porCode.equals(other.porCode))
            return false;
        if (productionFamilyCode == null) {
            if (other.productionFamilyCode != null)
                return false;
        } else if (!productionFamilyCode.equals(other.productionFamilyCode))
            return false;
        if (qty != other.qty)
            return false;
        return true;
    }
}
