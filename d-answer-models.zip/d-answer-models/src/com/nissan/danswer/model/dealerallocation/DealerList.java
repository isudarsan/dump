package com.nissan.danswer.model.dealerallocation;

import java.util.ArrayList;

public class DealerList extends ArrayList<Dealer> {

    private static final long serialVersionUID = -5686127754620749273L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted Dealer Data(csv format) --------%n");
        out.append("#PLAN_YEAR_MONTH,CAR_SERIES,POR_CODE,END_ITEM_MODEL_CODE,PRODUCTION_FAMILY_CODE,DEALER_CODE,DAYS_SUPPLY,TARGET_DAYS_SUPPLY,DAILY_RETAIL%n");

        for (Dealer dl : this) {
            out.append(dl.toCSV());
            out.append("%n");
        }

        out.append("------------------------------------------");
        
        return out.toString();
    }
}
