package com.nissan.danswer.model;

/**
 * DANSWER 定数クラス
 * @author SCSK
 *
 */
public final class DanswerConstant {

	/** SYAKEI_FRAME_CODE */
	public static final String SYAKEI_FRAME_CODE = "00";
	
	/** ORDER_TYPE(SP) */
	public static final String ORDER_TYPE_SP = "SP";
	/** ORDER_TYPE(DS) */
	public static final String ORDER_TYPE_DS = "DS";
	/** ORDER_TYPE(DL) */
	public static final String ORDER_TYPE_DL = "DL";
    
	/** DEALER_REPLY_FLG(A:Accept) */
	public static final String DEALER_REPLY_FLG_ACCEPT = "A";
	/** DEALER_REPLY_FLG(H:Hold) */
	public static final String DEALER_REPLY_FLG_HOLD = "H";
	/** DEALER_REPLY_FLG(C:Change) */
	public static final String DEALER_REPLY_FLG_CHANGE = "C";
	
	/** SLOT_METHOD (usualSlot only) */
	public static final int SLOT_METHOD_USUAL = 1;
	/** SLOT_METHOD (usualSlot and forceSlot) */
	public static final int SLOT_METHOD_FORCE = 2;
	
	// Singleton
	private DanswerConstant() {}
}
