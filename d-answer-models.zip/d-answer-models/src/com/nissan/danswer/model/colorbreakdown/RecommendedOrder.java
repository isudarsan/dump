package com.nissan.danswer.model.colorbreakdown;

import com.nissan.danswer.model.BaseModel;

/**
 * RecommendedOrder
 * (Dealer Allocated Order)
 * @author matsuda
 *
 */
public class RecommendedOrder extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;

	/** POR_CODE */
	private String porCode;
	
	/** PRODUCTION_FAMILY_CODE */
	private String productionFamilyCode;
	
	/** DEALER_CODE */
	private String dealerCode;
	
	/** END_ITEM_MODEL_CODE */
	private String endItemModelCode;
	
	/** QTY */
	private int qty;
	
	/** (rule use) */
	private Integer differenceQty;

	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public String getPorCode() {
		return porCode;
	}

	public void setPorCode(String porCode) {
		this.porCode = porCode;
	}

	public String getProductionFamilyCode() {
		return productionFamilyCode;
	}

	public void setProductionFamilyCode(String productionFamilyCode) {
		this.productionFamilyCode = productionFamilyCode;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getEndItemModelCode() {
		return endItemModelCode;
	}

	public void setEndItemModelCode(String endItemModelCode) {
		this.endItemModelCode = endItemModelCode;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public Integer getDifferenceQty() {
		return differenceQty;
	}

	public void setDifferenceQty(Integer differenceQty) {
		this.differenceQty = differenceQty;
	}

	@Override
	public String toString() {
		return "RecommendedOrder [planYearMonth=" + planYearMonth
				+ ", carSeries=" + carSeries + ", porCode=" + porCode
				+ ", productionFamilyCode=" + productionFamilyCode
				+ ", dealerCode=" + dealerCode + ", endItemModelCode="
				+ endItemModelCode + ", qty=" + qty + ", differenceQty="
				+ differenceQty + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result
				+ ((dealerCode == null) ? 0 : dealerCode.hashCode());
		result = prime * result
				+ ((differenceQty == null) ? 0 : differenceQty.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
		result = prime
				* result
				+ ((productionFamilyCode == null) ? 0 : productionFamilyCode
						.hashCode());
		result = prime * result + qty;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RecommendedOrder other = (RecommendedOrder) obj;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (dealerCode == null) {
			if (other.dealerCode != null)
				return false;
		} else if (!dealerCode.equals(other.dealerCode))
			return false;
		if (differenceQty == null) {
			if (other.differenceQty != null)
				return false;
		} else if (!differenceQty.equals(other.differenceQty))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (porCode == null) {
			if (other.porCode != null)
				return false;
		} else if (!porCode.equals(other.porCode))
			return false;
		if (productionFamilyCode == null) {
			if (other.productionFamilyCode != null)
				return false;
		} else if (!productionFamilyCode.equals(other.productionFamilyCode))
			return false;
		if (qty != other.qty)
			return false;
		return true;
	}

	public String outCSV() {
		StringBuffer sb = new StringBuffer(64);
		
		sb.append(System.getProperty("line.separator"));
		sb.append(this.planYearMonth).append(",");
		sb.append(this.carSeries).append(",");
		sb.append(this.porCode).append(",");
		sb.append(this.productionFamilyCode).append(",");
		sb.append(this.dealerCode).append(",");
		sb.append(this.endItemModelCode).append(",");
		sb.append(this.qty);
		
		return sb.toString();		
	}
}
