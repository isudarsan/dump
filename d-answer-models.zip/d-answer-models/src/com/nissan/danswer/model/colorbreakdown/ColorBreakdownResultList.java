package com.nissan.danswer.model.colorbreakdown;

import java.util.ArrayList;

/**
 * ColorBreakdownResultList
 * @author SCSK
 *
 */
public class ColorBreakdownResultList extends ArrayList<ColorBreakdownResult> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
