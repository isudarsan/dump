package com.nissan.danswer.model.colorbreakdown;

import com.nissan.danswer.model.BaseModel;

/**
 * ProductionOrderImport
 * @author matsuda
 *
 */
public class ProductionOrderImport extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;

	/** POR_CODE */
	private String porCode;
	
	/** PRODUCTION_FAMILY_CODE */
	private String productionFamilyCode;
	
	/** END_ITEM_MODEL_CODE */
	private String endItemModelCode;

	/** END_ITEM_COLOR_CODE */
	private String endItemColorCode;
	
	/** QTY */
	private int qty;
	
	/** (rule use)カラー確定前の超過数 */
	private Integer exceedQty;
	
	/** (rule use)カラー確定後の余り数 */
	private Integer remainingQty;
	
	/** (rule use)カラー振替処理完了フラグ */
	private boolean normalColorChangeDone = false;

	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public String getPorCode() {
		return porCode;
	}

	public void setPorCode(String porCode) {
		this.porCode = porCode;
	}

	public String getProductionFamilyCode() {
		return productionFamilyCode;
	}

	public void setProductionFamilyCode(String productionFamilyCode) {
		this.productionFamilyCode = productionFamilyCode;
	}

	public String getEndItemModelCode() {
		return endItemModelCode;
	}

	public void setEndItemModelCode(String endItemModelCode) {
		this.endItemModelCode = endItemModelCode;
	}

	public String getEndItemColorCode() {
		return endItemColorCode;
	}

	public void setEndItemColorCode(String endItemColorCode) {
		this.endItemColorCode = endItemColorCode;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public Integer getExceedQty() {
		return exceedQty;
	}

	public void setExceedQty(Integer exceedQty) {
		this.exceedQty = exceedQty;
	}

	public Integer getRemainingQty() {
		return remainingQty;
	}

	public void setRemainingQty(Integer remainingQty) {
		this.remainingQty = remainingQty;
	}

	public boolean isNormalColorChangeDone() {
		return normalColorChangeDone;
	}

	public void setNormalColorChangeDone(boolean normalColorChangeDone) {
		this.normalColorChangeDone = normalColorChangeDone;
	}

	@Override
	public String toString() {
		return "ProductionOrderImport [planYearMonth=" + planYearMonth
				+ ", carSeries=" + carSeries + ", porCode=" + porCode
				+ ", productionFamilyCode=" + productionFamilyCode
				+ ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode + ", qty=" + qty
				+ ", exceedQty=" + exceedQty + ", remainingQty="
				+ remainingQty + ", normalColorChangeDone="
				+ normalColorChangeDone + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result
				+ ((exceedQty == null) ? 0 : exceedQty.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result + (normalColorChangeDone ? 1231 : 1237);
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
		result = prime
				* result
				+ ((productionFamilyCode == null) ? 0 : productionFamilyCode
						.hashCode());
		result = prime * result + qty;
		result = prime * result
				+ ((remainingQty == null) ? 0 : remainingQty.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductionOrderImport other = (ProductionOrderImport) obj;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (exceedQty == null) {
			if (other.exceedQty != null)
				return false;
		} else if (!exceedQty.equals(other.exceedQty))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (normalColorChangeDone != other.normalColorChangeDone)
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (porCode == null) {
			if (other.porCode != null)
				return false;
		} else if (!porCode.equals(other.porCode))
			return false;
		if (productionFamilyCode == null) {
			if (other.productionFamilyCode != null)
				return false;
		} else if (!productionFamilyCode.equals(other.productionFamilyCode))
			return false;
		if (qty != other.qty)
			return false;
		if (remainingQty == null) {
			if (other.remainingQty != null)
				return false;
		} else if (!remainingQty.equals(other.remainingQty))
			return false;
		return true;
	}

	public String outCSV() {
		StringBuffer sb = new StringBuffer(64);
		
		sb.append(System.getProperty("line.separator"));
		sb.append(planYearMonth).append(",");
		sb.append(carSeries).append(",");
		sb.append(porCode).append(",");
		sb.append(productionFamilyCode).append(",");
		sb.append(endItemModelCode).append(",");
		sb.append(endItemColorCode).append(",");
		sb.append(qty);
		
		return sb.toString();		
	}
}
