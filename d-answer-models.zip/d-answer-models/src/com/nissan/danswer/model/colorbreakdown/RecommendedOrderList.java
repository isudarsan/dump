package com.nissan.danswer.model.colorbreakdown;

import java.util.ArrayList;

/**
 * RecommendedOrderList
 * @author SCSK
 *
 */
public class RecommendedOrderList extends ArrayList<RecommendedOrder> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (RecommendedOrder element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
