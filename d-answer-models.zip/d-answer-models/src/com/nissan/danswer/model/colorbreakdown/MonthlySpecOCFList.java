package com.nissan.danswer.model.colorbreakdown;

import java.util.ArrayList;

/**
 * MonthlySpecOCFList
 * @author SCSK
 *
 */
public class MonthlySpecOCFList extends ArrayList<MonthlySpecOCF> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (MonthlySpecOCF element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
