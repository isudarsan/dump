package com.nissan.danswer.model.colorbreakdown;

import java.util.ArrayList;

/**
 * ColorRatioList
 * @author SCSK
 *
 */
public class ColorRatioList extends ArrayList<ColorRatio> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (ColorRatio element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
