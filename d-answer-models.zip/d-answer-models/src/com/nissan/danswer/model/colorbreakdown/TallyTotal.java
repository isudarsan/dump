package com.nissan.danswer.model.colorbreakdown;

import com.nissan.danswer.model.BaseModel;

/**
 * TallyTotal
 * @author SCSK
 *
 */
public class TallyTotal extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;
	
	/** POR_CODE */
	private String porCode;
	
	/** PRODUCTION_FAMILY_CODE */
	private String productionFamilyCode;
	
	/** DEALER_CODE */
	private String dealerCode;
	
	/** END_ITEM_MODEL_CODE */
	private String endItemModelCode;
	
	/** END_ITEM_COLOR_CODE */
	private String endItemColorCode;
	
	/**
	 * for rule use<br>
	 * Tally計算トータルカウント
	 */
	private int totalCount = 0;
	
	/**
	 * for rule use<br>
	 * Tally計算カレントカウント
	 */
	private int currentCount = 0;
	
	/**
	 * for rule use<br>
	 * (National rule)<br>
	 * 0:販社配分後の調整<br>
	 * 1:OCF枠内におさめるための調整<br>
	 * 2:カラー振替<br>
	 * (Imported rule)<br>
	 * 0:販社配分後の調整<br>
	 * 1:カラー確定<br>
	 * 2:カラー振替（希望ディーラーへ)<br>
	 * 3:カラー振替(強制)
	 */
	private int tallyKind;
	
	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public String getPorCode() {
		return porCode;
	}

	public void setPorCode(String porCode) {
		this.porCode = porCode;
	}

	public String getProductionFamilyCode() {
		return productionFamilyCode;
	}

	public void setProductionFamilyCode(String productionFamilyCode) {
		this.productionFamilyCode = productionFamilyCode;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getEndItemModelCode() {
		return endItemModelCode;
	}

	public void setEndItemModelCode(String endItemModelCode) {
		this.endItemModelCode = endItemModelCode;
	}

	public String getEndItemColorCode() {
		return endItemColorCode;
	}

	public void setEndItemColorCode(String endItemColorCode) {
		this.endItemColorCode = endItemColorCode;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getCurrentCount() {
		return currentCount;
	}

	public void setCurrentCount(int currentNo) {
		this.currentCount = currentNo;
	}

	public int getTallyKind() {
		return tallyKind;
	}

	public void setTallyKind(int tallyKind) {
		this.tallyKind = tallyKind;
	}

	@Override
	public String toString() {
		return "TallyTotal [planYearMonth=" + planYearMonth + ", carSeries="
				+ carSeries + ", porCode=" + porCode
				+ ", productionFamilyCode=" + productionFamilyCode
				+ ", dealerCode=" + dealerCode + ", endItemModelCode="
				+ endItemModelCode + ", endItemColorCode=" + endItemColorCode
				+ ", totalCount=" + totalCount + ", currentCount="
				+ currentCount + ", tallyKind=" + tallyKind + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result + currentCount;
		result = prime * result
				+ ((dealerCode == null) ? 0 : dealerCode.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
		result = prime
				* result
				+ ((productionFamilyCode == null) ? 0 : productionFamilyCode
						.hashCode());
		result = prime * result + tallyKind;
		result = prime * result + totalCount;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TallyTotal other = (TallyTotal) obj;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (currentCount != other.currentCount)
			return false;
		if (dealerCode == null) {
			if (other.dealerCode != null)
				return false;
		} else if (!dealerCode.equals(other.dealerCode))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (porCode == null) {
			if (other.porCode != null)
				return false;
		} else if (!porCode.equals(other.porCode))
			return false;
		if (productionFamilyCode == null) {
			if (other.productionFamilyCode != null)
				return false;
		} else if (!productionFamilyCode.equals(other.productionFamilyCode))
			return false;
		if (tallyKind != other.tallyKind)
			return false;
		if (totalCount != other.totalCount)
			return false;
		return true;
	}

}
