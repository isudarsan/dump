package com.nissan.danswer.model.colorbreakdown;

import java.util.ArrayList;

public class ProductionOrderImportList extends ArrayList<ProductionOrderImport> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (ProductionOrderImport element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
