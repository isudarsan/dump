package com.nissan.danswer.model;

import java.io.Serializable;

public abstract class BaseModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3063305310629590881L;

	public abstract int hashCode();
	
	public abstract boolean equals(Object obj);
}
