package com.nissan.danswer.model.eibreakdown;

import java.util.ArrayList;

/**
 * EndItemRatioList
 * <pre>
 * EndItemRatio情報はこのクラスにセットされた形でルールに渡され、ルール内で展開する
 * </pre>
 * @author SCSK
 *
 */
public class EndItemRatioList extends ArrayList<EndItemRatio> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (EndItemRatio element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
