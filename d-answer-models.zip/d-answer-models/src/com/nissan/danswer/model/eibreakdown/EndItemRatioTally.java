package com.nissan.danswer.model.eibreakdown;

import java.util.List;

import com.nissan.danswer.model.OCFIdentificationInfo;

/**
 * EndItemRatioTally
 * <pre>
 * ルール内部で利用するファクト。EndItemRatioのTALLY計算を行う際に使用する。
 * </pre>
 * @author scsk
 *
 */
public class EndItemRatioTally extends EndItemRatio {
	
	private static final long serialVersionUID = 1L;

	/**
	 * RATIO / TALLY計算対象の全データのRATIO合計
	 */
	private Double ratioPlan;

	/**
	 * Tally計算で求めたTally値
	 */
	private Double tallyValue;

	/**
	 * SpecOCFから取得した、E/Iに紐づくOCF情報リスト
	 */
	private List<OCFIdentificationInfo> ocfList;

	public Double getRatioPlan() {
		return ratioPlan;
	}

	public void setRatioPlan(Double ratioPlan) {
		this.ratioPlan = ratioPlan;
	}

	public Double getTallyValue() {
		return tallyValue;
	}

	public void setTallyValue(Double tallyValue) {
		this.tallyValue = tallyValue;
	}

	public List<OCFIdentificationInfo> getOcfList() {
		return ocfList;
	}

	public void setOcfList(List<OCFIdentificationInfo> ocfList) {
		this.ocfList = ocfList;
	}

	@Override
	public String toString() {
		return "EndItemRatioTally [ratioPlan=" + ratioPlan + ", tallyValue="
				+ tallyValue + ", ocfList=" + ocfList.toString() + ", toString()="
				+ super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((ocfList == null) ? 0 : ocfList.hashCode());
		result = prime * result
				+ ((ratioPlan == null) ? 0 : ratioPlan.hashCode());
		result = prime * result
				+ ((tallyValue == null) ? 0 : tallyValue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		EndItemRatioTally other = (EndItemRatioTally) obj;
		if (ocfList == null) {
			if (other.ocfList != null)
				return false;
		} else if (!ocfList.equals(other.ocfList))
			return false;
		if (ratioPlan == null) {
			if (other.ratioPlan != null)
				return false;
		} else if (!ratioPlan.equals(other.ratioPlan))
			return false;
		if (tallyValue == null) {
			if (other.tallyValue != null)
				return false;
		} else if (!tallyValue.equals(other.tallyValue))
			return false;
		return true;
	}


}

