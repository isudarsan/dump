package com.nissan.danswer.model.eibreakdown;

import java.util.ArrayList;

/**
 * EndItemSlottingResultList
 * <pre>
 * EndItemSlottingResultはこのリストに格納する。
 * EndItemSlottingResultはスロット順に格納されるが、PLAN_YEAR_MONTHは混在してセットされる
 * </pre>
 * @author SCSK
 *
 */
public class EndItemSlottingResultList extends ArrayList<EndItemSlottingResult> {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

}
