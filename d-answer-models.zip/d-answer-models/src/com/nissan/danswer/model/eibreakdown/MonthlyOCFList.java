package com.nissan.danswer.model.eibreakdown;

import java.util.ArrayList;

/**
 * MonthlyOCFList
 * <pre>
 * IN / OUT
 * </pre>
 * @author SCSK
 *
 */
public class MonthlyOCFList extends ArrayList<MonthlyOCF> {
	
	private static final long serialVersionUID = 1L;
	
	public MonthlyOCFList(){
		super();
	}

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (MonthlyOCF element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
	
}
