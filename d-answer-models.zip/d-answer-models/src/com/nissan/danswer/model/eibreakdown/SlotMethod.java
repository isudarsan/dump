package com.nissan.danswer.model.eibreakdown;

import com.nissan.danswer.model.BaseModel;

/**
 * SlotMethod
 * <pre>
 * IN Fact
 * 1:usual slot, 2:usual slot + force slot
 * </pre>
 * @author SCSK
 *
 */
public class SlotMethod extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	/**
	 * SlotMethodFlg<br>
	 * 1:usual slot, 2:usual slot + force slot
	 */
	private int slotMethodFlg;

	public int getSlotMethodFlg() {
		return slotMethodFlg;
	}

	public void setSlotMethodFlg(int slotMethodFlg) {
		this.slotMethodFlg = slotMethodFlg;
	}

	@Override
	public String toString() {
		return "SlotMethod [slotMethodFlg=" + slotMethodFlg + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + slotMethodFlg;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SlotMethod other = (SlotMethod) obj;
		if (slotMethodFlg != other.slotMethodFlg)
			return false;
		return true;
	}

}
