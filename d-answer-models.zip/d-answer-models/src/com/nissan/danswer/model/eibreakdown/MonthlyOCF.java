package com.nissan.danswer.model.eibreakdown;

import com.nissan.danswer.model.BaseModel;
import com.nissan.danswer.model.OCFIdentificationInfo;

/**
 * MonthlyOCF
 * <pre>
 * IN / OUT
 * MONTHLY_OCF_TRNから抽出したデータを、FACTORY_CODEを以外のキーでサマリしたデータ。
 * </pre>
 * @author SCSK
 *
 */
public class MonthlyOCF extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;
	
	/** 
	 * OCFIdentificationInfo
	 * @see com.nissan.danswer.model.OCFIdentificationInfo
	 */
	private OCFIdentificationInfo ocfInfo;

	/** MAX_QTY */
	private int maxQty = 0;
	
	/** ACTUAL_QTY */
	private int actualQty = 0;
	
	/* below for rule */
	/**
	 * ルール内部で使用<br>
	 * 通常スロット時の対象OCFの場合にtrueがセットされる。
	 */
	private boolean isMin = false;
	
	/**
	 * ルール内部で使用<br>
	 * 強制スロット時の対象OCFの場合にtrueがセットされる。
	 */
	private boolean isMax = false;
	
	/**
	 * ルール内部で使用<br>
	 * 当OCFの通常スロットが終わった際に、trueがセットされる。
	 */
	private boolean usualFlg = false;
	
	/**
	 * ルール内部で使用<br>
	 * 当OCFの強制スロットが終わった際に、trueがセットされる。
	 */
	private boolean forceFlg = false;

	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public OCFIdentificationInfo getOcfInfo() {
		return ocfInfo;
	}

	public void setOcfInfo(OCFIdentificationInfo ocfInfo) {
		this.ocfInfo = ocfInfo;
	}

	public int getMaxQty() {
		return maxQty;
	}

	public void setMaxQty(int maxQty) {
		this.maxQty = maxQty;
	}

	public int getActualQty() {
		return actualQty;
	}

	public void setActualQty(int actualQty) {
		this.actualQty = actualQty;
	}

	public boolean isUsualFlg() {
		return usualFlg;
	}

	public void setUsualFlg(boolean usualFlg) {
		this.usualFlg = usualFlg;
	}

	public boolean isMin() {
		return isMin;
	}

	public void setMin(boolean isMin) {
		this.isMin = isMin;
	}

	public boolean isMax() {
		return isMax;
	}

	public void setMax(boolean isMax) {
		this.isMax = isMax;
	}

	public boolean isForceFlg() {
		return forceFlg;
	}

	public void setForceFlg(boolean forceFlg) {
		this.forceFlg = forceFlg;
	}

	@Override
	public String toString() {
		return "MonthlyOCF [planYearMonth=" + planYearMonth + ", carSeries="
				+ carSeries + ", ocfInfo=" + ocfInfo + ", maxQty=" + maxQty
				+ ", actualQty=" + actualQty + ", isMin=" + isMin + ", isMax="
				+ isMax + ", usualFlg=" + usualFlg + ", forceFlg=" + forceFlg
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actualQty;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result + (forceFlg ? 1231 : 1237);
		result = prime * result + (isMax ? 1231 : 1237);
		result = prime * result + (isMin ? 1231 : 1237);
		result = prime * result + maxQty;
		result = prime * result + ((ocfInfo == null) ? 0 : ocfInfo.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + (usualFlg ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MonthlyOCF other = (MonthlyOCF) obj;
		if (actualQty != other.actualQty)
			return false;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (forceFlg != other.forceFlg)
			return false;
		if (isMax != other.isMax)
			return false;
		if (isMin != other.isMin)
			return false;
		if (maxQty != other.maxQty)
			return false;
		if (ocfInfo == null) {
			if (other.ocfInfo != null)
				return false;
		} else if (!ocfInfo.equals(other.ocfInfo))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (usualFlg != other.usualFlg)
			return false;
		return true;
	}
	
	public String outCSV() {
		StringBuffer sb = new StringBuffer(64);

		sb.append(System.getProperty("line.separator"));
		sb.append(this.planYearMonth).append(",");
		sb.append(this.carSeries).append(",");
		sb.append(this.ocfInfo.getFrameSortCode()).append(",");
		sb.append(this.ocfInfo.getOcfClassificationCode()).append(",");
		sb.append(this.ocfInfo.getLocationIdentificationCode()).append(",");
		sb.append(this.ocfInfo.getCarGroup()).append(",");
		sb.append(this.ocfInfo.getFrameCode()).append(",");
		sb.append(this.maxQty).append(",");
		sb.append(this.actualQty);
		
		return sb.toString();
	}
}
