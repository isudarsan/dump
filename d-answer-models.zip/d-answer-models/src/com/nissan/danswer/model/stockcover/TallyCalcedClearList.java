package com.nissan.danswer.model.stockcover;

import java.util.ArrayList;


//public class InOrderList extends ArrayList<InOrder> {
public class TallyCalcedClearList extends ArrayList<Tally> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

}
