package com.nissan.danswer.model.stockcover;

import com.nissan.danswer.model.BaseModel;

public class Tally extends BaseModel {
    private static final long serialVersionUID = 8105313816383309151L;

    public Tally() {}
    public Tally(InOrder order) {
        setOrder(order);
    }
    public Tally(InOrder order, String key) {
        setOrder(order);
        setSortkey(key);
    }

    private InOrder order;
    private double total;
    private double init;
    private double tally;
    private String sortkey; 
    private int tallycalced;
    
    public InOrder getOrder() {
        return order;
    }
    public void setOrder(InOrder order) {
        this.order = order;
    }
    public double getTotal() {
        return total;
    }
    public void setTotal(double total) {
        this.total = total;
    }
    public double getTally() {
        return tally;
    }
    public void setTally(double tally) {
        this.tally = tally;
    }
    public int getTallycalced() {
        return tallycalced;
    }
    public void setTallycalced(int tallycalced) {
        this.tallycalced = tallycalced;
    }
    @Override
    public String toString() {
        return "Tally "
                + "[order=" + order
                + ", total=" + total
                + ", tally=" + tally
                + ", init=" + init
                + ", tallycalced=" + tallycalced
                + ", sortkey=" + sortkey
                + "]";
    }
    public double getInit() {
        return init;
    }
    public void setInit(double init) {
        this.init = init;
    }
    public String getSortkey() {
        return sortkey;
    }
    public void setSortkey(String sortkey) {
        this.sortkey = sortkey;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        long temp;
        temp = Double.doubleToLongBits(init);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((order == null) ? 0 : order.hashCode());
        result = prime * result + ((sortkey == null) ? 0 : sortkey.hashCode());
        temp = Double.doubleToLongBits(tally);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + tallycalced;
        temp = Double.doubleToLongBits(total);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Tally other = (Tally) obj;
        if (Double.doubleToLongBits(init) != Double
                .doubleToLongBits(other.init))
            return false;
        if (order == null) {
            if (other.order != null)
                return false;
        } else if (!order.equals(other.order))
            return false;
        if (sortkey == null) {
            if (other.sortkey != null)
                return false;
        } else if (!sortkey.equals(other.sortkey))
            return false;
        if (Double.doubleToLongBits(tally) != Double
                .doubleToLongBits(other.tally))
            return false;
        if (tallycalced != other.tallycalced)
            return false;
        if (Double.doubleToLongBits(total) != Double
                .doubleToLongBits(other.total))
            return false;
        return true;
    }
}
