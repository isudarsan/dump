package com.nissan.danswer.model.stockcover;


import com.nissan.danswer.model.BaseModel;

/**
 * OCF Check
 */
public class OCFClear extends BaseModel {
    private static final long serialVersionUID = 4034131002398795091L;
    
    private OCFDaily ocf;
    
    public OCFClear() {}
    public OCFClear(OCFDaily ocf) {
        setOcf(ocf);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((ocf == null) ? 0 : ocf.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCFClear other = (OCFClear) obj;
        if (ocf == null) {
            if (other.ocf != null)
                return false;
        } else if (!ocf.equals(other.ocf))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "OCFCheck [ocf=" + ocf + "]";
    }

    public OCFDaily getOcf() {
        return ocf;
    }

    public void setOcf(OCFDaily ocf) {
        this.ocf = ocf;
    }

    
}
