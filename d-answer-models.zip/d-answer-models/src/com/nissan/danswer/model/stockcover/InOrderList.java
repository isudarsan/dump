package com.nissan.danswer.model.stockcover;

import java.util.ArrayList;

/**
 * InOrderList
 * @author SCSK
 *
 */
public class InOrderList extends ArrayList<InOrder> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted InOrderList Data(csv format) --------%n");
        out.append("#PLAN_YEAR_MONTH,CAR_SERIES,END_ITEM_MODEL_CODE,END_ITEM_COLOR_CODE,QTY%n");

        for (InOrder ei : this) {
            out.append(ei.toCSV());
            out.append("%n");
        }

        out.append("----------------------------------------");
        
        return out.toString();
    }
}
