package com.nissan.danswer.model.stockcover;

import java.util.ArrayList;

/**
 * Daily OCF List(IN/OUT)
 * 
 */
public class OCFDailyList extends ArrayList<OCFDaily> {
    private static final long serialVersionUID = 4361045253511968304L;
    
    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted OCFDaily Data(csv format) --------%n");
        out.append("#PLAN_YEAR_MONTH,CAR_SERIES,FRAME_SORT_CODE,OCF_CLASSIFICATION_CODE,LOC_ID_CODE,CAR_GROUP,FACTORY_CODE,LINE_CLASS,FRAME_CODE,WEEK_NO,DATE,MAX_QTY%n");

        for (OCFDaily ocf : this) {
            out.append(ocf.toCSV());
            out.append("%n");
        }

        out.append("----------------------------------------");
        
        return out.toString();
    }
}
