package com.nissan.danswer.model.stockcover;

import java.util.ArrayList;

public class OCFClearList extends ArrayList<OCFDaily> {
    private static final long serialVersionUID = -4807051475621763900L;
}
