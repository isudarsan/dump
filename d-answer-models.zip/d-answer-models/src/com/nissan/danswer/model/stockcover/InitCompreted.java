package com.nissan.danswer.model.stockcover;

public class InitCompreted {}
