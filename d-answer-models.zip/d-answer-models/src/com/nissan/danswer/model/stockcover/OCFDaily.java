package com.nissan.danswer.model.stockcover;


import com.nissan.danswer.model.BaseModel;
import com.nissan.danswer.model.OCFIdentificationInfo;

/**
 * Daily OCF
 */
public class OCFDaily extends BaseModel {
    private static final long serialVersionUID = 2722227072984460224L;
    
    private String planYearMonth;
    private String carSeries;
    private OCFIdentificationInfo ocfInfo;
    private String factoryCode;
    private String lineClass;
    private String weekNo;
    private String date;
    private int maxQty;
    private int actualQty;
    
//    private int lineno;
    private int flg;

    public String getPlanYearMonth() {
        return planYearMonth;
    }

    public void setPlanYearMonth(String planYearMonth) {
        this.planYearMonth = planYearMonth;
    }
    public String getCarSeries() {
        return carSeries;
    }
    public void setCarSeries(String carSeries) {
        this.carSeries = carSeries;
    }
    public OCFIdentificationInfo getOcfInfo() {
        return ocfInfo;
    }
    public void setOcfInfo(OCFIdentificationInfo ocfInfo) {
        this.ocfInfo = ocfInfo;
    }
    public String getFactoryCode() {
        return factoryCode;
    }
    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }
    public String getLineClass() {
        return lineClass;
    }
    public void setLineClass(String lineClass) {
        this.lineClass = lineClass;
    }
    public String getWeekNo() {
        return weekNo;
    }
    public void setWeekNo(String weekNo) {
        this.weekNo = weekNo;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public int getMaxQty() {
        return maxQty;
    }
    public void setMaxQty(int maxQty) {
        this.maxQty = maxQty;
    }
    public int getActualQty() {
        return actualQty;
    }
    public void setActualQty(int actualQty) {
        this.actualQty = actualQty;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + actualQty;
        result = prime * result
                + ((carSeries == null) ? 0 : carSeries.hashCode());
        result = prime * result + ((date == null) ? 0 : date.hashCode());
        result = prime * result
                + ((factoryCode == null) ? 0 : factoryCode.hashCode());
        result = prime * result
                + ((lineClass == null) ? 0 : lineClass.hashCode());
        result = prime * result + maxQty;
        result = prime * result + ((ocfInfo == null) ? 0 : ocfInfo.hashCode());
        result = prime * result
                + ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
        result = prime * result + ((weekNo == null) ? 0 : weekNo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCFDaily other = (OCFDaily) obj;
        if (actualQty != other.actualQty)
            return false;
        if (carSeries == null) {
            if (other.carSeries != null)
                return false;
        } else if (!carSeries.equals(other.carSeries))
            return false;
        if (date == null) {
            if (other.date != null)
                return false;
        } else if (!date.equals(other.date))
            return false;
        if (factoryCode == null) {
            if (other.factoryCode != null)
                return false;
        } else if (!factoryCode.equals(other.factoryCode))
            return false;
        if (lineClass == null) {
            if (other.lineClass != null)
                return false;
        } else if (!lineClass.equals(other.lineClass))
            return false;
        if (maxQty != other.maxQty)
            return false;
        if (ocfInfo == null) {
            if (other.ocfInfo != null)
                return false;
        } else if (!ocfInfo.equals(other.ocfInfo))
            return false;
        if (planYearMonth == null) {
            if (other.planYearMonth != null)
                return false;
        } else if (!planYearMonth.equals(other.planYearMonth))
            return false;
        if (weekNo == null) {
            if (other.weekNo != null)
                return false;
        } else if (!weekNo.equals(other.weekNo))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "OCFDaily " // + lineno
                + "[planYearMonth=" + planYearMonth
                + ", carSeries=" + carSeries
                + ", ocfInfo=" + ocfInfo
                + ", factoryCode=" + factoryCode
                + ", lineClass=" + lineClass
                + ", weekNo=" + weekNo
                + ", date=" + date 
                + ", maxQty=" + maxQty
                + ", actualQty=" + actualQty
                + ", flg=" + flg
                + "]";
    }
    
    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d", 
                planYearMonth,
                carSeries,
                ocfInfo.getFrameSortCode(),
                ocfInfo.getOcfClassificationCode(),
                ocfInfo.getLocationIdentificationCode(),
                ocfInfo.getCarGroup(),
                factoryCode,
                lineClass,
                ocfInfo.getFrameCode(),
                weekNo,
                date,
                maxQty);
    }

//    public int getLineno() {
//        return lineno;
//    }
//
//    public void setLineno(int lineno) {
//        this.lineno = lineno;
//    }

    public int getFlg() {
        return flg;
    }

    public void setFlg(int flg) {
        this.flg = flg;
    }
    
}
