package com.nissan.danswer.model.stockcover;

import java.util.ArrayList;

/**
 * OutOrderList
 * <pre>
 * OutOrder情報はこのクラスにセットされた形で返します。
 * </pre>
 * @author SCSK
 *
 */
public class OutOrderList extends ArrayList<OutOrder> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

}
