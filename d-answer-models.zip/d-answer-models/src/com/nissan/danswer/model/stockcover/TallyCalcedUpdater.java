package com.nissan.danswer.model.stockcover;


import com.nissan.danswer.model.BaseModel;

public class TallyCalcedUpdater extends BaseModel {
    private static final long serialVersionUID = 8828398145558939138L;
    
    private Tally tally;
    
    public TallyCalcedUpdater() {}
    public TallyCalcedUpdater(Tally tally) {
        setTally(tally);
    }
    public Tally getTally() {
        return tally;
    }
    public void setTally(Tally tally) {
        this.tally = tally;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((tally == null) ? 0 : tally.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TallyCalcedUpdater other = (TallyCalcedUpdater) obj;
        if (tally == null) {
            if (other.tally != null)
                return false;
        } else if (!tally.equals(other.tally))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "TallyCalcedUpdater [tally=" + tally + "]";
    }
}
