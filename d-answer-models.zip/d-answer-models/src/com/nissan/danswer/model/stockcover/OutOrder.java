package com.nissan.danswer.model.stockcover;

import com.nissan.danswer.model.BaseModel;

public class OutOrder extends BaseModel {
    private static final long serialVersionUID = -6430770929715149105L;

    private String planYearMonth;
	private String carSeries;
	private String endItemModelCode;
	private String endItemColorCode;
    
	private String newOfflineDate;
	private String newOfflineWeek;
	private String newFactoryCode;
	private String newLineClass;
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((carSeries == null) ? 0 : carSeries.hashCode());
        result = prime
                * result
                + ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
        result = prime
                * result
                + ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
        result = prime * result
                + ((newFactoryCode == null) ? 0 : newFactoryCode.hashCode());
        result = prime * result
                + ((newLineClass == null) ? 0 : newLineClass.hashCode());
        result = prime * result
                + ((newOfflineDate == null) ? 0 : newOfflineDate.hashCode());
        result = prime * result
                + ((newOfflineWeek == null) ? 0 : newOfflineWeek.hashCode());
        result = prime * result
                + ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OutOrder other = (OutOrder) obj;
        if (carSeries == null) {
            if (other.carSeries != null)
                return false;
        } else if (!carSeries.equals(other.carSeries))
            return false;
        if (endItemColorCode == null) {
            if (other.endItemColorCode != null)
                return false;
        } else if (!endItemColorCode.equals(other.endItemColorCode))
            return false;
        if (endItemModelCode == null) {
            if (other.endItemModelCode != null)
                return false;
        } else if (!endItemModelCode.equals(other.endItemModelCode))
            return false;
        if (newFactoryCode == null) {
            if (other.newFactoryCode != null)
                return false;
        } else if (!newFactoryCode.equals(other.newFactoryCode))
            return false;
        if (newLineClass == null) {
            if (other.newLineClass != null)
                return false;
        } else if (!newLineClass.equals(other.newLineClass))
            return false;
        if (newOfflineDate == null) {
            if (other.newOfflineDate != null)
                return false;
        } else if (!newOfflineDate.equals(other.newOfflineDate))
            return false;
        if (newOfflineWeek == null) {
            if (other.newOfflineWeek != null)
                return false;
        } else if (!newOfflineWeek.equals(other.newOfflineWeek))
            return false;
        if (planYearMonth == null) {
            if (other.planYearMonth != null)
                return false;
        } else if (!planYearMonth.equals(other.planYearMonth))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "OutOrder [planYearMonth=" + planYearMonth + ", carSeries="
                + carSeries + ", endItemModelCode=" + endItemModelCode
                + ", endItemColorCode=" + endItemColorCode
                + ", newOfflineDate=" + newOfflineDate + ", newOfflineWeek="
                + newOfflineWeek + ", newFactoryCode=" + newFactoryCode
                + ", newLineClass=" + newLineClass + "]";
    }
    public String getPlanYearMonth() {
        return planYearMonth;
    }
    public void setPlanYearMonth(String planYearMonth) {
        this.planYearMonth = planYearMonth;
    }
    public String getCarSeries() {
        return carSeries;
    }
    public void setCarSeries(String carSeries) {
        this.carSeries = carSeries;
    }
    public String getEndItemModelCode() {
        return endItemModelCode;
    }
    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }
    public String getEndItemColorCode() {
        return endItemColorCode;
    }
    public void setEndItemColorCode(String endItemColorCode) {
        this.endItemColorCode = endItemColorCode;
    }
    public String getNewOfflineDate() {
        return newOfflineDate;
    }
    public void setNewOfflineDate(String newOfflineDate) {
        this.newOfflineDate = newOfflineDate;
    }
    public String getNewOfflineWeek() {
        return newOfflineWeek;
    }
    public void setNewOfflineWeek(String newOfflineWeek) {
        this.newOfflineWeek = newOfflineWeek;
    }
    public String getNewFactoryCode() {
        return newFactoryCode;
    }
    public void setNewFactoryCode(String newFactoryCode) {
        this.newFactoryCode = newFactoryCode;
    }
    public String getNewLineClass() {
        return newLineClass;
    }
    public void setNewLineClass(String newLineClass) {
        this.newLineClass = newLineClass;
    }
}
