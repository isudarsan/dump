package com.nissan.danswer.model.stockcover;

import com.nissan.danswer.model.BaseModel;

public class MaxTally extends BaseModel {
    private static final long serialVersionUID = 519556098581538918L;

    public MaxTally() {}
    public MaxTally(double max) {
        setMax(max);
    }
    public MaxTally(double max, String sortkey) {
        setMax(max);
        setSortkey(sortkey);
    }

    private double max;
    private String sortkey;
    
    @Override
    public String toString() {
        return "MaxTally "
                + "[max=" + max + ", "
                + "sortkey=" + sortkey + ", "
                + "]";
    }
    public double getMax() {
        return max;
    }
    public void setMax(double max) {
        this.max = max;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        long temp;
        temp = Double.doubleToLongBits(max);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((sortkey == null) ? 0 : sortkey.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MaxTally other = (MaxTally) obj;
        if (Double.doubleToLongBits(max) != Double.doubleToLongBits(other.max))
            return false;
        if (sortkey == null) {
            if (other.sortkey != null)
                return false;
        } else if (!sortkey.equals(other.sortkey))
            return false;
        return true;
    }
    public String getSortkey() {
        return sortkey;
    }
    public void setSortkey(String sortkey) {
        this.sortkey = sortkey;
    }
}
