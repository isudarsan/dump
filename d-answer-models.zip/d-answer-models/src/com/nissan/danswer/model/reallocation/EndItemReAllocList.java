package com.nissan.danswer.model.reallocation;

import java.util.ArrayList;

/**
 * Re-Allocation ORDER List (IN/OUT)
 * 
 * @author ishikawa
 * 
 */
public class EndItemReAllocList extends ArrayList<EndItemReAlloc> {

    private static final long serialVersionUID = 6185792599780363612L;

    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted EndItemReAlloc Data(csv format) --------%n");
        out.append("#PLAN_YEAR_MONTH,CAR_SERIES,DISTRIBUTION_NO,END_ITEM_MODEL_CODE,END_ITEM_COLOR_CODE,FACTORY_CODE,LINE_CLASS,ORDER_TYPE,RE_ALLOCATION_PRIORITY_NO,RE_ALLOCATION_SCOPE_FLG,INPUT_DATE_OF_ORDER,WEEK_OF_DUE_DATE_FOR_DELIVERY,FIX_FLG,DEALER_REPLY_FLG,RANDOM_NO,BOLSA_OR_NOT,OFFLINE_DATE,OFFLINE_WEEK_NO%n");

        for (EndItemReAlloc ei : this) {
            out.append(ei.toCSV());
            out.append("%n");
        }

        out.append("------------------------------------------");
        
        return out.toString();
    }
}
