package com.nissan.danswer.model.reallocation;

import com.nissan.danswer.model.BaseModel;

/**
 * Factory Line Sort Table(入力用)
 */
public class FactoryLine extends BaseModel {
    private static final long serialVersionUID = 7504585753781709626L;

    private String factory; // オーダーが指定する工場
    private String line;    // オーダーが指定するライン
    
    public FactoryLine() {}
    
    public FactoryLine(String factory, String line) {
        this.factory = factory;
        this.line = line;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((factory == null) ? 0 : factory.hashCode());
        result = prime * result + ((line == null) ? 0 : line.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FactoryLine other = (FactoryLine) obj;
        if (factory == null) {
            if (other.factory != null)
                return false;
        } else if (!factory.equals(other.factory))
            return false;
        if (line == null) {
            if (other.line != null)
                return false;
        } else if (!line.equals(other.line))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "FactoryLine [factory=" + factory + ", line=" + line + "]";
    }

    public void setFactory(String factory) {
        this.factory = factory;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getFactory() {
        return factory;
    }

    public String getLine() {
        return line;
    }
}
