package com.nissan.danswer.model.reallocation;

import com.nissan.danswer.model.BaseModel;

/**
 * Factory Line Sort Table
 */
public class FactoryLineSort extends BaseModel {
    private static final long serialVersionUID = -8123355215027001152L;

    private String orderFactory; // オーダーが指定する工場
    private String orderLine;    // オーダーが指定するライン
    private String sortFactory;  // 未確定オーダーで引当てられる工場の候補
    private String sortLine;     // 未確定オーダーで引当てられるラインの候補
    private String sortNo;       // 未確定オーダーで引当てる優先順位
    private int allocated;
    
    public String getOrderFactory() {
        return orderFactory;
    }
    public void setOrderFactory(String orderFactory) {
        this.orderFactory = orderFactory;
    }
    public String getOrderLine() {
        return orderLine;
    }
    public void setOrderLine(String orderLine) {
        this.orderLine = orderLine;
    }
    public String getSortFactory() {
        return sortFactory;
    }
    public void setSortFactory(String sortFactory) {
        this.sortFactory = sortFactory;
    }
    public String getSortLine() {
        return sortLine;
    }
    public void setSortLine(String sortLine) {
        this.sortLine = sortLine;
    }
    public String getSortNo() {
        return sortNo;
    }
    public void setSortNo(String sortNo) {
        this.sortNo = sortNo;
    }
    @Override
    public String toString() {
        return "FactoryLineSort [orderFactory=" + orderFactory + ", orderLine="
                + orderLine + ", sortFactory=" + sortFactory + ", sortLine="
                + sortLine + ", sortNo=" + sortNo + ", allocated=" + allocated
                + "]";
    }
    public int getAllocated() {
        return allocated;
    }
    public void setAllocated(int allocated) {
        this.allocated = allocated;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + allocated;
        result = prime * result
                + ((orderFactory == null) ? 0 : orderFactory.hashCode());
        result = prime * result
                + ((orderLine == null) ? 0 : orderLine.hashCode());
        result = prime * result
                + ((sortFactory == null) ? 0 : sortFactory.hashCode());
        result = prime * result
                + ((sortLine == null) ? 0 : sortLine.hashCode());
        result = prime * result + ((sortNo == null) ? 0 : sortNo.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FactoryLineSort other = (FactoryLineSort) obj;
        if (allocated != other.allocated)
            return false;
        if (orderFactory == null) {
            if (other.orderFactory != null)
                return false;
        } else if (!orderFactory.equals(other.orderFactory))
            return false;
        if (orderLine == null) {
            if (other.orderLine != null)
                return false;
        } else if (!orderLine.equals(other.orderLine))
            return false;
        if (sortFactory == null) {
            if (other.sortFactory != null)
                return false;
        } else if (!sortFactory.equals(other.sortFactory))
            return false;
        if (sortLine == null) {
            if (other.sortLine != null)
                return false;
        } else if (!sortLine.equals(other.sortLine))
            return false;
        if (sortNo == null) {
            if (other.sortNo != null)
                return false;
        } else if (!sortNo.equals(other.sortNo))
            return false;
        return true;
    }

    
}
