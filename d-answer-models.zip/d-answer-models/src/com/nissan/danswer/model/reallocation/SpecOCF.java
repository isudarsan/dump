package com.nissan.danswer.model.reallocation;

import java.util.List;

import com.nissan.danswer.model.BaseModel;
import com.nissan.danswer.model.OCFIdentificationInfo;

/**
 * SPEC_OCF(with WEEK_NO)
 * 
 * @author ishikawa
 * 
 */
public class SpecOCF extends BaseModel {

    private static final long serialVersionUID = 1L;

    private String productionYear="";
	public String getProductionYear() {
		return productionYear;
	}
	public void setProductionYear(String productionYear) {
		this.productionYear = productionYear;
	}
    private String planYearMonth;
    private String carSeries;
    private String porCode;
    private String productionFamilyCode;
    private String endItemModelCode;
    private String endItemColorCode;
    private String weekNo;
    private List<OCFIdentificationInfo> ocfList;

    public String getPlanYearMonth() {
        return planYearMonth;
    }

    public void setPlanYearMonth(String planYearMonth) {
        this.planYearMonth = planYearMonth;
    }

    public String getCarSeries() {
        return carSeries;
    }

    public void setCarSeries(String carSeries) {
        this.carSeries = carSeries;
    }

    public String getPorCode() {
        return porCode;
    }

    public void setPorCode(String porCode) {
        this.porCode = porCode;
    }

    public String getProductionFamilyCode() {
        return productionFamilyCode;
    }

    public void setProductionFamilyCode(String productionFamilyCode) {
        this.productionFamilyCode = productionFamilyCode;
    }

    public String getEndItemModelCode() {
        return endItemModelCode;
    }

    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }

    public String getEndItemColorCode() {
        return endItemColorCode;
    }

    public void setEndItemColorCode(String endItemColorCode) {
        this.endItemColorCode = endItemColorCode;
    }

    public String getWeekNo() {
        return weekNo;
    }

    public void setWeekNo(String weekNo) {
        this.weekNo = weekNo;
    }

    public List<OCFIdentificationInfo> getOcfList() {
        return ocfList;
    }

    public void setOcfList(List<OCFIdentificationInfo> ocfList) {
        this.ocfList = ocfList;
    }

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result + ((ocfList == null) ? 0 : ocfList.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
		result = prime
				* result
				+ ((productionFamilyCode == null) ? 0 : productionFamilyCode
						.hashCode());
		result = prime * result
				+ ((productionYear == null) ? 0 : productionYear.hashCode());
		result = prime * result + ((weekNo == null) ? 0 : weekNo.hashCode());
		return result;
	}

    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpecOCF other = (SpecOCF) obj;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (ocfList == null) {
			if (other.ocfList != null)
				return false;
		} else if (!ocfList.equals(other.ocfList))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (porCode == null) {
			if (other.porCode != null)
				return false;
		} else if (!porCode.equals(other.porCode))
			return false;
		if (productionFamilyCode == null) {
			if (other.productionFamilyCode != null)
				return false;
		} else if (!productionFamilyCode.equals(other.productionFamilyCode))
			return false;
		if (productionYear == null) {
			if (other.productionYear != null)
				return false;
		} else if (!productionYear.equals(other.productionYear))
			return false;
		if (weekNo == null) {
			if (other.weekNo != null)
				return false;
		} else if (!weekNo.equals(other.weekNo))
			return false;
		return true;
	}

    @Override
	public String toString() {
		return "SpecOCF [productionYear=" + productionYear + ", planYearMonth="
				+ planYearMonth + ", carSeries=" + carSeries + ", porCode="
				+ porCode + ", productionFamilyCode=" + productionFamilyCode
				+ ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode + ", weekNo="
				+ weekNo + ", ocfList=" + ocfList + "]";
	}
    
    public String toCSV() {
        StringBuffer out = new StringBuffer();
        for (OCFIdentificationInfo ocf : ocfList) {
            out.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s%n",
                    productionYear,
                    planYearMonth,
                    carSeries,
                    porCode,
                    productionFamilyCode,
                    endItemModelCode,
                    endItemColorCode,
                    weekNo,
                    ocf.getFrameSortCode(),
                    ocf.getOcfClassificationCode(),
                    ocf.getLocationIdentificationCode(),
                    ocf.getCarGroup(),
                    ocf.getFrameCode()));
        }
        return out.toString();
    }
}
