package com.nissan.danswer.model.reallocation;

import com.nissan.danswer.model.BaseModel;

/**
 * Instance of FactoryLineTablePreparing exists while making Factory/Line table  
 */
public class FactoryLineTablePreparing extends BaseModel {
    private static final long serialVersionUID = 1L;
    private int numOfFLs;
    
    public FactoryLineTablePreparing() {}
    public FactoryLineTablePreparing(int n) {
        setNumOfFLs(n);
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + numOfFLs;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FactoryLineTablePreparing other = (FactoryLineTablePreparing) obj;
        if (numOfFLs != other.numOfFLs)
            return false;
        return true;
    }
    public int getNumOfFLs() {
        return numOfFLs;
    }
    public void setNumOfFLs(int numOfFLs) {
        this.numOfFLs = numOfFLs;
    }
    
}