package com.nissan.danswer.model.reallocation;

import java.math.BigDecimal;

import com.nissan.danswer.model.BaseModel;

/**
 * Re-Allocation ORDER
 *
 */
public class EndItemReAlloc extends BaseModel {

    private static final long serialVersionUID = 1L;
    
//    private int lineNo;
//    private long index;
    
    private String productionYear="";
	public String getProductionYear() {
		return productionYear;
	}
	public void setProductionYear(String productionYear) {
		this.productionYear = productionYear;
	}
    private String planYearMonth;
    private String carSeries;
    private String distributionNo;
    private String endItemModelCode;
    private String endItemColorCode;
    private String factoryCode;
    private String lineClass;
    private String orderType;
    private String reallocationPriorityNo;
    private String reallocationScopeFlg;
    private String inputDateOfOrder;
    private String weekOfDueDateForDelivery;
    private String fixFlg;
    private String dealerReplyFlg;
    private String randomNo;
    private String bolsaOrNot;
    private String offlineDate;
    private String offlineWeekNo;
    private String newOfflineDate;  // out
    private String newOfflineWeek;  // out
    private String newFactoryCode;  // out
    private String newLineClass;    // out
    private String newBackOrderFlg; // out
    private BigDecimal sortNo;
    private String allocType;
    private String execute;
    
    private String offlineDateForSortNo;
    private String dsOrder;
    private String dealer;
    private String bolsaForSortNo;
    
    public String getPlanYearMonth() {
        return planYearMonth;
    }
    public void setPlanYearMonth(String planYearMonth) {
        this.planYearMonth = planYearMonth;
    }
    public String getCarSeries() {
        return carSeries;
    }
    public void setCarSeries(String carSeries) {
        this.carSeries = carSeries;
    }
    public String getDistributionNo() {
        return distributionNo;
    }
    public void setDistributionNo(String distributionNo) {
        this.distributionNo = distributionNo;
    }
    public String getEndItemModelCode() {
        return endItemModelCode;
    }
    public void setEndItemModelCode(String endItemModelCode) {
        this.endItemModelCode = endItemModelCode;
    }
    public String getEndItemColorCode() {
        return endItemColorCode;
    }
    public void setEndItemColorCode(String endItemColorCode) {
        this.endItemColorCode = endItemColorCode;
    }
    public String getFactoryCode() {
        return factoryCode;
    }
    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }
    public String getLineClass() {
        return lineClass;
    }
    public void setLineClass(String lineClass) {
        this.lineClass = lineClass;
    }
    public String getOrderType() {
        return orderType;
    }
    public String getTrimmedOrderType() {
        return orderType.trim();
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getReallocationPriorityNo() {
        return reallocationPriorityNo;
    }
    public void setReallocationPriorityNo(String reallocationPriorityNo) {
        this.reallocationPriorityNo = reallocationPriorityNo;
    }
    public String getReallocationScopeFlg() {
        return reallocationScopeFlg;
    }
    public void setReallocationScopeFlg(String reallocationScopeFlg) {
        this.reallocationScopeFlg = reallocationScopeFlg;
    }
    public String getInputDateOfOrder() {
        return inputDateOfOrder;
    }
    public void setInputDateOfOrder(String inputDateOfOrder) {
        this.inputDateOfOrder = inputDateOfOrder;
    }
    public String getFixFlg() {
        return fixFlg;
    }
    public void setFixFlg(String fixFlg) {
        this.fixFlg = fixFlg.trim();
    }
    public String getDealerReplyFlg() {
        return dealerReplyFlg;
    }
    public void setDealerReplyFlg(String dealerReplyFlg) {
        this.dealerReplyFlg = dealerReplyFlg.trim();
    }
    public String getRandomNo() {
        return randomNo;
    }
    /**
     * returns zero padded random no
     * @return
     */
    public String getRandomNoZeroPadding() {
        final String paddedNo = "0000000000" + this.randomNo;
        return paddedNo.substring(paddedNo.length() - 10, paddedNo.length());
    }
    public void setRandomNo(String randomNo) {
        this.randomNo = randomNo;
    }
    public String getOfflineDate() {
        return offlineDate;
    }
    public void setOfflineDate(String offlineDate) {
        this.offlineDate = offlineDate;
    }
    public String getOfflineWeekNo() {
        return offlineWeekNo;
    }
    public void setOfflineWeekNo(String offlineWeekNo) {
        this.offlineWeekNo = offlineWeekNo;
    }
    public String getNewOfflineDate() {
        return newOfflineDate;
    }
    public void setNewOfflineDate(String newOfflineDate) {
        this.newOfflineDate = newOfflineDate;
    }
    public String getNewOfflineWeek() {
        return newOfflineWeek;
    }
    public void setNewOfflineWeek(String newOfflineWeek) {
        this.newOfflineWeek = newOfflineWeek;
    }
    public String getNewFactoryCode() {
        return newFactoryCode;
    }
    public void setNewFactoryCode(String newFactoryCode) {
        this.newFactoryCode = newFactoryCode;
    }
    public String getNewLineClass() {
        return newLineClass;
    }
    public void setNewLineClass(String newLineClass) {
        this.newLineClass = newLineClass;
    }
    public String getNewBackOrderFlg() {
        return newBackOrderFlg;
    }
    public void setNewBackOrderFlg(String newBackOrderFlg) {
        this.newBackOrderFlg = newBackOrderFlg;
    }
//    /**
//     * @return the lineNo
//     */
//    public int getLineNo() {
//        return lineNo;
//    }
//    /**
//     * @param lineNo the lineNo to set
//     */
//    public void setLineNo(int index) {
//        this.lineNo = index;
//    }
    /**
     * @return the offlineDateForSortNo
     */
    public String getOfflineDateForSortNo() {
        return offlineDateForSortNo;
    }
    /**
     * @param offlineDateForSortNo the offlineDateForSortNo to set
     */
    public void setOfflineDateForSortNo(String offlineDateForSortNo) {
        this.offlineDateForSortNo = offlineDateForSortNo;
    }
    /**
     * @return the dsOrder
     */
    public String getDsOrder() {
        return dsOrder;
    }
    /**
     * @param dsOrder the dsOrder to set
     */
    public void setDsOrder(String dsOrder) {
        this.dsOrder = dsOrder;
    }
    /**
     * @return the dealer
     */
    public String getDealer() {
        return dealer;
    }
    /**
     * @param dealer the dealer to set
     */
    public void setDealer(String dealer) {
        this.dealer = dealer;
    }
    /**
     * @return the allocType
     */
    public String getAllocType() {
        return allocType;
    }
    /**
     * @param allocType the allocType to set
     */
    public void setAllocType(String allocType) {
        this.allocType = allocType;
    }
    public String getWeekOfDueDateForDelivery() {
        return weekOfDueDateForDelivery;
    }
    public void setWeekOfDueDateForDelivery(String weekOfDueDateForDelivery) {
        this.weekOfDueDateForDelivery = weekOfDueDateForDelivery;
    }
//    public long getIndex() {
//        return index;
//    }
//    public void setIndex(long index) {
//        this.index = index;
//    }
    public String getExecute() {
        return execute;
    }
    public void setExecute(String execute) {
        this.execute = execute;
    }
    public String getBolsaOrNot() {
        return bolsaOrNot;
    }
    public void setBolsaOrNot(String bolsaOrNot) {
        this.bolsaOrNot = bolsaOrNot.trim();
    }
    public String getBolsaForSortNo() {
        return bolsaForSortNo;
    }
    public void setBolsaForSortNo(String bolsaForSortNo) {
        this.bolsaForSortNo = bolsaForSortNo;
    }

    public String toCSV() {
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",
                planYearMonth,
                carSeries,
                distributionNo,
                endItemModelCode,
                endItemColorCode,
                factoryCode,
                lineClass,
                orderType,
                reallocationPriorityNo,
                reallocationScopeFlg,
                inputDateOfOrder,
                weekOfDueDateForDelivery,
                fixFlg,
                dealerReplyFlg,
                randomNo,
                bolsaOrNot,
                offlineDate,
                offlineWeekNo,productionYear);
    }
    
    public BigDecimal getSortNo() {
        return sortNo;
    }
    public void setSortNo(BigDecimal sortNo) {
        this.sortNo = sortNo;
    }
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((allocType == null) ? 0 : allocType.hashCode());
		result = prime * result
				+ ((bolsaForSortNo == null) ? 0 : bolsaForSortNo.hashCode());
		result = prime * result
				+ ((bolsaOrNot == null) ? 0 : bolsaOrNot.hashCode());
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result + ((dealer == null) ? 0 : dealer.hashCode());
		result = prime * result
				+ ((dealerReplyFlg == null) ? 0 : dealerReplyFlg.hashCode());
		result = prime * result
				+ ((distributionNo == null) ? 0 : distributionNo.hashCode());
		result = prime * result + ((dsOrder == null) ? 0 : dsOrder.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result + ((execute == null) ? 0 : execute.hashCode());
		result = prime * result
				+ ((factoryCode == null) ? 0 : factoryCode.hashCode());
		result = prime * result + ((fixFlg == null) ? 0 : fixFlg.hashCode());
		result = prime
				* result
				+ ((inputDateOfOrder == null) ? 0 : inputDateOfOrder.hashCode());
		result = prime * result
				+ ((lineClass == null) ? 0 : lineClass.hashCode());
		result = prime * result
				+ ((newBackOrderFlg == null) ? 0 : newBackOrderFlg.hashCode());
		result = prime * result
				+ ((newFactoryCode == null) ? 0 : newFactoryCode.hashCode());
		result = prime * result
				+ ((newLineClass == null) ? 0 : newLineClass.hashCode());
		result = prime * result
				+ ((newOfflineDate == null) ? 0 : newOfflineDate.hashCode());
		result = prime * result
				+ ((newOfflineWeek == null) ? 0 : newOfflineWeek.hashCode());
		result = prime * result
				+ ((offlineDate == null) ? 0 : offlineDate.hashCode());
		result = prime
				* result
				+ ((offlineDateForSortNo == null) ? 0 : offlineDateForSortNo
						.hashCode());
		result = prime * result
				+ ((offlineWeekNo == null) ? 0 : offlineWeekNo.hashCode());
		result = prime * result
				+ ((orderType == null) ? 0 : orderType.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result
				+ ((productionYear == null) ? 0 : productionYear.hashCode());
		result = prime * result
				+ ((randomNo == null) ? 0 : randomNo.hashCode());
		result = prime
				* result
				+ ((reallocationPriorityNo == null) ? 0
						: reallocationPriorityNo.hashCode());
		result = prime
				* result
				+ ((reallocationScopeFlg == null) ? 0 : reallocationScopeFlg
						.hashCode());
		result = prime * result + ((sortNo == null) ? 0 : sortNo.hashCode());
		result = prime
				* result
				+ ((weekOfDueDateForDelivery == null) ? 0
						: weekOfDueDateForDelivery.hashCode());
		return result;
	}
    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EndItemReAlloc other = (EndItemReAlloc) obj;
		if (allocType == null) {
			if (other.allocType != null)
				return false;
		} else if (!allocType.equals(other.allocType))
			return false;
		if (bolsaForSortNo == null) {
			if (other.bolsaForSortNo != null)
				return false;
		} else if (!bolsaForSortNo.equals(other.bolsaForSortNo))
			return false;
		if (bolsaOrNot == null) {
			if (other.bolsaOrNot != null)
				return false;
		} else if (!bolsaOrNot.equals(other.bolsaOrNot))
			return false;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (dealer == null) {
			if (other.dealer != null)
				return false;
		} else if (!dealer.equals(other.dealer))
			return false;
		if (dealerReplyFlg == null) {
			if (other.dealerReplyFlg != null)
				return false;
		} else if (!dealerReplyFlg.equals(other.dealerReplyFlg))
			return false;
		if (distributionNo == null) {
			if (other.distributionNo != null)
				return false;
		} else if (!distributionNo.equals(other.distributionNo))
			return false;
		if (dsOrder == null) {
			if (other.dsOrder != null)
				return false;
		} else if (!dsOrder.equals(other.dsOrder))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (execute == null) {
			if (other.execute != null)
				return false;
		} else if (!execute.equals(other.execute))
			return false;
		if (factoryCode == null) {
			if (other.factoryCode != null)
				return false;
		} else if (!factoryCode.equals(other.factoryCode))
			return false;
		if (fixFlg == null) {
			if (other.fixFlg != null)
				return false;
		} else if (!fixFlg.equals(other.fixFlg))
			return false;
		if (inputDateOfOrder == null) {
			if (other.inputDateOfOrder != null)
				return false;
		} else if (!inputDateOfOrder.equals(other.inputDateOfOrder))
			return false;
		if (lineClass == null) {
			if (other.lineClass != null)
				return false;
		} else if (!lineClass.equals(other.lineClass))
			return false;
		if (newBackOrderFlg == null) {
			if (other.newBackOrderFlg != null)
				return false;
		} else if (!newBackOrderFlg.equals(other.newBackOrderFlg))
			return false;
		if (newFactoryCode == null) {
			if (other.newFactoryCode != null)
				return false;
		} else if (!newFactoryCode.equals(other.newFactoryCode))
			return false;
		if (newLineClass == null) {
			if (other.newLineClass != null)
				return false;
		} else if (!newLineClass.equals(other.newLineClass))
			return false;
		if (newOfflineDate == null) {
			if (other.newOfflineDate != null)
				return false;
		} else if (!newOfflineDate.equals(other.newOfflineDate))
			return false;
		if (newOfflineWeek == null) {
			if (other.newOfflineWeek != null)
				return false;
		} else if (!newOfflineWeek.equals(other.newOfflineWeek))
			return false;
		if (offlineDate == null) {
			if (other.offlineDate != null)
				return false;
		} else if (!offlineDate.equals(other.offlineDate))
			return false;
		if (offlineDateForSortNo == null) {
			if (other.offlineDateForSortNo != null)
				return false;
		} else if (!offlineDateForSortNo.equals(other.offlineDateForSortNo))
			return false;
		if (offlineWeekNo == null) {
			if (other.offlineWeekNo != null)
				return false;
		} else if (!offlineWeekNo.equals(other.offlineWeekNo))
			return false;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (productionYear == null) {
			if (other.productionYear != null)
				return false;
		} else if (!productionYear.equals(other.productionYear))
			return false;
		if (randomNo == null) {
			if (other.randomNo != null)
				return false;
		} else if (!randomNo.equals(other.randomNo))
			return false;
		if (reallocationPriorityNo == null) {
			if (other.reallocationPriorityNo != null)
				return false;
		} else if (!reallocationPriorityNo.equals(other.reallocationPriorityNo))
			return false;
		if (reallocationScopeFlg == null) {
			if (other.reallocationScopeFlg != null)
				return false;
		} else if (!reallocationScopeFlg.equals(other.reallocationScopeFlg))
			return false;
		if (sortNo == null) {
			if (other.sortNo != null)
				return false;
		} else if (!sortNo.equals(other.sortNo))
			return false;
		if (weekOfDueDateForDelivery == null) {
			if (other.weekOfDueDateForDelivery != null)
				return false;
		} else if (!weekOfDueDateForDelivery
				.equals(other.weekOfDueDateForDelivery))
			return false;
		return true;
	}
    @Override
	public String toString() {
		return "EndItemReAlloc [productionYear=" + productionYear
				+ ", planYearMonth=" + planYearMonth + ", carSeries="
				+ carSeries + ", distributionNo=" + distributionNo
				+ ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode + ", factoryCode="
				+ factoryCode + ", lineClass=" + lineClass + ", orderType="
				+ orderType + ", reallocationPriorityNo="
				+ reallocationPriorityNo + ", reallocationScopeFlg="
				+ reallocationScopeFlg + ", inputDateOfOrder="
				+ inputDateOfOrder + ", weekOfDueDateForDelivery="
				+ weekOfDueDateForDelivery + ", fixFlg=" + fixFlg
				+ ", dealerReplyFlg=" + dealerReplyFlg + ", randomNo="
				+ randomNo + ", bolsaOrNot=" + bolsaOrNot + ", offlineDate="
				+ offlineDate + ", offlineWeekNo=" + offlineWeekNo
				+ ", newOfflineDate=" + newOfflineDate + ", newOfflineWeek="
				+ newOfflineWeek + ", newFactoryCode=" + newFactoryCode
				+ ", newLineClass=" + newLineClass + ", newBackOrderFlg="
				+ newBackOrderFlg + ", sortNo=" + sortNo + ", allocType="
				+ allocType + ", execute=" + execute
				+ ", offlineDateForSortNo=" + offlineDateForSortNo
				+ ", dsOrder=" + dsOrder + ", dealer=" + dealer
				+ ", bolsaForSortNo=" + bolsaForSortNo + "]";
	}
}
