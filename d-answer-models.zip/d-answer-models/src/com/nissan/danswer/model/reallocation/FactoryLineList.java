package com.nissan.danswer.model.reallocation;

import java.util.ArrayList;

/**
 * Factory/Line Sort List
 */
public class FactoryLineList extends ArrayList<FactoryLine> {

    private static final long serialVersionUID = 1L;
}
