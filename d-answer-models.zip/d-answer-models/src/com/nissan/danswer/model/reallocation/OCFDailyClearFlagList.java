package com.nissan.danswer.model.reallocation;

import java.util.ArrayList;

/**
 * Daily OCF List(IN/OUT)
 * 
 * @author ishikawa
 * 
 */
public class OCFDailyClearFlagList extends ArrayList<OCFDaily> {

    private static final long serialVersionUID = 1L;

}
