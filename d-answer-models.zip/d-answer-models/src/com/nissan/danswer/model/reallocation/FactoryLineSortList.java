package com.nissan.danswer.model.reallocation;

import java.util.ArrayList;

/**
 * Factory/Line Sort List
 */
public class FactoryLineSortList extends ArrayList<FactoryLineSort> {

    private static final long serialVersionUID = 1L;
}
