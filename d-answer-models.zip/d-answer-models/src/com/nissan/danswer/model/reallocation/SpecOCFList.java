package com.nissan.danswer.model.reallocation;

import java.util.ArrayList;

/**
 * SPEC OCF List(IN/OUT)
 * @author ishikawa
 *
 */
public class SpecOCFList extends ArrayList<SpecOCF> {
    private static final long serialVersionUID = 6185927351352219819L;
    
    public String toCSV() {
        StringBuffer out = new StringBuffer("%ninserted SpecOCF Data(csv format) --------%n");
        out.append("#PLAN_YEAR_MONTH,CAR_SERIES,POR_CODE,PRODUCTION_FAMILY_CODE,END_ITEM_MODEL_CODE,END_ITEM_COLOR_CODE,WEEK_NO,FRAME_SORT,OCF_CLASS,OCF_LOC,CAR_GROUP,FRAME_CODE%n");

        for (SpecOCF ocf : this) {
            out.append(ocf.toCSV());
            out.append("%n");
        }

        out.append("------------------------------------------");
        
        return out.toString();
    }

}
