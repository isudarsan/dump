package com.nissan.danswer.model.ocfslotting;

import java.util.ArrayList;

/**
 * OrderInfoList
 * @author SCSK
 *
 */
public class OrderInfoList extends ArrayList<OrderInfo> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (OrderInfo element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
