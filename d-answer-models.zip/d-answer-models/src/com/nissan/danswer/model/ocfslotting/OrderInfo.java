package com.nissan.danswer.model.ocfslotting;

import com.nissan.danswer.model.BaseModel;

/**
 * OrderInfo
 * <pre>
 * SpecialOrderおよびDirectSalesOrderのオーダー情報
 * </pre>
 * @author SCSK
 *
 */
public class OrderInfo extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;
	
	/** POR_CODE */
	private String porCode;
	
	/** PRODUCTION_FAMILY_CODE */
	private String productionFamilyCode;
	
	/** END_ITEM_MODEL_CODE */
	private String endItemModelCode;

	/** 
	 * END_ITEM_COLOR_CODE<br>
	 * FloorPlan時はNULL
	 */
	private String endItemColorCode;
	
	/**
	 * <lo>
	 * <li>SP:set SEQ
	 * <li>DS:set DIRECT_SALES_ORDER_NO
	 * </lo>
	 */
	private String seqId;
	
	/**
	 * <lo>
	 * <li>SP:set WEEK_OF_DUE_FOR_DELIVERY
	 * <li>DS:set INPUT_DATE_OF_ORDER
	 * </lo>
	 */
	private String sortKey1;
	
	/**
	 * <lo>
	 * <li>SP:set INPUT_DATE_OF_ORDER
	 * <li>DS:NULL
	 * </lo>
	 */
	private String sortKey2;
	
	/**
	 * <lo>
	 * <li>preliminaly field(no use)
	 * </lo>
	 */
	private String sortKey3;
	
	/**
	 * ORDER_TYPE(DS or SP)
	 */
	private String orderType;

	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public String getPorCode() {
		return porCode;
	}

	public void setPorCode(String porCode) {
		this.porCode = porCode;
	}

	public String getProductionFamilyCode() {
		return productionFamilyCode;
	}

	public void setProductionFamilyCode(String productionFamilyCode) {
		this.productionFamilyCode = productionFamilyCode;
	}

	public String getEndItemModelCode() {
		return endItemModelCode;
	}

	public void setEndItemModelCode(String endItemModelCode) {
		this.endItemModelCode = endItemModelCode;
	}

	public String getEndItemColorCode() {
		return endItemColorCode;
	}

	public void setEndItemColorCode(String endItemColorCode) {
		this.endItemColorCode = endItemColorCode;
	}

	public String getSeqId() {
		return seqId;
	}

	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}

	public String getSortKey1() {
		return sortKey1;
	}

	public void setSortKey1(String sortKey1) {
		this.sortKey1 = sortKey1;
	}

	public String getSortKey2() {
		return sortKey2;
	}

	public void setSortKey2(String sortKey2) {
		this.sortKey2 = sortKey2;
	}

	public String getSortKey3() {
		return sortKey3;
	}

	public void setSortKey3(String sortKey3) {
		this.sortKey3 = sortKey3;
	}

	public String getOrderType() {
		return orderType;
	}
	
	/**
	 * trimをかけて取得
	 * @return
	 */
	public String getOrderTypeTrim() {
		return orderType.trim();
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Override
	public String toString() {
		return "OrderInfo [planYearMonth=" + planYearMonth + ", carSeries="
				+ carSeries + ", porCode=" + porCode
				+ ", productionFamilyCode=" + productionFamilyCode
				+ ", endItemModelCode=" + endItemModelCode
				+ ", endItemColorCode=" + endItemColorCode + ", seqId=" + seqId
				+ ", sortKey1=" + sortKey1 + ", sortKey2=" + sortKey2
				+ ", sortKey3=" + sortKey3 + ", orderType=" + orderType + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime
				* result
				+ ((endItemColorCode == null) ? 0 : endItemColorCode.hashCode());
		result = prime
				* result
				+ ((endItemModelCode == null) ? 0 : endItemModelCode.hashCode());
		result = prime * result
				+ ((orderType == null) ? 0 : orderType.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + ((porCode == null) ? 0 : porCode.hashCode());
		result = prime
				* result
				+ ((productionFamilyCode == null) ? 0 : productionFamilyCode
						.hashCode());
		result = prime * result + ((seqId == null) ? 0 : seqId.hashCode());
		result = prime * result
				+ ((sortKey1 == null) ? 0 : sortKey1.hashCode());
		result = prime * result
				+ ((sortKey2 == null) ? 0 : sortKey2.hashCode());
		result = prime * result
				+ ((sortKey3 == null) ? 0 : sortKey3.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderInfo other = (OrderInfo) obj;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (endItemColorCode == null) {
			if (other.endItemColorCode != null)
				return false;
		} else if (!endItemColorCode.equals(other.endItemColorCode))
			return false;
		if (endItemModelCode == null) {
			if (other.endItemModelCode != null)
				return false;
		} else if (!endItemModelCode.equals(other.endItemModelCode))
			return false;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (porCode == null) {
			if (other.porCode != null)
				return false;
		} else if (!porCode.equals(other.porCode))
			return false;
		if (productionFamilyCode == null) {
			if (other.productionFamilyCode != null)
				return false;
		} else if (!productionFamilyCode.equals(other.productionFamilyCode))
			return false;
		if (seqId == null) {
			if (other.seqId != null)
				return false;
		} else if (!seqId.equals(other.seqId))
			return false;
		if (sortKey1 == null) {
			if (other.sortKey1 != null)
				return false;
		} else if (!sortKey1.equals(other.sortKey1))
			return false;
		if (sortKey2 == null) {
			if (other.sortKey2 != null)
				return false;
		} else if (!sortKey2.equals(other.sortKey2))
			return false;
		if (sortKey3 == null) {
			if (other.sortKey3 != null)
				return false;
		} else if (!sortKey3.equals(other.sortKey3))
			return false;
		return true;
	}
	
	public String outCSV() {
		StringBuffer sb = new StringBuffer(64);

		sb.append(System.getProperty("line.separator"));
		sb.append(planYearMonth).append(",");
		sb.append(carSeries).append(",");
		sb.append(porCode).append(",");
		sb.append(productionFamilyCode).append(",");
		sb.append(endItemModelCode).append(",");
		sb.append(endItemColorCode).append(",");
		sb.append(seqId).append(",");
		sb.append(sortKey1).append(",");
		sb.append(sortKey2).append(",");
		sb.append(sortKey3).append(",");
		sb.append(orderType);
		
		return sb.toString();
	}
}
