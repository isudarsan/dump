package com.nissan.danswer.model.ocfslotting;

import java.util.ArrayList;

public class EndItemSlottingResultList extends ArrayList<EndItemSlottingResult> {

	private static final long serialVersionUID = 1L;

}
