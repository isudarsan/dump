package com.nissan.danswer.model.ocfslotting;

import java.util.ArrayList;

/**
 * EndItemBreakdownResultList
 * <pre>
 * INファクト
 * E/Iばらし結果(EndItemBreakdownResult）のリスト
 * </pre>
 * @author SCSK
 *
 */
public class EndItemBreakdownResultList extends ArrayList<EndItemBreakdownResult> {

	private static final long serialVersionUID = 1L;

	public String outCSV() {
		
		StringBuffer sb = new StringBuffer(2560);
		
		for (EndItemBreakdownResult element : this) {
			sb.append(element.outCSV());
		}
		
		return sb.toString();
	}
}
