package com.nissan.danswer.model.ocfslotting;

import com.nissan.danswer.model.BaseModel;
import com.nissan.danswer.model.OCFIdentificationInfo;

/**
 * OCFSlottingResult
 * <pre>
 * OCFスロット結果
 * </pre>
 * @author matsuda
 *
 */
public class OCFSlottingResult extends BaseModel {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;
	
	/** OCF一意キー情報 */
	private OCFIdentificationInfo ocfInfo;
	
	/**
	 * スロット結果<br>
	 * true:スロットOK<br>
	 * false:スロットNG（ブリーチ）
	 */
	private boolean slotOkFlg = true;
	
	public OCFSlottingResult() {
	}
	
	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public OCFSlottingResult(OCFIdentificationInfo ocfInfo) {
		this.ocfInfo = ocfInfo;
	}

	public OCFIdentificationInfo getOcfInfo() {
		return ocfInfo;
	}

	public void setOcfInfo(OCFIdentificationInfo ocfInfo) {
		this.ocfInfo = ocfInfo;
	}

	public boolean isSlotOkFlg() {
		return slotOkFlg;
	}

	public void setSlotOkFlg(boolean slotOkFlg) {
		this.slotOkFlg = slotOkFlg;
	}

	@Override
	public String toString() {
		return "OCFSlottingResult [planYearMonth=" + planYearMonth
				+ ", carSeries=" + carSeries + ", ocfInfo=" + ocfInfo
				+ ", slotOkFlg=" + slotOkFlg + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result + ((ocfInfo == null) ? 0 : ocfInfo.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		result = prime * result + (slotOkFlg ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OCFSlottingResult other = (OCFSlottingResult) obj;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (ocfInfo == null) {
			if (other.ocfInfo != null)
				return false;
		} else if (!ocfInfo.equals(other.ocfInfo))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		if (slotOkFlg != other.slotOkFlg)
			return false;
		return true;
	}

}
