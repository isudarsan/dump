package com.nissan.danswer.model.ocfslotting;

import com.nissan.danswer.model.BaseModel;
import com.nissan.danswer.model.OCFIdentificationInfo;

/**
 * MonthlyOCF
 * <pre>
 * IN / OUT
 * MONTHLY_OCF_TRNから抽出したデータを、FACTORY_CODEを以外のキーでサマリしたデータ。
 * </pre>
 * @author SCSK
 *
 */
public class MonthlyOCF extends BaseModel {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	/** PLAN_YEAR_MONTH */
	private String planYearMonth;
	
	/** CAR_SERIES */
	private String carSeries;
	
	/** 
	 * OCFIdentificationInfo
	 * @see com.nissan.danswer.model.OCFIdentificationInfo
	 */
	private OCFIdentificationInfo ocfInfo;

	/** MAX_QTY */
	private int maxQty = 0;
	
	/** ACTUAL_QTY */
	private int actualQty = 0;

	public String getPlanYearMonth() {
		return planYearMonth;
	}

	public void setPlanYearMonth(String planYearMonth) {
		this.planYearMonth = planYearMonth;
	}

	public String getCarSeries() {
		return carSeries;
	}

	public void setCarSeries(String carSeries) {
		this.carSeries = carSeries;
	}

	public OCFIdentificationInfo getOcfInfo() {
		return ocfInfo;
	}

	public void setOcfInfo(OCFIdentificationInfo ocfInfo) {
		this.ocfInfo = ocfInfo;
	}

	public int getMaxQty() {
		return maxQty;
	}

	public void setMaxQty(int maxQty) {
		this.maxQty = maxQty;
	}

	public int getActualQty() {
		return actualQty;
	}

	public void setActualQty(int actualQty) {
		this.actualQty = actualQty;
	}
	
	@Override
	public String toString() {
		return "MonthlyOCF [planYearMonth=" + planYearMonth + ", carSeries="
				+ carSeries + ", ocfInfo=" + ocfInfo + ", maxQty=" + maxQty
				+ ", actualQty=" + actualQty + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actualQty;
		result = prime * result
				+ ((carSeries == null) ? 0 : carSeries.hashCode());
		result = prime * result + maxQty;
		result = prime * result + ((ocfInfo == null) ? 0 : ocfInfo.hashCode());
		result = prime * result
				+ ((planYearMonth == null) ? 0 : planYearMonth.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MonthlyOCF other = (MonthlyOCF) obj;
		if (actualQty != other.actualQty)
			return false;
		if (carSeries == null) {
			if (other.carSeries != null)
				return false;
		} else if (!carSeries.equals(other.carSeries))
			return false;
		if (maxQty != other.maxQty)
			return false;
		if (ocfInfo == null) {
			if (other.ocfInfo != null)
				return false;
		} else if (!ocfInfo.equals(other.ocfInfo))
			return false;
		if (planYearMonth == null) {
			if (other.planYearMonth != null)
				return false;
		} else if (!planYearMonth.equals(other.planYearMonth))
			return false;
		return true;
	}
	
	public String outCSV() {
		StringBuffer sb = new StringBuffer(64);

		sb.append(System.getProperty("line.separator"));
		sb.append(this.planYearMonth).append(",");
		sb.append(this.carSeries).append(",");
		sb.append(this.ocfInfo.getFrameSortCode()).append(",");
		sb.append(this.ocfInfo.getOcfClassificationCode()).append(",");
		sb.append(this.ocfInfo.getLocationIdentificationCode()).append(",");
		sb.append(this.ocfInfo.getCarGroup()).append(",");
		sb.append(this.ocfInfo.getFrameCode()).append(",");
		sb.append(this.maxQty).append(",");
		sb.append(this.actualQty);
		
		return sb.toString();
	}
}
