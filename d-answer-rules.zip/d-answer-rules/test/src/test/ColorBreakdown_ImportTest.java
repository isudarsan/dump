package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.colorbreakdown.ColorBreakdownResult;
import com.nissan.danswer.model.colorbreakdown.ColorBreakdownResultList;
import com.nissan.danswer.model.colorbreakdown.ColorRatio;
import com.nissan.danswer.model.colorbreakdown.ColorRatioList;
import com.nissan.danswer.model.colorbreakdown.ProductionOrderImport;
import com.nissan.danswer.model.colorbreakdown.ProductionOrderImportList;
import com.nissan.danswer.model.colorbreakdown.RecommendedOrder;
import com.nissan.danswer.model.colorbreakdown.RecommendedOrderList;

/**
 * カラー配分（輸入車）ルールテスト
 * @author matsuda
 *
 */
public class ColorBreakdown_ImportTest {

	// 最大fire件数
	private static int MAX_FIRE = 3000;
	
	// DRLファイル名
	private static String drlName = "ColorBreakdownImport.drl";	
	// テストデータ格納場所
	private static String filepath = "../d-answer-testdata/data/colorbd_import";
	
	// flowファイル名
	private static String rfName = "ColorBreakdownImport.rf";
	// flowID
	private static String flowID = "com.nissan.danswer.flow.colorbreakdownimport";
	
	// knowledgeBase
	private static KnowledgeBase kbase = null;
	
	// knowledge session
	private StatefulKnowledgeSession ksession;
	
	// logger
	private KnowledgeRuntimeLogger logger = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource(drlName),ResourceType.DRL);
    	kbuilder.add(ResourceFactory.newClassPathResource(rfName),ResourceType.DRF);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	}
	
	@Before
	public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();
        
        //logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/ColorBreakdownImport");	
	}
	
	@After
	public void tearDown() {
		if (logger != null) {
			logger.close();
		}
		// dispose a knowledge session
		if (ksession != null) {
			ksession.dispose();			
		}
	}
	
	/**
	 * testCase1
	 */
	@Test
	public void testCase1() {
		try {
			// input Fact list
			ColorRatioList ratioList = makeColorRatioList(filepath + "/testCase1/coloratio.csv");
			RecommendedOrderList recommendedList = makeRecommendedList(filepath + "/testCase1/recommended.csv");
			ProductionOrderImportList orderList = makeOrderImportList(filepath + "/testCase1/order_import.csv");
			ColorBreakdownResultList resultList = new ColorBreakdownResultList();
			
			ksession.insert(ratioList);			// IN
			ksession.insert(recommendedList);	// IN
			ksession.insert(orderList);			// IN
			ksession.insert(resultList);		// OUT
			
			// startProcess
			ksession.startProcess(flowID);
			
			Date startDate = new Date();
			
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);		
			
			Date endDate = new Date();
			System.out.println("====> testCase1 run");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
	
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MatchingResult予測結果
			ColorBreakdownResultList expectedResult = makeResultList(filepath + "/testCase1/result.csv");
			// 予測と実際を比較
			checkColorBreakdownResult(expectedResult, resultList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * testCase2
	 */
	@Test
	public void testCase2() {
		try {
			// input Fact list
			ColorRatioList ratioList = makeColorRatioList(filepath + "/testCase2/coloratio.csv");
			RecommendedOrderList recommendedList = makeRecommendedList(filepath + "/testCase2/recommended.csv");
			ProductionOrderImportList orderList = makeOrderImportList(filepath + "/testCase2/order_import.csv");
			ColorBreakdownResultList resultList = new ColorBreakdownResultList();
			
			ksession.insert(ratioList);			// IN
			ksession.insert(recommendedList);	// IN
			ksession.insert(orderList);			// IN
			ksession.insert(resultList);		// OUT
			// startProcess
			ksession.startProcess(flowID);
			
			Date startDate = new Date();
			
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);		
			
			Date endDate = new Date();
			System.out.println("====> testCase2 run");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
	
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MatchingResult予測結果
			ColorBreakdownResultList expectedResult = makeResultList(filepath + "/testCase2/result.csv");
			// 予測と実際を比較
			checkColorBreakdownResult(expectedResult, resultList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * testCase3
	 */
	@Test
	public void testCase3() {
		try {
			// input Fact list
			ColorRatioList ratioList = makeColorRatioList(filepath + "/testCase3/coloratio.csv");
			RecommendedOrderList recommendedList = makeRecommendedList(filepath + "/testCase3/recommended.csv");
			ProductionOrderImportList orderList = makeOrderImportList(filepath + "/testCase3/order_import.csv");
			ColorBreakdownResultList resultList = new ColorBreakdownResultList();
			
			ksession.insert(ratioList);			// IN
			ksession.insert(recommendedList);	// IN
			ksession.insert(orderList);			// IN
			ksession.insert(resultList);		// OUT
			// startProcess
			ksession.startProcess(flowID);
			
			Date startDate = new Date();
			
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);		
			
			Date endDate = new Date();
			System.out.println("====> testCase3 run");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
	
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MatchingResult予測結果
			ColorBreakdownResultList expectedResult = makeResultList(filepath + "/testCase3/result.csv");
			// 予測と実際を比較
			checkColorBreakdownResult(expectedResult, resultList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * testCase4
	 */
	@Test
	public void testCase4() {
		try {
			// input Fact list
			ColorRatioList ratioList = makeColorRatioList(filepath + "/testCase4/coloratio.csv");
			RecommendedOrderList recommendedList = makeRecommendedList(filepath + "/testCase4/recommended.csv");
			ProductionOrderImportList orderList = makeOrderImportList(filepath + "/testCase4/order_import.csv");
			ColorBreakdownResultList resultList = new ColorBreakdownResultList();
			
			ksession.insert(ratioList);			// IN
			ksession.insert(recommendedList);	// IN
			ksession.insert(orderList);			// IN
			ksession.insert(resultList);		// OUT
			// startProcess
			ksession.startProcess(flowID);
			
			Date startDate = new Date();
			
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);		
			
			Date endDate = new Date();
			System.out.println("====> testCase4 run");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
	
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MatchingResult予測結果
			ColorBreakdownResultList expectedResult = makeResultList(filepath + "/testCase4/result.csv");
			// 予測と実際を比較
			checkColorBreakdownResult(expectedResult, resultList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * testCase5
	 */
	@Test
	public void testCase5() {
		try {
			// input Fact list
			ColorRatioList ratioList = makeColorRatioList(filepath + "/testCase5/coloratio.csv");
			RecommendedOrderList recommendedList = makeRecommendedList(filepath + "/testCase5/recommended.csv");
			ProductionOrderImportList orderList = makeOrderImportList(filepath + "/testCase5/order_import.csv");
			ColorBreakdownResultList resultList = new ColorBreakdownResultList();
			
			ksession.insert(ratioList);			// IN
			ksession.insert(recommendedList);	// IN
			ksession.insert(orderList);			// IN
			ksession.insert(resultList);		// OUT
			// startProcess
			ksession.startProcess(flowID);
			
			Date startDate = new Date();
			
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);		
			
			Date endDate = new Date();
			System.out.println("====> testCase5 run");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
	
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MatchingResult予測結果
			ColorBreakdownResultList expectedResult = makeResultList(filepath + "/testCase5/result.csv");
			// 予測と実際を比較
			checkColorBreakdownResult(expectedResult, resultList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/************************************
	 * CSVファイルを読み込み、テストデータを作成する
	 * @throws Exception 
	 ************************************/
	public static RecommendedOrderList makeRecommendedList(String filename) throws Exception {
		String data[]=new String[7];
		RecommendedOrderList list = new RecommendedOrderList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setRecommended(
						data[0], data[1], data[2], data[3],
						data[4], data[5], Integer.valueOf(data[6]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	// COLOR_RATIO
	public static ColorRatioList makeColorRatioList(String filename) throws Exception {
		String data[]=new String[8];
		ColorRatioList list = new ColorRatioList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setColorRatio(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], Double.valueOf(data[7]).doubleValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}
	
	// PRODUCTION_ORDER_IMPORT
	public static ProductionOrderImportList makeOrderImportList(String filename) throws Exception {
		String data[]=new String[7];
		ProductionOrderImportList list = new ProductionOrderImportList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setOrderImport(
						data[0], data[1], data[2], data[3],
						data[4], data[5], Integer.valueOf(data[6]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}
	
	// COLOR_BREAKDOWN_RESULT
	private ColorBreakdownResultList makeResultList(String filename) throws Exception {
		String data[]=new String[8];
		ColorBreakdownResultList list = new ColorBreakdownResultList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setResult(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], Integer.valueOf(data[7]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	private ColorBreakdownResult setResult(String ym, String car, String por,
			String family, String dealer, String model, String color,
			int qty) {
		
		ColorBreakdownResult result = new ColorBreakdownResult();
		result.setPlanYearMonth(ym);
		result.setCarSeries(car);
		result.setPorCode(por);
		result.setProductionFamilyCode(family);
		result.setDealerCode(dealer);
		result.setEndItemModelCode(model);
		result.setEndItemColorCode(color);
		result.setQty(qty);		
		
		return result;
	}

	private static RecommendedOrder setRecommended(String ym, String car,
			String por, String family, String dealer, String model,
			int qty) {
		
		RecommendedOrder order = new RecommendedOrder();
		order.setPlanYearMonth(ym);
		order.setCarSeries(car);
		order.setPorCode(por);
		order.setProductionFamilyCode(family);
		order.setDealerCode(dealer);
		order.setEndItemModelCode(model);
		order.setQty(qty);
		
		return order;
	}
	
	private static ProductionOrderImport setOrderImport(String ym, String car,
			String por, String family, String model, String color,
			int qty) {
		
		ProductionOrderImport order = new ProductionOrderImport();
		order.setPlanYearMonth(ym);
		order.setCarSeries(car);
		order.setPorCode(por);
		order.setProductionFamilyCode(family);
		order.setEndItemModelCode(model);
		order.setEndItemColorCode(color);
		order.setQty(qty);
		
		return order;
	}

	private static ColorRatio setColorRatio(String ym, String car,
			String por, String family, String dealer, String model,
			String color, double ratio) {
		
		ColorRatio colorRatio = new ColorRatio();
		colorRatio.setPlanYearMonth(ym);
		colorRatio.setCarSeries(car);
		colorRatio.setPorCode(por);
		colorRatio.setProductionFamilyCode(family);
		colorRatio.setDealerCode(dealer);
		colorRatio.setEndItemModelCode(model);
		colorRatio.setEndItemColorCode(color);
		colorRatio.setRatio(ratio);
		
		return colorRatio;
	}
	
	private void checkColorBreakdownResult(ColorBreakdownResultList expected, ColorBreakdownResultList actual) {

		assertTrue(actual.size() > 0);
		
		assertEquals(expected.size(), actual.size());
		
		// 格納順序は保証しないため、一致を確かめるために、DEALER_CODE,EI_MODEL_CODE,EI_COLOR_CODEの昇順にソート
		Collections.sort(expected, new Comparator<Object>() {
			public int compare(Object lhs, Object rhs) {
				try {
					ColorBreakdownResult lhsResult = (ColorBreakdownResult)lhs;
					ColorBreakdownResult rhsResult = (ColorBreakdownResult)rhs;
					if (lhsResult.getDealerCode().compareTo(rhsResult.getDealerCode()) == 0) {
						if (lhsResult.getEndItemModelCode().compareTo(rhsResult.getEndItemModelCode()) == 0) {
							return lhsResult.getEndItemColorCode().compareTo(rhsResult.getEndItemColorCode());
						} else {
							return lhsResult.getEndItemModelCode().compareTo(rhsResult.getEndItemModelCode());
						}
					} else {
						return lhsResult.getDealerCode().compareTo(rhsResult.getDealerCode());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return 0;
			}
		});
		
		Collections.sort(actual, new Comparator<Object>() {
			public int compare(Object lhs, Object rhs) {
				try {
					ColorBreakdownResult lhsResult = (ColorBreakdownResult)lhs;
					ColorBreakdownResult rhsResult = (ColorBreakdownResult)rhs;
					if (lhsResult.getDealerCode().compareTo(rhsResult.getDealerCode()) == 0) {
						if (lhsResult.getEndItemModelCode().compareTo(rhsResult.getEndItemModelCode()) == 0) {
							return lhsResult.getEndItemColorCode().compareTo(rhsResult.getEndItemColorCode());
						} else {
							return lhsResult.getEndItemModelCode().compareTo(rhsResult.getEndItemModelCode());
						}
					} else {
						return lhsResult.getDealerCode().compareTo(rhsResult.getDealerCode());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return 0;
			}
		});
		
		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
			assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
			assertEquals(expected.get(idx).getDealerCode(), actual.get(idx).getDealerCode());
			assertEquals(expected.get(idx).getQty(), actual.get(idx).getQty());
		}
		
	}

}
