package test;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
//import org.drools.logger.KnowledgeRuntimeLogger;
//import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.ocfslotting.EndItemBreakdownResult;
import com.nissan.danswer.model.ocfslotting.EndItemSlottingResult;
import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.ocfslotting.MonthlyOCF;
import com.nissan.danswer.model.ocfslotting.EndItemBreakdownResultList;
import com.nissan.danswer.model.ocfslotting.EndItemSlottingResultList;
import com.nissan.danswer.model.ocfslotting.MonthlyOCFList;
import com.nissan.danswer.model.ocfslotting.OCFSlottingResult;
import com.nissan.danswer.model.ocfslotting.OrderInfo;
import com.nissan.danswer.model.ocfslotting.OrderInfoList;
import com.nissan.danswer.model.ocfslotting.MonthlySpecOCF;
import com.nissan.danswer.model.ocfslotting.MonthlySpecOCFList;


public class OcfSlottingTest {

	// 最大fire件数
	private static int MAX_FIRE = 5000;
	
	// DRLファイル名
	private static String drlName = "OCFSlotting.drl";
	// テストデータ格納場所
	private static String filepath = "../d-answer-testdata/data/ocfslotting";
	
	// DRFファイル名
	private static String rfName = "OCFSlotting.rf";
	// flowID
	private static String flowID = "com.nissan.danswer.flow.ocfslotting";
	
	// knowledgeBase
	private static KnowledgeBase kbase = null;
	
	// knowledge session
	private StatefulKnowledgeSession ksession;
	
	// logger
	private KnowledgeRuntimeLogger logger = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource(drlName),ResourceType.DRL);
    	kbuilder.add(ResourceFactory.newClassPathResource(rfName),ResourceType.DRF);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	}
	
	@Before
	public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();
        
        //logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/OcfSlottingTest");	
	}
	
	@After
	public void tearDown() {
		if (logger != null) {
			logger.close();
		}
		// dispose a knowledge session
		if (ksession != null) {
			ksession.dispose();			
		}
	}
	
	/**
	 * Monthly(N-1～N+6か月分） →　しかしここでは、2か月分でテスト
	 */
	@Test
	public void testMonthly() {
		
		try {
			// input Fact list
			EndItemBreakdownResultList bdList = makeEIBreakdownList(filepath + "/testMonthly/breakdown_result.csv");
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testMonthly/monthly_ocf.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testMonthly/spec_ocf.csv");	
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();	
			
			ksession.insert(bdList);	// IN
			ksession.insert(ocfList);	// IN/OUT
			ksession.insert(specList);	// IN
			ksession.insert(slotList);	// OUT
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testMonthly run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MonthlyOCF予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testMonthly/result_ocf.csv");
			
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
			
			// OCFSlotResult予測結果
			EndItemSlottingResultList resultSlot_1 = makeResultEISlottingList(filepath + "/testMonthly/result_eislotting_1.csv");
			EndItemSlottingResultList resultSlot_2 = makeResultEISlottingList(filepath + "/testMonthly/result_eislotting_2.csv");
	
			// OCFSlotResult実際の結果を年月ごとに分別
			EndItemSlottingResultList list_1 = new EndItemSlottingResultList();
			EndItemSlottingResultList list_2 = new EndItemSlottingResultList();
	
			for (EndItemSlottingResult slottingResult : slotList) {
				if (slottingResult.getPlanYearMonth().equals("201304")) {
					list_1.add(slottingResult);
				} else if (slottingResult.getPlanYearMonth().equals("201305")) {
					list_2.add(slottingResult);
				}
			}
			
			// 予測と実際を比較
			checkSlottingResult(resultSlot_1, list_1);
			checkSlottingResult(resultSlot_2, list_2);

		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	private void checkOcfResult(MonthlyOCFList resultOcf, MonthlyOCFList ocfList) {
		
		assertTrue(ocfList.size() > 0);
		
		assertEquals(resultOcf.size(), ocfList.size());
		
		for (int idx = 0; idx < ocfList.size(); idx++) {
			MonthlyOCF monthlyOCF = ocfList.get(idx);
			assertEquals(resultOcf.get(idx).getPlanYearMonth(), monthlyOCF.getPlanYearMonth());
			assertEquals(resultOcf.get(idx).getCarSeries(), monthlyOCF.getCarSeries());
			assertEquals(resultOcf.get(idx).getOcfInfo().getFrameSortCode(), monthlyOCF.getOcfInfo().getFrameSortCode());
			assertEquals(resultOcf.get(idx).getOcfInfo().getOcfClassificationCode(), monthlyOCF.getOcfInfo().getOcfClassificationCode());
			assertEquals(resultOcf.get(idx).getOcfInfo().getLocationIdentificationCode(), monthlyOCF.getOcfInfo().getLocationIdentificationCode());
			assertEquals(resultOcf.get(idx).getOcfInfo().getCarGroup(), monthlyOCF.getOcfInfo().getCarGroup());
			assertEquals(resultOcf.get(idx).getOcfInfo().getFrameCode(), monthlyOCF.getOcfInfo().getFrameCode());
			assertEquals(resultOcf.get(idx).getMaxQty(), monthlyOCF.getMaxQty());
			assertEquals(resultOcf.get(idx).getActualQty(), monthlyOCF.getActualQty());
		}
	}
	
	private void checkSlottingResult(EndItemSlottingResultList result, EndItemSlottingResultList actual) {
		
		assertTrue(actual.size() > 0);
		
		assertEquals(result.size(), actual.size());
		
		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(result.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(result.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(result.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(result.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(result.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
			assertEquals(result.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
			assertEquals(result.get(idx).getSeqId(), actual.get(idx).getSeqId());
			assertEquals(result.get(idx).getOcfSlottingList(), actual.get(idx).getOcfSlottingList());
			//System.out.println(result.get(idx).getPlanYearMonth() + ":" + idx);
		}
	}
	
	/**
	 * FloorPlan(N月のみ)
	 * COLOR情報なし
	 */
	@Test
	public void testFloorPlan() {
		
		try {
			// input Fact list
			EndItemBreakdownResultList bdList = makeEIBreakdownList(filepath + "/testFloorPlan/breakdown_result.csv");
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testFloorPlan/monthly_ocf.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testFloorPlan/spec_ocf.csv");	
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(bdList);	// IN
			ksession.insert(ocfList);	// IN/OUT
			ksession.insert(specList);	// IN
			ksession.insert(slotList);	// OUT
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testFloorPlan run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MonthlyOCF予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testFloorPlan/result_ocf.csv");
			
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
			
			// OCFSlotResult予測結果
			EndItemSlottingResultList resultSlot_1 = makeResultEISlottingList(filepath + "/testFloorPlan/result_eislotting.csv");
			
			checkSlottingResult(resultSlot_1, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * FloorPlan(N月のみ)
	 * COLOR情報なし
	 */
	@Test
	public void testFloorPlan2() {
		try {
			// input Fact list
			EndItemBreakdownResultList bdList = makeEIBreakdownList(filepath + "/testFloorPlan2/breakdown_result.csv");
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testFloorPlan2/monthly_ocf.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testFloorPlan2/spec_ocf.csv");		
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(bdList);	// IN
			ksession.insert(ocfList);	// IN/OUT
			ksession.insert(specList);	// IN
			ksession.insert(slotList);	// OUT
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testFloorPlan2 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MonthlyOCF予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testFloorPlan2/result_ocf.csv");
			
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
			
			// OCFSlotResult予測結果
			EndItemSlottingResultList resultSlot_1 = makeResultEISlottingList(filepath + "/testFloorPlan2/result_eislotting.csv");
			
			checkSlottingResult(resultSlot_1, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}	
	
	/**
	 * FloorPlan(N月のみ）
	 * SpecialOrderの枠埋め
	 */
	@Test
	public void testSP() {
		
		try {
			// input Fact list
			OrderInfoList orderList = makeOrderInfoList(filepath + "/testSP/orderinfo.csv");
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testSP/monthly_ocf.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testSP/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(orderList);	// IN
			ksession.insert(ocfList);	// IN/OUT
			ksession.insert(specList);	// IN
			ksession.insert(slotList);	// OUT
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testSP run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MonthlyOCF予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testSP/result_ocf.csv");
			
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
			
			// OCFSlotResult予測結果
			EndItemSlottingResultList resultSlot_1 = makeResultEISlottingList(filepath + "/testSP/result_eislotting.csv");
			
			// 件数チェック
			assertTrue(slotList.size() > 0);
			
			// 予測と実際を比較
			checkSlottingResult(resultSlot_1, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * FloorPlan(N月のみ）
	 * DirectSalesの枠埋め
	 */
	@Test
	public void testDS() {
		
		try {
			// input Fact list
			OrderInfoList orderList = makeOrderInfoList(filepath + "/testDS/orderinfo.csv");
			MonthlyOCFList ocfList  = makeMonthlyOcfList(filepath + "/testDS/monthly_ocf.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testDS/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(orderList);	// IN
			ksession.insert(ocfList);	// IN/OUT
			ksession.insert(specList);	// IN
			ksession.insert(slotList);	// OUT
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testDS run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MonthlyOCF予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testDS/result_ocf.csv");
			
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
			
			// OCFSlotResult予測結果
			EndItemSlottingResultList resultSlot_1 = makeResultEISlottingList(filepath + "/testDS/result_eislotting.csv");
			
			// 予測と実際を比較
			checkSlottingResult(resultSlot_1, slotList);
		
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * FP・データ異常系
	 */
	//@Test
	public void testCase1() {
		
		try {
			// input Fact list
			EndItemBreakdownResultList bdList;
			MonthlyOCFList ocfList;
			MonthlySpecOCFList specList;
			EndItemSlottingResultList slotList;
			
			bdList = makeEIBreakdownList(filepath + "/testCase1/breakdown_result.csv");
			ocfList = makeMonthlyOcfList(filepath + "/testCase1/monthly_ocf.csv");
			specList = makeSpecOcfList(filepath + "/testCase1/spec_ocf.csv");
			
			slotList = new EndItemSlottingResultList();
			
			ksession.insert(bdList);	// IN
			ksession.insert(ocfList);	// IN/OUT
			ksession.insert(specList);	// IN
			ksession.insert(slotList);	// OUT
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase1 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			
			// MonthlyOCF予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase1/result_ocf.csv");
			
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
			
			// OCFSlotResult予測結果
			EndItemSlottingResultList resultSlot_1 = makeResultEISlottingList(filepath + "/testCase1/result_eislotting.csv");
			
			// 件数チェック
			assertTrue(slotList.size() > 0);
			
			// 予測と実際を比較
			checkSlottingResult(resultSlot_1, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/************************************
	 * CSVファイルを読み込み、テストデータを作成する
	 * @throws Exception 
	 ************************************/
	// SPEC_OCF
	public static MonthlySpecOCFList makeSpecOcfList(String filename) throws Exception {
		String data[]=new String[11];
		MonthlySpecOCFList list = new MonthlySpecOCFList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			int i = 0;
			while((line = bufferedreader.readLine()) != null) {
				//System.out.println("Start line at " + i);
				data = line.split(",", -1);
				if (i > 0 &&
						list.get(i-1).getPlanYearMonth().equals(data[0]) &&
						list.get(i-1).getCarSeries().equals(data[1]) &&
						list.get(i-1).getPorCode().equals(data[2]) &&
						list.get(i-1).getProductionFamilyCode().equals(data[3]) &&
						list.get(i-1).getEndItemModelCode().equals(data[4]) &&
						list.get(i-1).getEndItemColorCode().equals(data[5])) {
					// EIキーが同じ場合は、OCF情報のみを追加
					list.get(i-1).getOcfList().add(setOcfInfo(data[6], data[7], data[8], data[9], data[10]));					
				} else {
					// 新規行追加
					list.add(setSpecOCF(
							data[0], data[1], data[2], data[3],
							data[4], data[5], data[6], data[7],
							data[8], data[9], data[10]));
					i++;
				}
			}
			//System.out.println(i+"a");	
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	// MONTHLY_OCF
	public static MonthlyOCFList makeMonthlyOcfList(String filename) throws Exception {
		String data[]=new String[9];
		MonthlyOCFList list = new MonthlyOCFList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setMonthlyOCF(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], Integer.valueOf(data[7]).intValue(), Integer.valueOf(data[8]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	// ORDER_INFO
	public static OrderInfoList makeOrderInfoList(String filename) throws Exception {
		String data[]=new String[11];
		OrderInfoList list = new OrderInfoList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setOrderInfo(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], data[7],
						data[8], data[9], data[10]));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	// EI_BREAKDOWN_RESULT
	public static EndItemBreakdownResultList makeEIBreakdownList(String filename) throws Exception {
		String data[]=new String[7];
		EndItemBreakdownResultList list = new EndItemBreakdownResultList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setEIResult(
						data[0], data[1], data[2], data[3],
						data[4], data[5], Integer.valueOf(data[6]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	public static MonthlyOCF setMonthlyOCF(String ym, String car, String sort, String ocfClass, String loc, String group, String frame,
			int maxQty, int actualQty) {
		
		MonthlyOCF ocfMonthly = new MonthlyOCF();
		ocfMonthly.setPlanYearMonth(ym);
		ocfMonthly.setCarSeries(car);
		ocfMonthly.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
		ocfMonthly.setMaxQty(maxQty);
		ocfMonthly.setActualQty(actualQty);
		
		return ocfMonthly;
	}
	
	public static OCFIdentificationInfo setOcfInfo(String sort, String ocfClass, String loc, String group, String frame) {
		
		OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
		ocfInfo.setFrameSortCode(sort);
		ocfInfo.setOcfClassificationCode(ocfClass);
		ocfInfo.setLocationIdentificationCode(loc);
		ocfInfo.setCarGroup(group);
		ocfInfo.setFrameCode(frame);
		
		return ocfInfo;
	}
	
	public static MonthlySpecOCF setSpecOCF(String ym, String car, String por, String family, String model, String color, String sort, 
			String ocfclass, String loc, String group, String frame) {
		
		MonthlySpecOCF spec = new MonthlySpecOCF();
		spec.setPlanYearMonth(ym);
		spec.setCarSeries(car);
		spec.setPorCode(por);
		spec.setProductionFamilyCode(family);
		spec.setEndItemModelCode(model);
		spec.setEndItemColorCode(color);
		
		List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
		ocfList.add(setOcfInfo(sort, ocfclass, loc, group, frame));
		
		spec.setOcfList(ocfList);
		
		return spec;
	}
	
	public static OrderInfo setOrderInfo(String ym, String car, String por, String family, String model, String color,
			String seqId, String sortKey1, String sortKey2, String sortKey3, String orderType) {
		
		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setPlanYearMonth(ym);
		orderInfo.setCarSeries(car);
		orderInfo.setPorCode(por);
		orderInfo.setProductionFamilyCode(family);
		orderInfo.setEndItemModelCode(model);
		orderInfo.setEndItemColorCode(color);
		orderInfo.setSeqId(seqId);
		orderInfo.setSortKey1(sortKey1);
		orderInfo.setSortKey2(sortKey2);
		orderInfo.setSortKey3(sortKey3);
		orderInfo.setOrderType(orderType);
		
		return orderInfo;
	}

	/************************************
	 * 予測結果データ作成
	 * @throws Exception 
	 ************************************/
	private EndItemSlottingResultList makeResultEISlottingList(String filename) throws Exception {
		String data[]=new String[13];
		EndItemSlottingResultList list = new EndItemSlottingResultList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			int i = 0;
			while((line = bufferedreader.readLine()) != null) {
				//System.out.println("Start line at " + i);
				data = line.split(",", -1);
				if (!"00".equals(data[11])) {
					// キーが同じ場合は、OCF情報のみを追加
					list.get(i-1).getOcfSlottingList().add(setOcfSlotResult(data[0],data[1],
							setOcfInfo(data[7], data[8], data[9], data[10], data[11]), 
							data[12]));					
				} else {
					// 新規行追加
					list.add(setEISlotResult(
							data[0], data[1], data[2], data[3],
							data[4], data[5], data[6], data[7],
							data[8], data[9], data[10], data[11], data[12]));
					i++;
				}
			}
			//System.out.println(i+"a");	
			filereader.close();
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	private static EndItemBreakdownResult setEIResult(String ym, String car, String por, String family, String model, String color, int qty) {
		
		EndItemBreakdownResult eiResult = new EndItemBreakdownResult();
		eiResult.setPlanYearMonth(ym);
		eiResult.setCarSeries(car);
		eiResult.setPorCode(por);
		eiResult.setProductionFamilyCode(family);
		eiResult.setEndItemModelCode(model);
		eiResult.setEndItemColorCode(color);
		eiResult.setQty(qty);
		
		return eiResult;
	}

	private EndItemSlottingResult setEISlotResult(String ym, String car, String por, String family, String model,
			String color, String seqId, String sort, String ocfClass, String loc, String group, String frame, String slotOkFlg) {
		
		EndItemSlottingResult eiResult = new EndItemSlottingResult();
		eiResult.setPlanYearMonth(ym);
		eiResult.setCarSeries(car);
		eiResult.setPorCode(por);
		eiResult.setProductionFamilyCode(family);
		eiResult.setEndItemModelCode(model);
		eiResult.setEndItemColorCode(color);
		eiResult.setSeqId("".equals(seqId) ? null : seqId);
		
		List<OCFSlottingResult> ocfSlottingList = new ArrayList<OCFSlottingResult>();
		OCFSlottingResult ocfSlotResult = new OCFSlottingResult();
		ocfSlotResult.setPlanYearMonth(ym);
		ocfSlotResult.setCarSeries(car);
		ocfSlotResult.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
		ocfSlotResult.setSlotOkFlg("true".equals(slotOkFlg) ? true : false);
		ocfSlottingList.add(ocfSlotResult);
		
		eiResult.setOcfSlottingList(ocfSlottingList);

		return eiResult;
	}

	private OCFSlottingResult setOcfSlotResult(String ym, String car,
			OCFIdentificationInfo ocfInfo, String slotOkFlg) {
		
		OCFSlottingResult slotResult = new OCFSlottingResult();
		slotResult.setPlanYearMonth(ym);
		slotResult.setCarSeries(car);
		slotResult.setOcfInfo(ocfInfo);
		slotResult.setSlotOkFlg("true".equals(slotOkFlg) ? true : false);
		
		return slotResult;
	}

}
