package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ColorBreakdown_ImportTest.class,
		ColorBreakdown_NationalTest.class, DealerAllocationTest.class,
		EndItemBreakdownTest.class, InventoryAllocTest.class,
		OcfSlottingTest.class, ReAllocationTest.class, ScheduleCheckTest.class,
		StockCoverTest.class })
public class AllTests {

}
