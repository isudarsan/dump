package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.dealerallocation.DealerAllocationResult;
import com.nissan.danswer.model.inventoryallocation.FixProductionInventory;
import com.nissan.danswer.model.inventoryallocation.FixProductionInventoryList;
import com.nissan.danswer.model.inventoryallocation.Inventory;
import com.nissan.danswer.model.inventoryallocation.InventoryList;
import com.nissan.danswer.model.inventoryallocation.Order;
import com.nissan.danswer.model.inventoryallocation.OrderList;
import com.nissan.danswer.model.inventoryallocation.OutOrderList;
import com.nissan.danswer.model.inventoryallocation.StorageYardPriorityByDealer;
import com.nissan.danswer.model.inventoryallocation.StorageYardPriorityByDealerList;

@SuppressWarnings("restriction")
public class InventoryAllocTest {

    // 最大fire件数
    private static int MAX_FIRE = 500000;

    // DRLファイル名
    private static String drlName = "InventoryAlloc.drl";
    // テストデータ格納場所
    private static String filepath = "../d-answer-testdata/data/inventoryallocation";

    // DRFファイル名
    private static String rfName = "InventoryAlloc.rf";
    // flowID
    private static String flowID = "com.nissan.danswer.flow.inventoryallocation";

    // knowledgeBase
    private static KnowledgeBase kbase = null;

    // knowledge session
    private StatefulKnowledgeSession ksession;

    // logger
    private KnowledgeRuntimeLogger logger = null;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {

        // knowledgeBuilder
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
                .newKnowledgeBuilder();

        // add resources to KnowledgeBuilder
        kbuilder.add(ResourceFactory.newClassPathResource(drlName), ResourceType.DRL);
    	kbuilder.add(ResourceFactory.newClassPathResource(rfName), ResourceType.DRF);

        // knowledgeBuilderErrors
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error : errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }

        // knowledgeBase
        kbase = KnowledgeBaseFactory.newKnowledgeBase();

        // add knowledgePackages to knowledgeBase
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
    }

    @Before
    public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();

        logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
                    "log/InventoryAlloc-audit");
    }

    @After
    public void tearDown() {
        if (logger != null) {
            logger.close();
        }
        // dispose a knowledge session
        if (ksession != null) {
            ksession.dispose();
        }
    }

    /**
     * ルール空実行
     */
    @Test
    public void testEmpty() {
        System.out.println("TEST OF empty");
        ksession.startProcess(flowID);

        // fire
        int fireCnt = ksession.fireAllRules(MAX_FIRE);

        assertEquals(0, fireCnt);

        System.out.println("empty");
    }

    // オールNGのテスト
    @Test
    public void testCase01() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase01/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase01/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase01/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase01/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase01 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath + "/testCase01/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            
            // OUTの結果が2件であること
            assertEquals(2, out.size());
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }    
    // ソートNoのテスト
    @Test
    public void testCase02() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase02/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase02/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase02/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase02/storageYard.csv");
    
            ksession.insert(odList);
            ksession.insert(new OutOrderList());
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase02 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase02/order_result.csv");
    
            Collections.sort(resultOrder, new OrderComparator());
            Collections.sort(odList,      new OrderComparator());
            
            // 予測と実際を比較
            for (Order order : odList) {
                int idx = odList.indexOf(order);
                System.out.println("Order = " + order);
                assertEquals(resultOrder.get(idx).getSortNo(), order.getSortNo());
            }
    		ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // オーダー順(実在庫)のテスト
    @Test
    public void testCase03() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase03/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase03/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase03/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase03/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase03 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath + "/testCase03/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
    		ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase04() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase04/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase04/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase04/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase04/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase04 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase04/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
    		ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase05() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase05/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase05/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase05/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase05/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase05 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath + "/testCase05/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
    		ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase06() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase06/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase06/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase06/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase06/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase06 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath + "/testCase06/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
    		ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase07() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase07/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase07/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase07/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase07/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase07 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase07/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            
            assertTrue(odList.size() == 2); // inData size
            assertTrue(out.size() == 1); // outData size 引当て件数1
            System.out.println("number of orders          = " + odList.size());
            System.out.println("number of assigned orders = " + out.size());
            for (Order order : out) {
                System.out.println("OutOrder = " + order);
            }
    		ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
		
    }

    @Test
    public void testCase08() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase08/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase08/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase08/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase08/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase08 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase08/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            
            assertTrue(odList.size() == 2); // inData size
            assertTrue(out.size() == 2); // outData size 引当て件数1
            System.out.println("number of orders          = " + odList.size());
            System.out.println("number of assigned orders = " + out.size());
            for (Order order : out) {
                System.out.println("OutOrder = " + order);
            }
        	ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }
    
    // FixProductionInvantoryのsortNoテスト
    @Test
    public void testCase09() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase09/fix-product-inv.csv");
            for (FixProductionInventory inv : fixInvList) {
                inv.setSortNo(new BigDecimal("0"));
                ksession.insert(inv);
            }
            
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            Collections.sort(fixInvList, new FixProductionInventoryComparator());
            assertEquals(new BigDecimal("20130601201306012013060320130603"), fixInvList.get(0).getSortNo());
            assertEquals(new BigDecimal("20130601201306012013060399999999"), fixInvList.get(1).getSortNo());
            assertEquals(new BigDecimal("20130601201306019999999999999999"), fixInvList.get(2).getSortNo());
            assertEquals(new BigDecimal("20130601999999999999999999999999"), fixInvList.get(3).getSortNo());
            assertEquals(new BigDecimal("99999999999999999999999999999999"), fixInvList.get(4).getSortNo());
    
    
            System.out.println("====> testCase09 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
        	ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // オーダー順(確定在庫)のテスト
    @Test
    public void testCase10() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase10/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase10/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase10/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase10/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(fixInvList);
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase10 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath + "/testCase10/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
        	ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // オーダー順(確定在庫)のテスト
    @Test
    public void testCase10_1() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase10-1/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase10-1/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase10-1/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase10-1/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(fixInvList);
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
            ksession.insert("JAPAN");
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath + "/testCase10-1/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // 生産確定在庫のリストがない場合(
    @Test
    public void testCase11() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase11/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase11/inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase11/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> " + (new Throwable().getStackTrace()[0].getMethodName()) + " run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase11/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase12() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase12/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase12/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase12/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase12/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> " + (new Throwable().getStackTrace()[0].getMethodName()) + " run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase12/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            
            assertTrue(odList.size() == 2); // inData size
            assertTrue(out.size() == 1); // outData size 引当て件数1
            System.out.println("number of orders          = " + odList.size());
            System.out.println("number of assigned orders = " + out.size());
            for (Order order : out) {
                System.out.println("OutOrder = " + order);
            }
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }

    }

    @Test
    public void testCase13() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase13/order.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath
                    + "/testCase13/fix-product-inv.csv");
            OutOrderList out = new OutOrderList();

            ksession.insert(odList);
            ksession.insert(fixInvList);
            ksession.insert(out);

            ksession.startProcess(flowID);

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            System.out.println("====> "
                    + (new Throwable().getStackTrace()[0].getMethodName())
                    + " run end");

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase13/order_result.csv");

            // 予測と実際を比較
            checkAll(out, resultOrder);

            assertTrue(odList.size() == 2); // inData size
            assertTrue(out.size() == 1); // outData size 引当て件数1
            System.out.println("number of orders          = " + odList.size());
            System.out.println("number of assigned orders = " + out.size());
            for (Order order : out) {
                System.out.println("OutOrder = " + order);
            }
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase20() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase20/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase20/inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase20/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
            ksession.insert("JAPAN");
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase04 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase20/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase21() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase21/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase21/inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase21/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> "+ new Throwable().getStackTrace()[0].getMethodName() + " end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase21/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase22() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase22/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase22/inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase22/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> "+ new Throwable().getStackTrace()[0].getMethodName() + " end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase22/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase23() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase23/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase23/inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase23/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> "+ new Throwable().getStackTrace()[0].getMethodName() + " end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase23/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void testCase24() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase24/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase24/inv.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> "+ new Throwable().getStackTrace()[0].getMethodName() + " end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
            OrderList resultOrder = makeOrderResultList(filepath
                    + "/testCase24/order_result.csv");
    
            // 予測と実際を比較
            checkAll(out, resultOrder);
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // 大量データテスト(結果未確認)
//    @Test
    public void testCase98() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase98/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase98/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase98/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase98/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(fixInvList);
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            Date startDate = new Date();
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
            Date endDate = new Date();
            System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + "run end");
            
            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
            
            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);
    
            System.out.println("====> testCase98 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            System.out.println("=================== OUT ==============");
    
            // HEADER
            System.out.println(
                    "VEHICLE_SEQ_ID\t" +
                    "DEALER_CODE\t" +
                    "END_ITEM_MODEL_CODE\t" +
                    "END_ITEM_COLOR_CODE\t" +
                    "ORDER_TYPE\t" +
                    "OFFLINE_DATE\t" +
                    "REALLOCATION_PRIORITY_NO\t" +
                    "INPUT_DATE_OF_ORDER\t" +
                    "WEEK_OF_DUE_DATE_FOR_DELOVERY\t" +
                    "DEALER_REPLY_FLG\t" +
                    "RANDOM_NO\t" +
                    "BOLSA_OR_NOT\t" +
                    "VIN_NO\t" +
                    "STORAGE_YARD_CODE\t" +
                    "FACTORY_CODE\t" +
                    "LINE_CLASS\t" +
                    "ACTUAL_FINAL_OK_DATE\t" +
                    "ACTUAL_OFFLINE_DATE\t" +
                    "PLAN_FINAL_OK_DATE\t" +
                    "PLAN_OFFLINE_DATE");
            for (Order o : out) {
                // IN items
                System.out.print(
                        String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                                o.getVehicleSeqId(),
                                o.getDealerCode(),
                                o.getEndItemModelCode(),
                                o.getEndItemColorCode(),
                                o.getOrderType(),
                                o.getOfflineDate(),
                                o.getReallocationPriorityNo(),
                                o.getInputDateOfOrder(),
                                o.getWeekOfDueDateForDelivery(),
                                o.getDealerReplyFlg(),
                                o.getRandomNo(),
                                o.getBolsaOrNot()));
                
                // OUT items
                System.out.println(
                        String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
                                o.getVinNo(),
                                o.getStorageYardCode(),
                                o.getFactoryCode(),
                                o.getLineClass(),
                                o.getActualFinalOkDate(),
                                o.getActualOfflineDate(),
                                o.getPlanFinalOkDate(),
                                o.getPlanOfflineDate()));
            }
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // @Test
    public void testCase99() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    
            // input Fact list
            OrderList odList = makeOrderList(filepath + "/testCase99/order.csv");
            InventoryList invList = makeInventoryList(filepath + "/testCase99/inv.csv");
            FixProductionInventoryList fixInvList = makeFixProductInvList(filepath + "/testCase99/fix-product-inv.csv");
            StorageYardPriorityByDealerList storageYardList = makeStorageYardList(filepath + "/testCase99/storageYard.csv");
            OutOrderList out = new OutOrderList();
    
            ksession.insert(odList);
            ksession.insert(invList);
            ksession.insert(fixInvList);
            ksession.insert(storageYardList);
            ksession.insert(out);
    
            ksession.startProcess(flowID);
    
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
    
            System.out.println("====> testCase99 run end");
    
            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
    
            // 予測結果
    //        OrderList resultOrder = makeOrderResultList(filepath + "/testCase99/order_result.csv");
    
            // 予測と実際を比較
    //        checkAll(out, resultOrder);
            
            System.out.println("=================== OUT ==============");
    
            // HEADER
            System.out.println(
                    "VEHICLE_SEQ_ID\t" +
                    "DEALER_CODE\t" +
                    "END_ITEM_MODEL_CODE\t" +
                    "END_ITEM_COLOR_CODE\t" +
                    "ORDER_TYPE\t" +
                    "OFFLINE_DATE\t" +
                    "REALLOCATION_PRIORITY_NO\t" +
                    "INPUT_DATE_OF_ORDER\t" +
                    "WEEK_OF_DUE_DATE_FOR_DELOVERY\t" +
                    "DEALER_REPLY_FLG\t" +
                    "RANDOM_NO\t" +
                    "BOLSA_OR_NOT\t" +
                    "VIN_NO\t" +
                    "STORAGE_YARD_CODE\t" +
                    "FACTORY_CODE\t" +
                    "LINE_CLASS\t" +
                    "ACTUAL_FINAL_OK_DATE\t" +
                    "ACTUAL_OFFLINE_DATE\t" +
                    "PLAN_FINAL_OK_DATE\t" +
                    "PLAN_OFFLINE_DATE");
            for (Order o : out) {
                // IN items
                System.out.print(
                        String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                                o.getVehicleSeqId(),
                                o.getDealerCode(),
                                o.getEndItemModelCode(),
                                o.getEndItemColorCode(),
                                o.getOrderType(),
                                o.getOfflineDate(),
                                o.getReallocationPriorityNo(),
                                o.getInputDateOfOrder(),
                                o.getWeekOfDueDateForDelivery(),
                                o.getDealerReplyFlg(),
                                o.getRandomNo(),
                                o.getBolsaOrNot()));
                
                // OUT items
                System.out.println(
                        String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
                                o.getVinNo(),
                                o.getStorageYardCode(),
                                o.getFactoryCode(),
                                o.getLineClass(),
                                o.getActualFinalOkDate(),
                                o.getActualOfflineDate(),
                                o.getPlanFinalOkDate(),
                                o.getPlanOfflineDate()));
            }
            
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /************************************
     * CSVファイルを読み込み、テストデータを作成する
     * @throws Exception 
     ************************************/
    public static FixProductionInventoryList makeFixProductInvList(
            String filename) throws Exception {
        FixProductionInventoryList list = new FixProductionInventoryList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        String data[];
        while ((line = bufferedreader.readLine()) != null) {
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            data = line.split(",", -1);
            list.add(setFixProductInv(
                    data[0], // VIN_NO
                    data[1], // END_ITEM_MODEL_CODE
                    data[2], // END_ITEM_COLOR_CODE
                    data[3], // FACTORY_CODE
                    data[4], // LINE_CLASS
                    data[5], // ACTUAL_FINAL_OK_DATE
                    data[6], // ACTUAL_OFFLINE_DATE
                    data[7], // PLAN_FINAL_OK_DATE
                    data[8])); // PLAN_OFFLINE_DATE
        }
        filereader.close();
        
        shuffle(list);
        return list;
    }

    public static InventoryList makeInventoryList(String filename) throws Exception {
        InventoryList list = new InventoryList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        String data[];
        while ((line = bufferedreader.readLine()) != null) {
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            data = line.split(",", -1);
            list.add(setInventory(
                    data[0], // VIN_NO
                    data[1], // END_ITEM_MODEL_CODE
                    data[2], // END_ITEM_COLOR_CODE
                    data[3], // STORAGE_YARD_CODE
                    data[4])); // DATE
        }
        filereader.close();

        shuffle(list);
        return list;
    }

    public static OrderList makeOrderList(String filename) throws Exception {
        OrderList list = new OrderList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        String data[];
        while ((line = bufferedreader.readLine()) != null) {
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            data = line.split(",", -1);
            list.add(setOrder(
                    data[0], // VEHICLE_SEQ_ID
                    data[1], // DEALER_CODE
                    data[2], // END_ITEM_MODEL_CODE
                    data[3], // END_ITEM_COLOR_CODE
                    data[4], // ORDER_TYPE
                    data[5], // OFFLINE_DATE
                    data[6], // RE_ALLOCATION_PRIORITY_NO
                    data[7], // INPUT_DATE_OF_ORDER
                    data[8], // WEEK_OF_DUE_DATE_FOR_DELIVERTY
                    data[9], // DEALER_REPLY_FLG
                    data[10], // RANDOM_NO
                    data[11])); // BOLSA_OR_NOT
        }
        filereader.close();

        
        shuffle(list);
        return list;
    }

    public static Inventory setInventory(String vinNo, String endItemModelCode,
            String endItemColorCode, String storageYardCode, String date) {
        Inventory inventory = new Inventory();
        inventory.setVinNo(vinNo);
        inventory.setEndItemModelCode(endItemModelCode);
        inventory.setEndItemColorCode(endItemColorCode);
        inventory.setStorageYardCode(storageYardCode);
        inventory.setDate(date);
        return inventory;
    }

    public static FixProductionInventory setFixProductInv(String vinNo,
            String endItemModelCode, String endItemColorCode,
            String factoryCode, String lineClass, String actualFinalOkDate,
            String actualOfflineDate, String planFinalOkDate,
            String planOfflineDate) {
        FixProductionInventory inv = new FixProductionInventory();
        inv.setVinNo(vinNo);
        inv.setEndItemModelCode(endItemModelCode);
        inv.setEndItemColorCode(endItemColorCode);
        inv.setFactoryCode(factoryCode);
        inv.setLineClass(lineClass);
        inv.setActualFinalOkDate(actualFinalOkDate);
        inv.setActualOfflineDate(actualOfflineDate);
        inv.setPlanFinalOkDate(planFinalOkDate);
        inv.setPlanOfflineDate(planOfflineDate);

        return inv;
    }

    public static StorageYardPriorityByDealerList makeStorageYardList(
            String filename) throws Exception {
        StorageYardPriorityByDealerList list = new StorageYardPriorityByDealerList();

        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        String data[];
        while ((line = bufferedreader.readLine()) != null) {
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            data = line.split(",", -1);
            list.add(setStorageYard(
                    data[0], // DEALER_CODE
                    data[1], // STORAGE_YARD_CODE
                    data[2])); // PRIORITY
        }
        filereader.close();
        
        shuffle(list);
        return list;
    }

    /************************************
     * 予測結果データ作成
     * @throws Exception 
     ************************************/
    public static OrderList makeOrderResultList(String filename) throws Exception {
        OrderList list = new OrderList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        String data[];
        while ((line = bufferedreader.readLine()) != null) {
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            data = line.split(",", -1);
            list.add(setOrderResult(data[0], // SORT_NO
                    data[1], // VEHICLE_SEQ_ID
                    data[2], // DEALER_CODE
                    data[3], // END_ITEM_MODEL_CODE
                    data[4], // END_ITEM_COLOR_CODE
                    data[5], // ORDER_TYPE
                    data[6], // OFFLINE_DATE
                    data[7], // RE_ALLOCATION_PRIORITY_NO
                    data[8], // INPUT_DATE_OF_ORDER
                    data[9], // WEEK_OF_DUE_DATE_FOR_DELIVERTY
                    data[10], // DEALER_REPLY_FLG
                    data[11], // RANDOM_NO
                    data[12], // BOLSA_OR_NOT
                    data[13], // VIN_NO
                    data[14], // STORAGE_YARD_CODE
                    data[15], // FACTORY_CODE
                    data[16], // LINE_CLASS
                    data[17], // ACTUAL_FINAL_OK_DATE
                    data[18], // ACTUAL_OFFLINE_OK_DATE
                    data[19], // PLAN_FINAL_OK_DATE
                    data[20])); // PLAN_OFFLINE_OK_DATE
        }
        filereader.close();

        shuffle(list);
        return list;
    }

    private static Order setOrder(String vehicleSeqId, String dealerCode,
            String endItemModelCode, String endItemColorCode, String orderType,
            String offlineDate, String reallocationPriorityNo,
            String inputDateOfOrder, String weekOfDueDateForDelivery,
            String dealerReplyFlg, String randomNo, String bolsaOrNot) {
        Order order = new Order();
        order.setVehicleSeqId(vehicleSeqId);
        order.setDealerCode(dealerCode);
        order.setEndItemModelCode(endItemModelCode);
        order.setEndItemColorCode(endItemColorCode);
        order.setOrderType(orderType);
        order.setOfflineDate("null".equals(offlineDate) ? null : offlineDate);
//        order.setOfflineDate(offlineDate);
        order.setReallocationPriorityNo(reallocationPriorityNo);
        order.setInputDateOfOrder(inputDateOfOrder);
        order.setWeekOfDueDateForDelivery(weekOfDueDateForDelivery);
        order.setDealerReplyFlg(dealerReplyFlg);
        order.setRandomNo(randomNo);
        order.setBolsaOrNot(bolsaOrNot);

        return order;
    }

    private static Order setOrderResult(String sortNo, String vehicleSeqId,
            String dealerCode, String endItemModelCode,
            String endItemColorCode, String orderType, String offlineDate,
            String reallocationPriorityNo, String inputDateOfOrder,
            String weekOfDueDateForDelivery, String dealerReplyFlg,
            String randomNo, String bolsaOrNot, String vinNo,
            String storageYardCode, String factoryCode, String lineClass,
            String actualFinalOkDate, String actualOfflineDate,
            String planFinalOkDate, String planOfflineDate) {
        Order order = new Order();
        order.setSortNo(new BigDecimal(sortNo));
        order.setVehicleSeqId(vehicleSeqId);
        order.setDealerCode(dealerCode);
        order.setEndItemModelCode(endItemModelCode);
        order.setEndItemColorCode(endItemColorCode);
        order.setOrderType(orderType);
        order.setOfflineDate(offlineDate);
        order.setReallocationPriorityNo(reallocationPriorityNo);
        order.setInputDateOfOrder(inputDateOfOrder);
        order.setWeekOfDueDateForDelivery(weekOfDueDateForDelivery);
        order.setDealerReplyFlg(dealerReplyFlg);
        order.setRandomNo(randomNo);
        order.setBolsaOrNot(bolsaOrNot);

        order.setVinNo(vinNo);
        order.setStorageYardCode(storageYardCode);
        order.setFactoryCode(factoryCode);
        order.setLineClass(lineClass);
        order.setActualFinalOkDate(actualFinalOkDate);
        order.setActualOfflineDate(actualOfflineDate);
        order.setPlanFinalOkDate(planFinalOkDate);
        order.setPlanOfflineDate(planOfflineDate);

        return order;
    }

    private static StorageYardPriorityByDealer setStorageYard(
            String dealerCode, String storage, String priority) {
        StorageYardPriorityByDealer storageYard = new StorageYardPriorityByDealer();
        storageYard.setDealerCode(dealerCode);
        storageYard.setStorageYardCode(storage);
        storageYard.setPriority(priority);

        return storageYard;
    }

    // Orderの比較(ソートNoで比較)
    private class OrderComparator implements Comparator<Object> {
        public int compare(Object self, Object other) {
            try {
                return ((Order) self).getSortNo().compareTo(((Order) other).getSortNo());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }
    }
    
    // FixProductionInventoryの比較(ソートNoで比較)
    private class FixProductionInventoryComparator implements Comparator<Object> {
        public int compare(Object self, Object other) {
            try {
                return ((FixProductionInventory) self).getSortNo().compareTo(((FixProductionInventory) other).getSortNo());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }
    }
    private void checkAll(OutOrderList results, OrderList expected) {
        System.out.println("result.size()=[" + results.size() + "], expected.size() = [" + expected.size() + "]");
        assertEquals(expected.size(), results.size()); // 結果と期待値のOrder数が異なる場合
        
        Collections.sort(results, new OrderComparator());
        Collections.sort(expected, new OrderComparator());

        for (int i = 0; i < results.size(); i++) {
            Order order = results.get(i);
            System.out.println("Order[" + i + "] = " + order);
            assertEquals(expected.get(i).getVehicleSeqId(), order.getVehicleSeqId());
            assertEquals(expected.get(i).getDealerCode(), order.getDealerCode());
            assertEquals(expected.get(i).getEndItemModelCode(), order.getEndItemModelCode());
            assertEquals(expected.get(i).getEndItemColorCode(), order.getEndItemColorCode());
            assertEquals(expected.get(i).getOrderType(), order.getOrderType());
            assertEquals(expected.get(i).getOfflineDate(), order.getOfflineDate());
            assertEquals(expected.get(i).getReallocationPriorityNo(), order.getReallocationPriorityNo());
            assertEquals(expected.get(i).getInputDateOfOrder(), order.getInputDateOfOrder());
            assertEquals(expected.get(i).getWeekOfDueDateForDelivery(), order.getWeekOfDueDateForDelivery());
            assertEquals(expected.get(i).getDealerReplyFlg(), order.getDealerReplyFlg());
            assertEquals(expected.get(i).getBolsaOrNot(), order.getBolsaOrNot());
            
            assertEquals(expected.get(i).getSortNo(), order.getSortNo());
            assertEquals(expected.get(i).getVinNo(), order.getVinNo() == null ? "" : order.getVinNo());
            assertEquals(expected.get(i).getStorageYardCode(), order.getStorageYardCode() == null ? "" : order.getStorageYardCode());
            assertEquals(expected.get(i).getFactoryCode(), order.getFactoryCode() == null ? "" : order.getFactoryCode());
            assertEquals(expected.get(i).getLineClass(), order.getLineClass() == null ? "" : order.getLineClass());
            assertEquals(expected.get(i).getActualFinalOkDate(), order.getActualFinalOkDate() == null ? "" : order.getActualFinalOkDate());
            assertEquals(expected.get(i).getActualOfflineDate(), order.getActualOfflineDate() == null ? "" : order.getActualOfflineDate());
            assertEquals(expected.get(i).getPlanFinalOkDate(), order.getPlanFinalOkDate() == null ? "" : order.getPlanFinalOkDate());
            assertEquals(expected.get(i).getPlanOfflineDate(), order.getPlanOfflineDate() == null ? "" : order.getPlanOfflineDate());
        }
    }

//    public static void shuffle(List list) {}
    public static void shuffle(List list) {
        final int size = list.size();
        for (int i = 0; i < size; i++) {
            java.util.Random rand = new java.util.Random();
            int destIndex = rand.nextInt(size);
            list.set(i, list.set(destIndex, list.get(i)));
        }
    }

//    // Orderの比較
//    private class OrderComparator implements Comparator<Object> {
//        public int compare(Object self, Object other) {
//            int comp = 0;
//            try {
//                final DealerAllocationResult selfOcf = (DealerAllocationResult) self;
//                final String selfKey = selfOcf.getPlanYearMonth()
//                        + selfOcf.getDealerCode()
//                        + selfOcf.getCarSeries()
//                        + selfOcf.getPorCode()
//                        + selfOcf.getEndItemModelCode()
//                        + selfOcf.getProductionFamilyCode();
//                final DealerAllocationResult otherOcf = (DealerAllocationResult) other;
//                final String otherKey = otherOcf.getPlanYearMonth()
//                        + otherOcf.getDealerCode()
//                        + otherOcf.getCarSeries()
//                        + otherOcf.getPorCode()
//                        + otherOcf.getEndItemModelCode()
//                        + otherOcf.getProductionFamilyCode();
//                comp = selfKey.compareTo(otherKey);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            return comp;
//        }
//    }

}
