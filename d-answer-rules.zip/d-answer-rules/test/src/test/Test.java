package test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


public class Test {

	public static void main(String[] args) {

		List<BigDecimal> list = new ArrayList<BigDecimal>();
		list.add(new BigDecimal("1999999999999120130110101090000000009"));
		list.add(new BigDecimal("1999999999999199999999999990000000010"));
		list.add(new BigDecimal("1999999999999120130112101090000000011"));
		list.add(new BigDecimal("1999999999915299999999999990000000012"));
		list.add(new BigDecimal("1999999999914299999999999990000000013"));
		list.add(new BigDecimal("1999999999917299999999999990000000008"));
		list.add(new BigDecimal("1999999999999399999999999990000000018"));
		list.add(new BigDecimal("1999999999999399999999999910000000017"));
		list.add(new BigDecimal("1999999999999399999999999900000000016"));
		list.add(new BigDecimal("1999999999999399999999999900000000015"));
		list.add(new BigDecimal("1999999999999299999999999990000000014"));
		
		
		System.out.println(java.util.Collections.min(list));
	}

}
