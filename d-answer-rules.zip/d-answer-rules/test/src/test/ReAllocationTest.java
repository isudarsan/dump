package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.reallocation.EndItemReAlloc;
import com.nissan.danswer.model.reallocation.EndItemReAllocList;
import com.nissan.danswer.model.reallocation.FactoryLine;
import com.nissan.danswer.model.reallocation.FactoryLineList;
import com.nissan.danswer.model.reallocation.OCFDaily;
import com.nissan.danswer.model.reallocation.OCFDailyList;
import com.nissan.danswer.model.reallocation.SpecOCF;
import com.nissan.danswer.model.reallocation.SpecOCFList;

/**
 * EndItemReAlloc.drlのテストクラス
 */
@SuppressWarnings("restriction")
public class ReAllocationTest {

    // 最大fire件数
    private static int MAX_FIRE = 10000;

    // DRLファイル名
    private static String drlName = "ReAllocation.drl";
    // knowledgeBase
    private static KnowledgeBase kbase = null;
    // knowledge session
    private StatefulKnowledgeSession ksession;
    private KnowledgeRuntimeLogger logger = null;

    // flowファイル名
    private static String rfName = "ReAllocation.rf";
    // flowID
    private static String flowID = "com.nissan.danswer.flow.reallocation";

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {

        // knowledgeBuilder
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
                .newKnowledgeBuilder();

        // add resources to KnowledgeBuilder
        kbuilder.add(ResourceFactory.newClassPathResource(drlName),
                ResourceType.DRL);
        kbuilder.add(ResourceFactory.newClassPathResource(rfName),
                ResourceType.DRF);

        // knowledgeBuilderErrors
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error : errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }

        // knowledgeBase
        kbase = KnowledgeBaseFactory.newKnowledgeBase();

        // add knowledgePackages to knowledgeBase
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
    }

    @Before
    public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();

        logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
                "log/enditem-allocation-audit");
    }

    @After
    public void tearDown() {
        if (logger != null) {
            logger.close();
        }
        // dispose a knowledge session
        if (ksession != null) {
            ksession.dispose();
        }
    }

    /**
     * 引当テストNo1
     */
    @Test
    public void testCase1() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase1/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase1/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase1/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase1/order_result.csv");

            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase1/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo2
     */
    @Test
    public void testCase2() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase2/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase2/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase2/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase2/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase2/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo3
     */
    @Test
    public void testCase3() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase3/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase3/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase3/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase3/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase3/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo4
     */
    @Test
    public void testCase4() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase4/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase4/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase4/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(specList);
            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase4/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase4/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo5
     */
    @Test
    public void testCase5() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase5/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase5/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase5/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase5/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase5/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo6
     */
    @Test
    public void testCase6() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase6/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase6/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase6/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase6/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase6/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo7
     */
    @Test
    public void testCase7() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase7/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase7/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase7/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase7/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);
            // for (int idx = 0; idx < eiList.size(); idx++) {
            // // System.out.println("resultAlloc_carseries1.get(idx) : " +
            // resultAlloc_carseries1.get(idx));
            // assertEquals(resultAlloc_carseries1.get(idx).getSortNo(),
            // eiList.get(idx).getSortNo());
            // assertEquals(resultAlloc_carseries1.get(idx).getNewOfflineDate(),
            // eiList.get(idx).getNewOfflineDate());
            // assertEquals(resultAlloc_carseries1.get(idx).getNewOfflineWeek(),
            // eiList.get(idx).getNewOfflineWeek());
            // assertEquals(resultAlloc_carseries1.get(idx).getNewBackOrderFlg(),
            // eiList.get(idx).getNewBackOrderFlg());
            // }

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase7/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);
            // for (int idx = 0; idx < resultOcf.size(); idx++) {
            // final OCFDaily ocf = resultOcf.get(idx);
            // // System.out.println("OCF csv line=[" + ocf.getIndex() + "]");
            // assertEquals(ocf.getPlanYearMonth(),
            // ocfList.get(idx).getPlanYearMonth());
            // assertEquals(ocf.getCarSeries(),
            // ocfList.get(idx).getCarSeries());
            // assertEquals(ocf.getOcfInfo().getFrameSortCode(),
            // ocfList.get(idx).getOcfInfo().getFrameSortCode());
            // assertEquals(ocf.getOcfInfo().getOcfClassificationCode(),
            // ocfList.get(idx).getOcfInfo().getOcfClassificationCode());
            // assertEquals(ocf.getOcfInfo().getLocationIdentificationCode(),
            // ocfList.get(idx).getOcfInfo().getLocationIdentificationCode());
            // assertEquals(ocf.getOcfInfo().getCarGroup(),
            // ocfList.get(idx).getOcfInfo().getCarGroup());
            // assertEquals(ocf.getOcfInfo().getFrameCode(),
            // ocfList.get(idx).getOcfInfo().getFrameCode());
            // assertEquals(ocf.getMaxQty(), ocfList.get(idx).getMaxQty());
            // assertEquals(ocf.getActualQty(),
            // ocfList.get(idx).getActualQty());
            // }

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo8
     */
    @Test
    public void testCase8() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase8/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase8/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase8/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(specList);
            ksession.insert(ocfList);
            ksession.insert(flList);
            ksession.insert(eiList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase8/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase8/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
	 * 引当テストNo9
	 */
	@Test
	public void testCase9() {
	    try {
	        System.out.println("============================== "
	                + new Throwable().getStackTrace()[0].getMethodName());
	        // creates a knowledge session
	        final StatefulKnowledgeSession ksession = kbase
	                .newStatefulKnowledgeSession();
	        // KnowledgeRuntimeLogger logger =
	        // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
	        // "log/TestEndItemAlloc");
	
	        EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase9/order.csv");
	        SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase9/spec_ocf.csv");
	        OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase9/ocf.csv");
	        FactoryLineList flList = makeFactoryLineSortList();
	
	        ksession.insert(flList);
	        ksession.insert(eiList);
	        ksession.insert(specList);
	        ksession.insert(ocfList);
	
	        // startProcess
	        ksession.startProcess(flowID);
	        // fire
	        int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
	        /*** 結果確認 ****/
	        // 0件以上fireされたこと
	        assertTrue(fireCnt > 0);
	
	        // EndItemReAlloc予測結果
	        EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase9/order_result.csv");
	        checkAllEndItem(eiList, resultAlloc_carseries1);
	
	        // OCFDaily予測結果
	        OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase9/ocf_result.csv");
	        checkAllOCF(ocfList, resultOcf);
	
	        // logger.close();
	        ksession.dispose();
	    } catch (Exception e) {
	        e.printStackTrace();
	        fail("An exception has occured.");
	    }
	}

	/**
     * 引当テストNo10
     */
    @Test
    public void testCase10() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase10/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase10/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase10/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase10/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase10/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo11
     */
    @Test
    public void testCase11() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase11/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase11/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase11/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase11/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase11/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo12
     */
    @Test
    public void testCase12() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase12/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase12/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase12/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase12/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase12/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo13
     */
    @Test
    public void testCase13() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC("../d-answer-testdata/data/endItemRealloc/TestCase13/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF("../d-answer-testdata/data/endItemRealloc/TestCase13/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY("../d-answer-testdata/data/endItemRealloc/TestCase13/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase13/order_result.csv");
            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase13/ocf_result.csv");
            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * 引当テストNo98 (工場/ライン情報の展開テスト)
     */
    @Test
    public void testCase98() {
        System.out.println("============================== "
                + new Throwable().getStackTrace()[0].getMethodName());
        // creates a knowledge session
        final StatefulKnowledgeSession ksession = kbase
                .newStatefulKnowledgeSession();

        FactoryLineList flList = makeFactoryLineSortList();
        assertTrue(flList.size() == 6);
        ksession.insert(flList);

        // startProcess
        ksession.startProcess(flowID);
        // fire
        int fireCnt = ksession.fireAllRules(MAX_FIRE);

        /*** 結果確認 ****/
        // 0件以上fireされたこと
        assertTrue(fireCnt > 0);

        ksession.dispose();
    }

    // 2013.10.27 メールの件確認
    // @Test
    public void testKakunin01() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            final String testDataPath = "../d-answer-testdata/data/endItemRealloc/kakunin-01";
            
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC(testDataPath + "/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF(testDataPath + "/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY(testDataPath + "/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList1();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules();
//            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
//            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase9/order_result.csv");
//            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
//            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT(testDataPath + "/ocf_result.csv");
//            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
            
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            for (OCFDaily d : ocfList) {
//                if (d.getMaxQty() == d.getActualQty())
//                    System.out.println("OCF=" + d);
                    System.out.println("" + d.getActualQty());
            }
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }
    
    
    // 2013.10.29 メールの件確認
    // @Test
    public void testKakunin02() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            final String testDataPath = "../d-answer-testdata/data/endItemRealloc/kakunin-02";
            
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC(testDataPath + "/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF(testDataPath + "/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY(testDataPath + "/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList1();

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules();
//            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
//            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase9/order_result.csv");
//            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
//            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT(testDataPath + "/ocf_result.csv");
//            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
            
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            for (OCFDaily d : ocfList) {
//                if (d.getMaxQty() == d.getActualQty())
//                    System.out.println("OCF=" + d);
                    System.out.println("" + d.getActualQty());
            }
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // 2013.10.31 メールの件確認
    // @Test
    public void testKakunin03() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            final String testDataPath = "../d-answer-testdata/data/endItemRealloc/kakunin-03";
            
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC(testDataPath + "/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF(testDataPath + "/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY(testDataPath + "/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList1();

//            ksession.insert("JAPAN");

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules();
//            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
//            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase9/order_result.csv");
//            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
//            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT(testDataPath + "/ocf_result.csv");
//            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
            
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            for (OCFDaily d : ocfList) {
//                if (d.getMaxQty() == d.getActualQty())
//                    System.out.println("OCF=" + d);
                    System.out.println("" + d.getActualQty());
            }
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // 2013.11.1 メールの件確認
    // @Test
    public void testKakunin04() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());
            final String testDataPath = "../d-answer-testdata/data/endItemRealloc/kakunin-04";
            
            // creates a knowledge session
            final StatefulKnowledgeSession ksession = kbase
                    .newStatefulKnowledgeSession();
            // KnowledgeRuntimeLogger logger =
            // KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
            // "log/TestEndItemAlloc");

            EndItemReAllocList eiList = readCSV_EI_ALLOC(testDataPath + "/order.csv");
            SpecOCFList specList = readCSV_SPEC_OCF(testDataPath + "/spec_ocf.csv");
            OCFDailyList ocfList = readCSV_OCF_DAILY(testDataPath + "/ocf.csv");
            FactoryLineList flList = makeFactoryLineSortList1();

//            ksession.insert("JAPAN");

            ksession.insert(flList);
            ksession.insert(eiList);
            ksession.insert(specList);
            ksession.insert(ocfList);

            // startProcess
            ksession.startProcess(flowID);
            // fire
            int fireCnt = ksession.fireAllRules();
//            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // EndItemReAlloc予測結果
//            EndItemReAllocList resultAlloc_carseries1 = readCSV_EI_ALLOC_RESULT("../d-answer-testdata/data/endItemRealloc/TestCase9/order_result.csv");
//            checkAllEndItem(eiList, resultAlloc_carseries1);

            // OCFDaily予測結果
//            OCFDailyList resultOcf = readCSV_OCF_DAILY_RESULT(testDataPath + "/ocf_result.csv");
//            checkAllOCF(ocfList, resultOcf);

            // logger.close();
            ksession.dispose();
            
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            for (OCFDaily d : ocfList) {
//                if (d.getMaxQty() == d.getActualQty())
//                    System.out.println("OCF=" + d);
                    System.out.println("" + d.getActualQty());
            }
            System.out.println("-----8=-----8<-----8=-----8<-----8=-----8<-----8=-----8<-----");
            
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }
    
    // =============================== set test data
    // ======================================== //
    private static OCFIdentificationInfo setOcfInfo(String sort,
            String ocfClass, String loc, String group, String frame) {

        OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
        ocfInfo.setFrameSortCode(sort);
        ocfInfo.setOcfClassificationCode(ocfClass);
        ocfInfo.setLocationIdentificationCode(loc);
        ocfInfo.setCarGroup(group);
        ocfInfo.setFrameCode(frame);

        return ocfInfo;
    }

    private static OCFDaily setOCFDaily_result(String ym,
            String car,
            String sort, // OCF INFO
            String ocfClass, // OCF INFO
            String loc, // OCF INFO
            String group, // OCF INFO
            String factory, String line, String frame, String week, String day,
            int max, int index, int actQty) {
        OCFDaily ocfDaily = new OCFDaily();
        ocfDaily.setPlanYearMonth(ym);
        ocfDaily.setCarSeries(car);
        ocfDaily.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
        ocfDaily.setFactoryCode(factory);
        ocfDaily.setLineClass(line);
        ocfDaily.setWeekNo(week);
        ocfDaily.setDate(day);
        ocfDaily.setMaxQty(max);

        ocfDaily.setActualQty(actQty);

        return ocfDaily;
    }

    private static EndItemReAlloc setEndItemReAlloc_result(String sortNo,
            String planYM, String carSeries, String distNo, String emCode,
            String emCol, String factory, String line, String order,
            String allocPri, String allocScope, String input, String weekDue,
            String fix, String reply, String random, String bolsa,
            String offDate, String offWeek, String newOffDate, // OUT
            String newOffWeek, // OUT
            String newFactory, // OUT
            String newLine, // OUT
            String newBackOrderFlg, // OUT
            int csvline) {
        EndItemReAlloc endItemReAlloc = new EndItemReAlloc();
//        endItemReAlloc.setSortNo(sortNo);
        endItemReAlloc.setSortNo(new BigDecimal(sortNo));
        endItemReAlloc.setPlanYearMonth(planYM);
        endItemReAlloc.setCarSeries(carSeries);
        endItemReAlloc.setDistributionNo(distNo);
        endItemReAlloc.setEndItemModelCode(emCode);
        endItemReAlloc.setEndItemColorCode(emCol);
        endItemReAlloc.setFactoryCode(factory);
        endItemReAlloc.setLineClass(line);
        endItemReAlloc.setOrderType(order);
        endItemReAlloc.setReallocationPriorityNo(allocPri);
        endItemReAlloc.setReallocationScopeFlg(allocScope);
        endItemReAlloc.setInputDateOfOrder(input);
        endItemReAlloc.setWeekOfDueDateForDelivery(weekDue);
        endItemReAlloc.setFixFlg(fix);
        endItemReAlloc.setDealerReplyFlg(reply);
        endItemReAlloc.setRandomNo(random);
        endItemReAlloc.setOfflineDate(offDate);
        endItemReAlloc.setOfflineWeekNo(offWeek);
        endItemReAlloc.setBolsaOrNot(bolsa);
        endItemReAlloc.setNewOfflineDate(nullCheck(newOffDate));
        endItemReAlloc.setNewOfflineWeek(nullCheck(newOffWeek));
        endItemReAlloc.setNewFactoryCode(nullCheck(newFactory));
        endItemReAlloc.setNewLineClass(nullCheck(newLine));
        endItemReAlloc.setNewBackOrderFlg(newBackOrderFlg);
        // endItemReAlloc.setLineNo(csvline);
        // System.out.println("csv read " + endItemReAlloc);
        return endItemReAlloc;
    }
    
    // 
    private static String nullCheck(String str) {
        return "(null)".equals(str) ? null : str;
    }

    // OCF DAILY
    public static OCFDailyList readCSV_OCF_DAILY(String filename)
            throws Exception {
        OCFDailyList list = new OCFDailyList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            i++;
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String[] data = line.split(",", -1);
//            System.out.println("i=" + i);
            list.add(setOCFDaily(
                        data[0],
                        data[1],
                        data[2], 
                        data[3], 
                        data[4],
                        data[5], 
                        data[6], 
                        data[7], 
                        data[8], 
                        data[9], 
                        data[10],
                        Integer.valueOf(data[11]).intValue(),
                        i)
            );
        }
        filereader.close();
        shuffle(list);
        return list;
    }

    public static OCFDailyList readCSV_OCF_DAILY_RESULT(String filename)
            throws Exception {
        OCFDailyList list = new OCFDailyList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            i++;
            // System.out.println("Start line at " + i);
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String[] data = line.split(",", -1);
            list.add(setOCFDaily_result(data[0], data[1], data[2], data[3],
                    data[4], data[5], data[6], data[7], data[8], data[9],
                    data[10], Integer.valueOf(data[11]).intValue(), i, Integer
                            .valueOf(data[12]).intValue()));
        }
        filereader.close();
        return list;
    }

    /**
     * CSV読み込み（SpecOCF）
     * 
     * @param fileName
     * @throws Exception
     */
    public static SpecOCFList readCSV_SPEC_OCF(String filename)
            throws Exception {
        SpecOCFList list = new SpecOCFList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        int j = 0;
        while ((line = bufferedreader.readLine()) != null) {
            j++;
//            System.out.println("csv " + j + "行目 : " + line);
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String[] data = line.split(",", -1);
            if (i > 0
                    && list.get(i - 1).getPlanYearMonth().equals(data[0])
                    && list.get(i - 1).getCarSeries().equals(data[1])
                    && list.get(i - 1).getPorCode().equals(data[2])
                    && list.get(i - 1).getProductionFamilyCode().equals(data[3])
                    && list.get(i - 1).getEndItemModelCode().equals(data[4])
                    && list.get(i - 1).getEndItemColorCode().equals(data[5])
                    && list.get(i - 1).getWeekNo().equals(data[6])) {
                // EIキーが同じ場合は、OCF情報のみを追加
                list.get(i - 1)
                        .getOcfList()
                        .add(setOcfInfo(data[7], data[8], data[9], data[10],
                                data[11]));
            } else {
                // 新規行追加
                list.add(setSpecOCF_CSV(data[0], data[1],
                        data[2], data[3],
                        data[4], data[5], data[6], data[7], data[8], data[9],
                        data[10], data[11], j));
                i++;
            }
        }
        filereader.close();
        
        System.out.println("spec ocf = [" + list.size() + "]");
        shuffle(list);
        return list;

    }

    // EndItemReAlloc
    public static EndItemReAllocList readCSV_EI_ALLOC(String filename)
            throws Exception {
        EndItemReAllocList list = new EndItemReAllocList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            i++;
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String[] data = line.split(",", -1);
//            System.out.println("i=" + i);
            list.add(setEndItemReAlloc(data[0], // PLAN_YEAR_MONTH
                    data[1], // CAR_SERIES
                    data[2], // DISTRIBUTION_NO
                    data[3], // END_ITEM_MODEL_CODE
                    data[4], // END_ITEM_COLOR_CODE
                    data[5], // FACTORY_CODE
                    data[6], // LINE_CLASS
                    data[7], // ORDER_TYPE
                    data[8], // RE_ALLOCATION_PRIORITY_NO
                    data[9], // RE_ALLOCATION_SCOPE_FLG
                    data[10], // INPUT_DATE_OF_ORDER
                    data[11], // WEEK_OF_DUE_DATE_FOR_DELIVERY
                    data[12], // FIX_FLG
                    data[13], // DEALER_REPLY_FLG
                    data[14], // RANDOM_NO
                    data[15], // BOLSA_OR_NOT
                    data[16], // OFFLINE_DATE
                    data[17], // OFFLINE_WEEK_NO
                    i // CSVの行数
            ));
        }
        filereader.close();

//        shuffle(list);
        return list;
    }

    // EndItemReAlloc
    public static EndItemReAllocList readCSV_EI_ALLOC_RESULT(String filename)
            throws Exception {
        EndItemReAllocList list = new EndItemReAllocList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            i++;
            // System.out.println("Start line at " + i);
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String[] data = line.split(",", -1);
            list.add(setEndItemReAlloc_result(data[0], // SORT_NO
                    data[1], // PLAN_YEAR_MONTH
                    data[2], // CAR_SERIES
                    data[3], // DISTRIBUTION_NO
                    data[4], // END_ITEM_MODEL_CODE
                    data[5], // END_ITEM_COLOR_CODE
                    data[6], // FACTORY_CODE
                    data[7], // LINE_CLASS
                    data[8], // ORDER_TYPE
                    data[9], // RE_ALLOCATION_PRIORITY_NO
                    data[10], // RE_ALLOCATION_SCOPE_FLG
                    data[11], // INPUT_DATE_OF_ORDER
                    data[12], // WEEK_OF_DUE_DATE_FOR_DELIVERY
                    data[13], // FIX_FLG
                    data[14], // DEALER_REPLY_FLG
                    data[15], // RANDOM_NO
                    data[16], // BOLSA_OR_NOT
                    data[17], // OFFLINE_DATE
                    data[18], // OFFLINE_WEEK_NO
                    data[19], // NEW_OFFLINE_DATE
                    data[20], // NEW_OFFLINE_WEEK
                    data[21], // NEW_FACTORY_CODE
                    data[22], // NEW_LINE_CLASS
                    data[23], // NEW_BACK_ORDER_FLG
                    i)); // csv line
        }
        filereader.close();
        return list;
    }

    private static EndItemReAlloc setEndItemReAlloc(String ym,
            String carSeries, String distNo, String model, String color,
            String factory, String lineClass, String order, String reallocPri,
            String reallocScope, String input, String week, String fix,
            String reply, String random, String bolsa, String offDate,
            String offWeek, int i) {
        EndItemReAlloc endItemReAlloc = new EndItemReAlloc();
        endItemReAlloc.setPlanYearMonth(ym);
        endItemReAlloc.setCarSeries(carSeries);
        endItemReAlloc.setDistributionNo(distNo);
        endItemReAlloc.setEndItemModelCode(model);
        endItemReAlloc.setEndItemColorCode(color);
        endItemReAlloc.setFactoryCode(factory);
        endItemReAlloc.setLineClass(lineClass);
        endItemReAlloc.setOrderType(order);
        endItemReAlloc.setReallocationPriorityNo(reallocPri);
        endItemReAlloc.setReallocationScopeFlg(reallocScope);
        endItemReAlloc.setInputDateOfOrder(input.equals("null") ? null : input);
        endItemReAlloc.setWeekOfDueDateForDelivery(week);
        endItemReAlloc.setFixFlg(fix);
        endItemReAlloc.setDealerReplyFlg(reply);
        endItemReAlloc.setRandomNo(random);
        endItemReAlloc.setBolsaOrNot(bolsa);
        endItemReAlloc.setOfflineDate("null".equals(offDate) ? null : offDate);
        endItemReAlloc.setOfflineWeekNo(offWeek);

        try {
        	// endItemReAlloc.setLineNo(i); ← この行の替わり
        	// setLineNo()メソッド(デバッグ用)があれば、CSVの行数をセットする
            Class<?> enditemCls = EndItemReAlloc.class;
			Method setter = enditemCls.getMethod("setLineNo", int.class);
			setter.invoke(endItemReAlloc, i);
		} catch (NoSuchMethodException e) {
			// setLineno()メソッドがなければ、なにもしない
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
        
        return endItemReAlloc;
    }

    // csv
    private static SpecOCF setSpecOCF_CSV(
            String ym,
            String car,
            String por,
            String family,
            String model,
            String color,
            String weekNo,
            String sort,
            String ocfClass,
            String loc,
            String group,
            String frame,
            int index) {

        SpecOCF spec = new SpecOCF();
        spec.setPlanYearMonth(ym);
        spec.setCarSeries(car);
        spec.setPorCode(por);
        spec.setProductionFamilyCode(family);
        spec.setEndItemModelCode(model);
        spec.setEndItemColorCode(color);
        spec.setWeekNo(weekNo);
        
        try {
        	// spec.setLineno(index); ← この行の替わり
        	// setLineno()メソッド(デバッグ用)があれば、CSVの行数をセットする
            Class<?> specCls = SpecOCF.class;
			Method setter = specCls.getMethod("setLineno", int.class);
			setter.invoke(spec, index);
		} catch (NoSuchMethodException e) {
			// setLineno()メソッドがなければ、なにもしない
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
        
        List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
        ocfList.add(setOcfInfo(sort, ocfClass, loc, group, frame));
        spec.setOcfList(ocfList);

        return spec;
    }

    private static OCFDaily setOCFDaily(
            String ym, 
            String car,

            String sort,     // OCF INFO
            String ocfClass, // OCF INFO
            String loc,      // OCF INFO
            String group,    // OCF INFO

            String factory, 
            String line, 
            String frame, 
            String week, 
            String day,
            int max, 
            int index) {
        OCFDaily ocfDaily = new OCFDaily();
        ocfDaily.setPlanYearMonth(ym);
        ocfDaily.setCarSeries(car);
        ocfDaily.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
        ocfDaily.setFactoryCode(factory);
        ocfDaily.setLineClass(line);
        ocfDaily.setFrameCode(frame);
        ocfDaily.setWeekNo(week);
        ocfDaily.setDate("null".equals(day) ? null : day);
        ocfDaily.setMaxQty(max);

        
        try {
        	// ocfDaily.setLineno(index); ← この行の替わり
        	// setLineno()メソッド(デバッグ用)があれば、CSVの行数をセットする
            Class<?> ocfCls = OCFDaily.class;
			Method setter = ocfCls.getMethod("setLineno", int.class);
			setter.invoke(ocfDaily, index);
		} catch (NoSuchMethodException e) {
			// setLineno()メソッドがなければ、なにもしない
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
        
        return ocfDaily;
    }

    // 生産未確定車引当て用工場/ラインテーブル
    public static FactoryLineList makeFactoryLineSortList() {
        FactoryLineList l = new FactoryLineList();
        l.add(new FactoryLine("A", "A")); // A工場、Aライン
        l.add(new FactoryLine("A", "B")); // A工場、Bライン
        l.add(new FactoryLine("A", "C")); // A工場、Cライン
        // l.add(new FactoryLine("A", "D")); // A工場、Cライン
        l.add(new FactoryLine("B", "D")); // B工場、Dライン
        l.add(new FactoryLine("B", "E")); // B工場、Eライン
        l.add(new FactoryLine("B", "F")); // B工場、Fライン
        
        shuffle(l);
        return l;
    }

    // 生産未確定車引当て用工場/ラインテーブル
    public static FactoryLineList makeFactoryLineSortList1() {
        FactoryLineList l = new FactoryLineList();
        l.add(new FactoryLine("B ", "1111")); // B 工場、1111ライン
        l.add(new FactoryLine("B ", "2222")); // B 工場、2222ライン
        l.add(new FactoryLine("C ", "1111")); // C 工場、1111ライン
        l.add(new FactoryLine("C ", "2222")); // C 工場、2222ライン
        
        shuffle(l);
        return l;
    }

    
    // Orderの比較(ソートNoで比較)
    private class EndItemComparator implements Comparator<Object> {
        public int compare(Object self, Object other) {
            try {
                int comp = ((EndItemReAlloc) self).getSortNo().compareTo(
                        ((EndItemReAlloc) other).getSortNo());
                if (comp == 0) {
                    // sortNoが同値の場合は、第比較キーとしてdealerReplyFlg
                    return ((EndItemReAlloc) self).getDealerReplyFlg().compareTo(((EndItemReAlloc) other).getDealerReplyFlg());
                } else {
                    return ((EndItemReAlloc) self).getSortNo().compareTo(
                            ((EndItemReAlloc) other).getSortNo());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }
    }

    // OCFの比較
    private class OCFComparator implements Comparator<Object> {
        public int compare(Object self, Object other) {
            int comp = 0;
            try {
                final OCFDaily selfOcf = (OCFDaily) self;
                final String selfKey = selfOcf.getPlanYearMonth()
                        + selfOcf.getCarSeries()
                        + selfOcf.getOcfInfo().getOcfClassificationCode()
                        + selfOcf.getFactoryCode()
                        + selfOcf.getLineClass()
                        + selfOcf.getWeekNo()
                        + selfOcf.getWeekNoDate();
                final OCFDaily otherOcf = (OCFDaily) other;
                final String otherKey = otherOcf.getPlanYearMonth()
                        + otherOcf.getCarSeries()
                        + otherOcf.getOcfInfo().getOcfClassificationCode()
                        + otherOcf.getFactoryCode()
                        + otherOcf.getLineClass()
                        + otherOcf.getWeekNo()
                        + otherOcf.getWeekNoDate();
                comp = selfKey.compareTo(otherKey);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return comp;
        }
    }

    private void checkAllEndItem(EndItemReAllocList results,
            EndItemReAllocList expected) {
        System.out.println("--- result " + results.size());
        System.out.println("--- expect " + expected.size());
        assertTrue(results.size() == expected.size()); // 結果と期待値のOrder数が異なる場合

        Collections.sort(results,  new EndItemComparator());
        Collections.sort(expected, new EndItemComparator());

        for (int i = 0; i < results.size(); i++) {
            EndItemReAlloc ei = results.get(i);
            System.out.println("---" + i + "--------------------------------------------------------");
            System.out.println("expected = " + expected.get(i));
            System.out.println("result   = " + ei);
            assertEquals(expected.get(i).getPlanYearMonth(),
                    ei.getPlanYearMonth());
            assertEquals(expected.get(i).getCarSeries(), ei.getCarSeries());
            assertEquals(expected.get(i).getDistributionNo(),
                    ei.getDistributionNo());
            assertEquals(expected.get(i).getEndItemModelCode(),
                    ei.getEndItemModelCode());
            assertEquals(expected.get(i).getEndItemColorCode(),
                    ei.getEndItemColorCode());
            assertEquals(expected.get(i).getFactoryCode(), ei.getFactoryCode());
            assertEquals(expected.get(i).getLineClass(), ei.getLineClass());
            assertEquals(expected.get(i).getOrderType(), ei.getOrderType());
            assertEquals(expected.get(i).getReallocationPriorityNo(),
                    ei.getReallocationPriorityNo());
            assertEquals(expected.get(i).getReallocationScopeFlg(),
                    ei.getReallocationScopeFlg());
            assertEquals(expected.get(i).getInputDateOfOrder(),
                    ei.getInputDateOfOrder());
            assertEquals(expected.get(i).getWeekOfDueDateForDelivery(),
                    ei.getWeekOfDueDateForDelivery());
            assertEquals(expected.get(i).getFixFlg(), ei.getFixFlg());
            assertEquals(expected.get(i).getDealerReplyFlg(),
                    ei.getDealerReplyFlg());
            assertEquals(expected.get(i).getRandomNo(), ei.getRandomNo());
            assertEquals(expected.get(i).getBolsaOrNot(), ei.getBolsaOrNot());
            assertEquals(expected.get(i).getOfflineDate(), ei.getOfflineDate());
            assertEquals(expected.get(i).getOfflineWeekNo(),
                    ei.getOfflineWeekNo());
            assertEquals(expected.get(i).getSortNo(), ei.getSortNo());

            // out fields
            // assertEquals(ei.getNewOfflineDate(),
            // expected.get(i).getNewOfflineDate());
            assertEquals(expected.get(i).getNewOfflineDate(),
                    ei.getNewOfflineDate());
            assertEquals(expected.get(i).getNewOfflineWeek(),
                    ei.getNewOfflineWeek());
            assertEquals(expected.get(i).getNewFactoryCode(),
                    ei.getNewFactoryCode());
            assertEquals(expected.get(i).getNewLineClass(),
                    ei.getNewLineClass());
            assertEquals(expected.get(i).getNewBackOrderFlg(),
                    ei.getNewBackOrderFlg());
        }
    }

    private void checkAllOCF(OCFDailyList results, OCFDailyList expected) {
        
        assertTrue(expected.size() == results.size());

        Collections.sort(results,  new OCFComparator());
        Collections.sort(expected,  new OCFComparator());
       
        for (int idx = 0; idx < expected.size(); idx++) {
            final OCFDaily ocf = expected.get(idx);
            System.out.println("ocf = " + results.get(idx));
            assertEquals(ocf.getPlanYearMonth(), results.get(idx)
                    .getPlanYearMonth());
            assertEquals(ocf.getCarSeries(), results.get(idx).getCarSeries());
            assertEquals(ocf.getOcfInfo().getFrameSortCode(), results.get(idx)
                    .getOcfInfo().getFrameSortCode());
            assertEquals(ocf.getOcfInfo().getOcfClassificationCode(), results
                    .get(idx).getOcfInfo().getOcfClassificationCode());
            assertEquals(ocf.getOcfInfo().getLocationIdentificationCode(),
                    results.get(idx).getOcfInfo()
                            .getLocationIdentificationCode());
            assertEquals(ocf.getOcfInfo().getCarGroup(), results.get(idx)
                    .getOcfInfo().getCarGroup());
            assertEquals(ocf.getOcfInfo().getFrameCode(), results.get(idx)
                    .getOcfInfo().getFrameCode());
            assertEquals(ocf.getMaxQty(), results.get(idx).getMaxQty());
            assertEquals(ocf.getActualQty(), results.get(idx).getActualQty());
        }
    }

    public static void shuffle(List list) {}
//    public static void shuffle(List list) {
//        final int size = list.size();
//        for (int i = 0; i < size; i++) {
//            java.util.Random rand = new java.util.Random();
//            int destIndex = rand.nextInt(size);
//            list.set(i, list.set(destIndex, list.get(i)));
//        }
//    }
}
