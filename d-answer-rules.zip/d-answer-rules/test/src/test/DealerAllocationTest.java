package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.dealerallocation.Dealer;
import com.nissan.danswer.model.dealerallocation.DealerAllocationResult;
import com.nissan.danswer.model.dealerallocation.DealerAllocationResultList;
import com.nissan.danswer.model.dealerallocation.DealerList;
import com.nissan.danswer.model.dealerallocation.EndItem;
import com.nissan.danswer.model.dealerallocation.EndItemList;
import com.nissan.danswer.model.reallocation.OCFDaily;

/**
 * 反射配分ルールテスト
 * @author seino
 */
@SuppressWarnings("restriction")
public class DealerAllocationTest {

	// 最大fire件数
	private static int MAX_FIRE = 2000;
	
	// DRLファイル名
	private static String drlName = "DealerAllocation.drl";	
	// テストデータ格納場所
	private static String filepath = "../d-answer-testdata/data/dealerallocation";
	
	// flowファイル名
	private static String rfName = "DealerAllocation.rf";
	// flowID
	private static String flowID = "com.nissan.danswer.flow.dealerallocation";
	
	// knowledgeBase
	private static KnowledgeBase kbase = null;
	
	// knowledge session
	private StatefulKnowledgeSession ksession;
	
	// logger
	private KnowledgeRuntimeLogger logger = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource(drlName),ResourceType.DRL);
    	kbuilder.add(ResourceFactory.newClassPathResource(rfName),ResourceType.DRF);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	}
	
	@Before
	public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();
        
        logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/dealerallocation-audit");	
	}
	
	@After
	public void tearDown() {
		if (logger != null) {
			logger.close();
		}
		// dispose a knowledge session
		if (ksession != null) {
			ksession.dispose();			
		}
	}
	
	/**
	 * testCase1
	 */
	@Test
	public void testCase1() {
        try {
    	    System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
    		// input Fact list
    		EndItemList eiList = makeEndItemList(filepath + "/test01/enditem.csv");
    		DealerList dealerList = makeDealerList(filepath + "/test01/dealer.csv");
    		DealerAllocationResultList resultList = new DealerAllocationResultList();
    		
            ksession.insert(resultList);        // OUT
            ksession.insert(dealerList);        // IN
            ksession.insert(eiList);            // IN
    		
    		// startProcess
    		ksession.startProcess(flowID);
    		
    		Date startDate = new Date();
    		
    		// fire
    		int fireCnt = ksession.fireAllRules(MAX_FIRE);		
    		
    		Date endDate = new Date();
    	        System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run");
    		
    		BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
    		
    		System.out.println("start : " + startDate);
    		System.out.println("end   : " + endDate);
    		System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
    		System.out.println("fireCnt : " + fireCnt);
    		
    		if (fireCnt == MAX_FIRE) {
    			System.out.println("WARNING! rule loops");
    		}
    
    		// 0件以上fireされたこと
    		assertTrue(fireCnt > 0);
    		
    		// MatchingResult予測結果
    		DealerAllocationResultList expectedResult = makeResultList(filepath + "/test01/result.csv");
    
    		// show result
            final String header = 
                    "#PLAN_YEAR_MONTH\t" +
                    "DEALER_CODE\t" +
                    "CAR_SERIES\t" +
                    "POR_CODE\t" +
                    "END_ITEM_MODEL_CODE\t" +
                    "PRODUCTION_FAMILY_CODE\t" +
                    "RECOMMENDED_BY_SYSTEM_QTY";
            final String outFormat = "%s\t%s\t%s\t%s\t%s\t%s\t%s";
    //      final String outFormat = "%s,%s,%s,%s,%s,%s,%s";
            System.out.println("=================== EXPECTED ==============");
            System.out.println(header);
            for (DealerAllocationResult o : expectedResult) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
            
            System.out.println("\n=================== ACTUAL ==============");
            System.out.println(header);
            for (DealerAllocationResult o : resultList) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
    		
            // 予測と実際を比較
            checkDealerAllocationResult(expectedResult, resultList);
    
    		System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run end");
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
	}

   /**
     * specification change
     */
//    @Test
    public void testCaseModifyBefore() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
            // input Fact list
            EndItemList eiList = makeEndItemList(filepath + "/test-modify-before/enditem.csv");
            DealerList dealerList = makeDealerList(filepath + "/test-modify-before/dealer.csv");
            DealerAllocationResultList resultList = new DealerAllocationResultList();
            
            ksession.insert(resultList);        // OUT
            ksession.insert(dealerList);        // IN
            ksession.insert(eiList);            // IN
            
            // startProcess
            ksession.startProcess(flowID);
            
            Date startDate = new Date();
            
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);      
            
            Date endDate = new Date();
                System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run");
            
            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
            
            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);
            
            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }
    
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
            
            // MatchingResult予測結果
            DealerAllocationResultList expectedResult = makeResultList(filepath + "/test-modify-before/result.csv");
    
            // show result
            final String header = 
                    "#PLAN_YEAR_MONTH\t" +
                    "DEALER_CODE\t" +
                    "CAR_SERIES\t" +
                    "POR_CODE\t" +
                    "END_ITEM_MODEL_CODE\t" +
                    "PRODUCTION_FAMILY_CODE\t" +
                    "RECOMMENDED_BY_SYSTEM_QTY";
            final String outFormat = "%s\t%s\t%s\t%s\t%s\t%s\t%s";
    //      final String outFormat = "%s,%s,%s,%s,%s,%s,%s";
            System.out.println("=================== EXPECTED ==============");
            System.out.println(header);
            for (DealerAllocationResult o : expectedResult) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
            
            System.out.println("\n=================== ACTUAL ==============");
            System.out.println(header);
            for (DealerAllocationResult o : resultList) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
            
            // 予測と実際を比較
            checkDealerAllocationResult(expectedResult, resultList);
    
            System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run end");
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /**
     * specification change
     */
    @Test
    public void testCaseModifyAfter() {
        try {
            System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
            // input Fact list
            final String path1 = "test-modify-after";
            EndItemList eiList = makeEndItemList(filepath + "/" + path1 + "/enditem.csv");
            DealerList dealerList = makeDealerList(filepath + "/" + path1 + "/dealer.csv");
            DealerAllocationResultList resultList = new DealerAllocationResultList();
            
            ksession.insert(resultList);        // OUT
            ksession.insert(dealerList);        // IN
            ksession.insert(eiList);            // IN
            
            // startProcess
            ksession.startProcess(flowID);
            
            Date startDate = new Date();
            
            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);      
            
            Date endDate = new Date();
                System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run");
            
            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
            
            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);
            
            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }
    
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);
            
            // MatchingResult予測結果
            DealerAllocationResultList expectedResult
                    = makeResultList(filepath + "/" + path1 + "/result.csv");
    
            // show result
            final String header = 
                    "#PLAN_YEAR_MONTH\t" +
                    "DEALER_CODE\t" +
                    "CAR_SERIES\t" +
                    "POR_CODE\t" +
                    "END_ITEM_MODEL_CODE\t" +
                    "PRODUCTION_FAMILY_CODE\t" +
                    "RECOMMENDED_BY_SYSTEM_QTY";
            final String outFormat = "%s\t%s\t%s\t%s\t%s\t%s\t%s";
            System.out.println("=================== EXPECTED ==============");
            System.out.println(header);
            for (DealerAllocationResult o : expectedResult) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
            
            System.out.println("\n=================== ACTUAL ==============");
            System.out.println(header);
            for (DealerAllocationResult o : resultList) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
            
            // 予測と実際を比較
            checkDealerAllocationResult(expectedResult, resultList);
    
            System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run end");
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }
//   @Test
    public void testCase98() {
       try {
	        System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
	        // input Fact list
	        EndItemList eiList = makeEndItemList(filepath + "/matsuTest/enditem.csv");
	        DealerList dealerList = makeDealerList(filepath + "/matsuTest/dealer.csv");
	        DealerAllocationResultList resultList = new DealerAllocationResultList();
	        
	        ksession.insert(resultList);        // OUT
	        ksession.insert(dealerList);        // IN
	        ksession.insert(eiList);            // IN
	        
	        // startProcess
	        ksession.startProcess(flowID);
	        
	        Date startDate = new Date();
	        
	        // fire
	        int fireCnt = ksession.fireAllRules(MAX_FIRE);      
	        
	        Date endDate = new Date();
	        System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run");
	        
	        BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
	        
	        System.out.println("start : " + startDate);
	        System.out.println("end   : " + endDate);
	        System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
	        System.out.println("fireCnt : " + fireCnt);
	        
	        if (fireCnt == MAX_FIRE) {
	            System.out.println("WARNING! rule loops");
	        }

	        // 0件以上fireされたこと
	        assertTrue(fireCnt > 0);
	        
	        // MatchingResult予測結果
	        DealerAllocationResultList expectedResult = makeResultList(filepath + "/matsuTest/result.csv");
	        // 予測と実際を比較
	        checkDealerAllocationResult(expectedResult, resultList);
	        
	        // show result
	        final String header = 
                    "#PLAN_YEAR_MONTH\t" +
                    "DEALER_CODE\t" +
                    "CAR_SERIES\t" +
                    "POR_CODE\t" +
                    "END_ITEM_MODEL_CODE\t" +
                    "PRODUCTION_FAMILY_CODE\t" +
                    "RECOMMENDED_BY_SYSTEM_QTY";
	        final String outFormat = "%s\t%s\t%s\t%s\t%s\t%s\t%s";
//	        final String outFormat = "%s,%s,%s,%s,%s,%s,%s";
            System.out.println("=================== EXPECTED ==============");
            System.out.println(header);
            for (DealerAllocationResult o : expectedResult) {
                System.out.println(
                        String.format(outFormat,
                                o.getPlanYearMonth(),
                                o.getDealerCode(),
                                o.getCarSeries(),
                                o.getPorCode(),
                                o.getEndItemModelCode(),
                                o.getProductionFamilyCode(),
                                o.getRecommendedBySystemQty()));
            }
	        
	        System.out.println("\n=================== ACTUAL ==============");
            System.out.println(header);
	        for (DealerAllocationResult o : resultList) {
	            System.out.println(
	                    String.format(outFormat,
	                            o.getPlanYearMonth(),
	                            o.getDealerCode(),
	                            o.getCarSeries(),
	                            o.getPorCode(),
	                            o.getEndItemModelCode(),
	                            o.getProductionFamilyCode(),
	                            o.getRecommendedBySystemQty()));
	        }

	        System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run end");
	    } catch (Exception e) {
	        e.printStackTrace();
            fail("An exception has occured.");
	    }

   }
   // 大量データテスト (結果はノーチェック)
//       @Test
   public void testCase99() throws Exception {
       try {
           System.out.println("============================== " + new Throwable().getStackTrace()[0].getMethodName());
           // input Fact list
           EndItemList eiList = makeEndItemList(filepath + "/test99/enditem.csv");
           DealerList dealerList = makeDealerList(filepath + "/test99/dealer.csv");
           DealerAllocationResultList resultList = new DealerAllocationResultList();
           
           ksession.insert(resultList);        // OUT
           ksession.insert(dealerList);        // IN
           ksession.insert(eiList);            // IN
           
           // startProcess
           ksession.startProcess(flowID);
           
           Date startDate = new Date();
           
           // fire
           int fireCnt = ksession.fireAllRules(MAX_FIRE);      
           
           Date endDate = new Date();
           System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run");
           
           BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
           
           System.out.println("start : " + startDate);
           System.out.println("end   : " + endDate);
           System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
           System.out.println("fireCnt : " + fireCnt);
           
           if (fireCnt == MAX_FIRE) {
               System.out.println("WARNING! rule loops");
           }

           // 0件以上fireされたこと
           assertTrue(fireCnt > 0);
           
/*
           // show result
           final String header = 
                   "#PLAN_YEAR_MONTH\t" +
                   "DEALER_CODE\t" +
                   "CAR_SERIES\t" +
                   "POR_CODE\t" +
                   "END_ITEM_MODEL_CODE\t" +
                   "PRODUCTION_FAMILY_CODE\t" +
                   "RECOMMENDED_BY_SYSTEM_QTY";
           final String outFormat = "%s\t%s\t%s\t%s\t%s\t%s\t%s";
//         final String outFormat = "%s,%s,%s,%s,%s,%s,%s";
           System.out.println("\n=================== ACTUAL ==============");
           System.out.println(header);
           for (DealerAllocationResult o : resultList) {
               System.out.println(
                       String.format(outFormat,
                               o.getPlanYearMonth(),
                               o.getDealerCode(),
                               o.getCarSeries(),
                               o.getPorCode(),
                               o.getEndItemModelCode(),
                               o.getProductionFamilyCode(),
                               o.getRecommendedBySystemQty()));
           }
*/
           System.out.println("====> " + new Throwable().getStackTrace()[0].getMethodName() + " run end");
	    } catch (Exception e) {
	        e.printStackTrace();
            fail("An exception has occured.");
	    }
    }
       
	/************************************
	 * CSVファイルを読み込み、テストデータを作成する
	 * @throws Exception 
	 ************************************/
	public EndItemList makeEndItemList(String filename) throws Exception {
		EndItemList list = new EndItemList();
		FileReader filereader = new FileReader(filename);
		BufferedReader bufferedreader = new BufferedReader(filereader);

		String line;
		int i = 0;
		while((line = bufferedreader.readLine()) != null) {
		    i++;
		    if (line.length() > 0 && line.charAt(0) == '#') continue; // '#' starts single line comments.
			String[] data = line.split(",", -1);
			list.add(setEndItem(
					data[0],  // PLAN_YEAR_MONTH
					data[1],  // CAR_SERIES
					data[2],  // POR_CODE
					data[3],  // END_ITEM_MODEL_CODE
					data[4],  // PRODUCTION_FAMILY_CODE
					Integer.valueOf(data[5]).intValue(), // QTY
					i));      // lineNo
		}
		filereader.close();
		
        shuffle(list);
		return list;
	}
	
	public DealerList makeDealerList(String filename) throws Exception {
	    DealerList list = new DealerList();
		FileReader filereader = new FileReader(filename);
		BufferedReader bufferedreader = new BufferedReader(filereader);

		String line;
		while((line = bufferedreader.readLine()) != null) {
		    if (line.length() > 0 && line.charAt(0) == '#') continue; // '#' starts single line comments.
			String[] data = line.split(",", -1);
			list.add(setDealer(
					data[0], // PLAN_YEAR_MONTH
					data[1], // CAR_SERIES
					data[2], // POR_CODE
					data[3], // END_ITEM_MODEL_CODE
					data[4], // PRODUCTION_FAMILY_CODE
					data[5], // DEALER_CODDE
					Double.valueOf(data[6]).doubleValue(), // DAYS_SUPPLY
					Double.valueOf(data[7]).doubleValue(), // TARGET_DAYS_SUPPLY
					Double.valueOf(data[8]).doubleValue()  // DAILY_RETAIL
			));
		}
		filereader.close();
		
		shuffle(list);
		return list;
	}
	
	private DealerAllocationResultList makeResultList(String filename) throws Exception {
	    DealerAllocationResultList list = new DealerAllocationResultList();
		FileReader filereader = new FileReader(filename);
		BufferedReader bufferedreader = new BufferedReader(filereader);

		String line;
		while((line = bufferedreader.readLine()) != null) {
		    if (line.length() > 0 && line.charAt(0) == '#') continue; // '#' starts single line comments.
			String[] data = line.split(",", -1);
			list.add(setResult(
					data[0], // PLAN_YEAR_MONTH
					data[1], // DEALER_CODE
					data[2], // CAR_SERIES
					data[3], // POR_CODE
					data[4], // END_ITEM_MODEL_CODE
					data[5], // PRODUCTION_FAMILY_CODE
					Integer.valueOf(data[6]).intValue())); // RECOMMENDE_BY_SYSTEM_QTY
		}
		filereader.close();
		
		
//		shuffle(list);
		return list;
	}

	private DealerAllocationResult setResult(
	        String ym,
            String dealer,
	        String car,
	        String por,
			String model,
            String family,
			int qty) {
		
	    DealerAllocationResult result = new DealerAllocationResult();
		result.setPlanYearMonth(ym);
        result.setDealerCode(dealer);
		result.setCarSeries(car);
		result.setPorCode(por);
        result.setEndItemModelCode(model);
		result.setProductionFamilyCode(family);
		result.setRecommendedBySystemQty(qty);
		
		return result;
	}

	private Dealer setDealer(
	        String ym,
	        String car,
			String por,
			String model,
            String family,
			String dealer,
			double daysSupply,
			double targetDaysSupply,
			double dailyRetail) {
		
		Dealer d = new Dealer();
		d.setPlanYearMonth(ym);
		d.setCarSeries(car);
		d.setPorCode(por);
		d.setEndItemModelCode(model);
        d.setProductionFamilyCode(family);
        d.setDealerCode(dealer);
        d.setDaysSupply(daysSupply);
        d.setTargetDaysSupply(targetDaysSupply);
        d.setDailyRetail(dailyRetail);
		
		return d;
	}

	private EndItem setEndItem(
	        String ym,
	        String car,
			String por,
			String model,
			String family,
			int qty,
			int lineno) {
		
	    EndItem ei = new EndItem();
		ei.setPlanYearMonth(ym);
		ei.setCarSeries(car);
		ei.setPorCode(por);
		ei.setEndItemModelCode(model);
        ei.setProductionFamilyCode(family);
		ei.setQty(qty);
//		ei.setLineno(lineno);
		
		return ei;
	}
	
	private void checkDealerAllocationResult(
	        DealerAllocationResultList expected,
	        DealerAllocationResultList actual)
	{
		assertTrue(actual.size() > 0);
        assertEquals(expected.size(), actual.size()); // 結果と期待値の数が異なる場合

        Collections.sort(expected, new DealerAllocationResultComparator());
        Collections.sort(actual  , new DealerAllocationResultComparator());
        
		for (int idx = 0; idx < actual.size(); idx++) {
//		    System.out.println("idx = " + idx);
//		    System.out.println("act = " + actual.get(idx));
			assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
            assertEquals(expected.get(idx).getDealerCode(), actual.get(idx).getDealerCode());
			assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
            assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(expected.get(idx).getRecommendedBySystemQty(), actual.get(idx).getRecommendedBySystemQty());
		}
	}

//    public static void shuffle(List list) {}
    public static void shuffle(List list) {
        final int size = list.size();
        for (int i = 0; i < size; i++) {
            java.util.Random rand = new java.util.Random();
            int destIndex = rand.nextInt(size);
            list.set(i, list.set(destIndex, list.get(i)));
        }
    }  
  
  // DealerAllocationResultの比較
  private class DealerAllocationResultComparator implements Comparator<Object> {
      public int compare(Object self, Object other) {
          int comp = 0;
          try {
              final DealerAllocationResult selfOcf = (DealerAllocationResult) self;
              final String selfKey = selfOcf.getPlanYearMonth()
                      + selfOcf.getDealerCode()
                      + selfOcf.getCarSeries()
                      + selfOcf.getPorCode()
                      + selfOcf.getEndItemModelCode()
                      + selfOcf.getProductionFamilyCode();
              final DealerAllocationResult otherOcf = (DealerAllocationResult) other;
              final String otherKey = otherOcf.getPlanYearMonth()
                      + otherOcf.getDealerCode()
                      + otherOcf.getCarSeries()
                      + otherOcf.getPorCode()
                      + otherOcf.getEndItemModelCode()
                      + otherOcf.getProductionFamilyCode();
              comp = selfKey.compareTo(otherKey);
          } catch (Exception e) {
              e.printStackTrace();
          }
          return comp;
      }
  }
}
