/**
 * 
 */
package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.schedulecheck.DailyOCF;
import com.nissan.danswer.model.schedulecheck.DailyOCFList;
import com.nissan.danswer.model.schedulecheck.MatchingResult;
import com.nissan.danswer.model.schedulecheck.MatchingResultList;
import com.nissan.danswer.model.schedulecheck.Order;
import com.nissan.danswer.model.schedulecheck.OrderList;
import com.nissan.danswer.model.schedulecheck.Schedule;
import com.nissan.danswer.model.schedulecheck.ScheduleList;
import com.nissan.danswer.model.schedulecheck.SpecOCF;
import com.nissan.danswer.model.schedulecheck.SpecOCFList;

/**
 * @author NDH70384
 */
public class CSVParser {

    private static final char DEFAULT_SEPARATOR = ',';

    public static void writeLine(Writer w, List<String> values) throws IOException {
        writeLine(w, values, DEFAULT_SEPARATOR, ' ');
    }

    public static void writeLine(Writer w, List<String> values, char separators) throws IOException {
        writeLine(w, values, separators, ' ');
    }

    // https://tools.ietf.org/html/rfc4180
    private static String followCVSformat(String value) {

        String result = value;
        if (result.contains("\"")) {
            result = result.replace("\"", "\"\"");
        }
        return result;

    }

    public static void writeLine(Writer w, List<String> values, char separators, char customQuote) throws IOException {

        boolean first = true;

        // default customQuote is empty

        if (separators == ' ') {
            separators = DEFAULT_SEPARATOR;
        }

        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (!first) {
                sb.append(separators);
            }
            if (customQuote == ' ') {
                sb.append(followCVSformat(value));
            } else {
                sb.append(customQuote).append(followCVSformat(value)).append(customQuote);
            }

            first = false;
        }
        sb.append("\n");
        w.append(sb.toString());

    }

    public static DailyOCFList makeDailyOcfList(String filename) throws Exception {
        String data[] = new String[13];
        DailyOCFList list = new DailyOCFList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setDailyOCF(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
                    data[9], data[10], Integer.valueOf(data[11]).intValue(), Integer.valueOf(data[12]).intValue()));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    public static OrderList makeOrderList(String filename) throws Exception {
        String data[] = new String[18];
        OrderList list = new OrderList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setOrder(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
                    data[9], data[10], data[11], data[12], data[13], Integer.valueOf(data[14]).intValue(), data[15],
                    data[16], data[17]));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    private static Order setOrder(String ym, String car, String por, String family, String model, String color,
        String productionOrderNo, String dealerCode, String orderType, String accountNo, String allocationPriority,
        String inputDateOfOrder, String weekOfDue, String dealerReplyFlg, int randomNo, String distributionNo,
        String weekNo, String day) {

        Order orderInfo = new Order();
        orderInfo.setPlanYearMonth(ym);
        orderInfo.setCarSeries(car);
        orderInfo.setPorCode(por);
        orderInfo.setProductionFamilyCode(family);
        orderInfo.setEndItemModelCode(model);
        orderInfo.setEndItemColorCode(color);
        orderInfo.setProductionOrderNo(productionOrderNo);
        orderInfo.setDealerCode(dealerCode);
        orderInfo.setOrderType(orderType);
        orderInfo.setAccountNo(accountNo);
        orderInfo.setAllocationPriority(allocationPriority);
        orderInfo.setInputDateOfOrder(inputDateOfOrder);
        orderInfo.setWeekOfDueDateForDelivery(weekOfDue);
        orderInfo.setDealerReplyFlg(dealerReplyFlg);
        orderInfo.setRandomNo(randomNo);
        orderInfo.setDistributionNo(distributionNo);
        orderInfo.setWeekNo(weekNo);
        orderInfo.setDay(day);

        return orderInfo;
    }

    // Schedule
    public static ScheduleList makeScheduleList(String filename) throws Exception {
        String data[] = new String[11];
        ScheduleList list = new ScheduleList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setSchedule(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
                    data[9], data[10]));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    // SPEC_OCF
    public static SpecOCFList makeSpecOcfList(String filename) throws Exception {
        String data[] = new String[12];
        SpecOCFList list = new SpecOCFList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            int i = 0;
            while ((line = bufferedreader.readLine()) != null) {
                // System.out.println("Start line at " + i);
                data = line.split(",", -1);
                if (i > 0 && list.get(i - 1).getPlanYearMonth().equals(data[0])
                    && list.get(i - 1).getCarSeries().equals(data[1])
                    && list.get(i - 1).getPorCode().equals(data[2])
                    && list.get(i - 1).getProductionFamilyCode().equals(data[3])
                    && list.get(i - 1).getEndItemModelCode().equals(data[4])
                    && list.get(i - 1).getEndItemColorCode().equals(data[5])
                    && list.get(i - 1).getWeekNo().equals(data[11])) {
                    list.get(i - 1).getOcfList().add(setOcfInfo(data[6], data[7], data[8], data[9], data[10]));
                } else {
                    list.add(setSpecOCF(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
                        data[9], data[10], data[11]));
                    i++;
                }
            }
            // System.out.println(i+"a");
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    public static DailyOCF setDailyOCF(String ym, String car, String weekNo, String day, String factory, String line,
        String sort, String ocfClass, String loc, String group, String frame, int maxQty, int actualQty) {

        DailyOCF ocf = new DailyOCF();
        ocf.setPlanYearMonth(ym);
        ocf.setCarSeries(car);
        ocf.setWeekNo(weekNo);
        ocf.setDay(day);
        ocf.setFactoryCode(factory);
        ocf.setLineClass(line);
        ocf.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
        ocf.setMaxQty(maxQty);
        ocf.setActualQty(actualQty);

        return ocf;
    }

    public static OCFIdentificationInfo setOcfInfo(String sort, String ocfClass, String loc, String group,
        String frame) {

        OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
        ocfInfo.setFrameSortCode(sort);
        ocfInfo.setOcfClassificationCode(ocfClass);
        ocfInfo.setLocationIdentificationCode(loc);
        ocfInfo.setCarGroup(group);
        ocfInfo.setFrameCode(frame);

        return ocfInfo;
    }

    public static SpecOCF setSpecOCF(String ym, String car, String por, String family, String model, String color,
        String sort, String ocfclass, String loc, String group, String frame, String weekNo) {

        SpecOCF spec = new SpecOCF();
        spec.setPlanYearMonth(ym);
        spec.setCarSeries(car);
        spec.setPorCode(por);
        spec.setProductionFamilyCode(family);
        spec.setEndItemModelCode(model);
        spec.setEndItemColorCode(color);
        spec.setWeekNo(weekNo);

        List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
        ocfList.add(setOcfInfo(sort, ocfclass, loc, group, frame));

        spec.setOcfList(ocfList);

        return spec;
    }

    private static Schedule setSchedule(String ym, String car, String por, String family, String model, String color,
        String factoy, String line, String newNo, String offDatePlan, String weekNo) {

        Schedule schedule = new Schedule();
        schedule.setPlanYearMonth(ym);
        schedule.setCarSeries(car);
        schedule.setProductionFamilyCode(family);
        schedule.setPorCode(por);
        schedule.setEndItemModelCode(model);
        schedule.setEndItemColorCode(color);
        schedule.setFactoryCode(factoy);
        schedule.setLineClass(line);
        schedule.setNewProductionOrderNo(newNo);
        schedule.setOffDatePlan(offDatePlan);
        schedule.setWeekNo(weekNo);

        return schedule;
    }

    public static MatchingResultList makeMatchingResultList(String filename) throws Exception {
        String data[] = new String[22];
        MatchingResultList list = new MatchingResultList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setResult(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8],
                    data[9], data[10], data[11], data[12], data[13], Integer.valueOf(data[14]).intValue(), data[15],
                    data[16], data[17], data[18], data[19], data[20], data[21]));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    private static MatchingResult setResult(String ym, String car, String por, String family, String model,
        String color, String productionOrderNo, String dealerCode, String orderType, String accountNo,
        String allocationPriority, String inputDateOfOrder, String weekOfDue, String dealerReplyFlg, int randomNo,
        String distributionNo, String weekNo, String day, String factory, String line, String newNo,
        String offDatePlan) {

        MatchingResult result = new MatchingResult();
        result.setPlanYearMonth(ym);
        result.setCarSeries(car);
        result.setPorCode(por);
        result.setProductionFamilyCode(family);
        result.setEndItemModelCode(model);
        result.setEndItemColorCode(color);
        result.setProductionOrderNo(productionOrderNo);
        result.setDealerCode(dealerCode);
        result.setOrderType(orderType);
        result.setAccountNo(accountNo);
        result.setAllocationPriority(allocationPriority);
        result.setInputDateOfOrder(inputDateOfOrder);
        result.setWeekOfDueDateForDelivery(weekOfDue);
        result.setDealerReplyFlg(dealerReplyFlg);
        result.setRandomNo(randomNo);
        result.setDistributionNo(distributionNo);
        result.setFactoryCode(day);
        result.setLineClass(factory);
        result.setNewProductionOrderNo(line);
        result.setOffDatePlan(newNo);
        result.setWeekNo(weekNo);
        result.setDay(offDatePlan);

        return result;
    }

}
