package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.stockcover.InOrder;
import com.nissan.danswer.model.stockcover.InOrderList;
import com.nissan.danswer.model.stockcover.OCFDaily;
import com.nissan.danswer.model.stockcover.OCFDailyList;
import com.nissan.danswer.model.stockcover.OutOrder;
import com.nissan.danswer.model.stockcover.OutOrderList;
import com.nissan.danswer.model.stockcover.SpecOCF;
import com.nissan.danswer.model.stockcover.SpecOCFList;

@SuppressWarnings("restriction")
public class StockCoverTest {

    // 最大fire件数
    private static int MAX_FIRE = 500000;
    // DRFファイル名
    private static String rfName = "StockCover.rf";
    // flowID
    private static String flowID = "com.nissan.danswer.flow.stockcover";
    // DRLファイル名
    private static String drlName = "StockCover.drl";
    // テストデータ格納場所
    private static String filepath = "../d-answer-testdata/data/stockcover";

    // knowledgeBase
    private static KnowledgeBase kbase = null;

    // knowledge session
    private StatefulKnowledgeSession ksession;

    // logger
    // private KnowledgeRuntimeLogger logger = null;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {

        // knowledgeBuilder
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
                .newKnowledgeBuilder();

        // add resources to KnowledgeBuilder
        kbuilder.add(ResourceFactory.newClassPathResource(drlName),
                ResourceType.DRL);
        kbuilder.add(ResourceFactory.newClassPathResource(rfName),
                ResourceType.DRF);

        // knowledgeBuilderErrors
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error : errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }

        // knowledgeBase
        kbase = KnowledgeBaseFactory.newKnowledgeBase();

        // add knowledgePackages to knowledgeBase
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
    }

    @Before
    public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();

        // logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
        // "log/OcfSlottingTest");
    }

    @After
    public void tearDown() {
        // if (logger != null) {
        // logger.close();
        // }
        // dispose a knowledge session
        if (ksession != null) {
            ksession.dispose();
        }
    }

    /**
     * ルール空実行
     */
    @Test
    public void testEmpty() {
        System.out.println("TEST OF empty");
        // fire
        ksession.startProcess(flowID);
        int fireCnt = ksession.fireAllRules(MAX_FIRE);

        assertEquals(0, fireCnt);

        System.out.println("empty");
    }

    // ORDERが1件の場合
    @Test
    public void test01() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test01/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test01/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test01/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test01/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test01/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // ORDERが2件の場合
    @Test
    public void test02() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test02/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test02/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test02/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test02/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test02/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // ORDERが3件以上の場合
    @Test
    public void test03() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test03/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test03/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test03/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test03/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test03/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    // ORDERが3件以上の場合
    @Test
    public void test04() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test04/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test04/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test04/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test04/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test04/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test05() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test05/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test05/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test05/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test05/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test05/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test06() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test06/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test06/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test06/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test06/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test06/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test07() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test07/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test07/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test07/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test07/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test07/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test08() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test08/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test08/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test08/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test08/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test08/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test09() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test09/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test09/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test09/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test09/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test09/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test10() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test10/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test10/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test10/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test10/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test10/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test89() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test89/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test89/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test89/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            Date startDate = new Date();
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
            Date endDate = new Date();

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/test89/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/test89/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);


            BigDecimal bdTime = new BigDecimal(endDate.getTime()
                    - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : "
                    + bdTime.divide(new BigDecimal(1000.0), 2,
                            RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);
            System.out.println("out : " + out.size());

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }
    
    // @Test
    public void test99() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/test99/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/test99/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath + "/test99/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            Date startDate = new Date();
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);
            Date endDate = new Date();

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            BigDecimal bdTime = new BigDecimal(endDate.getTime()
                    - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : "
                    + bdTime.divide(new BigDecimal(1000.0), 2,
                            RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);
            System.out.println("out : " + out.size());

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    @Test
    public void test100() {
        try {
            System.out.println("============================== "
                    + new Throwable().getStackTrace()[0].getMethodName());

            // input Fact list
            InOrderList orders = readCSV_EI_ALLOC(filepath
                    + "/matsuTest/order.csv");
            SpecOCFList specocfs = readCSV_SPEC_OCF(filepath
                    + "/matsuTest/spec_ocf.csv");
            OCFDailyList ocfs = readCSV_OCF_DAILY(filepath
                    + "/matsuTest/ocf.csv");

            OutOrderList out = new OutOrderList();

            ksession.insert(orders);
            ksession.insert(specocfs);
            ksession.insert(ocfs);
            ksession.insert(out);

            // fire
            ksession.startProcess(flowID);
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // OutOrder予測結果
            OutOrderList expectedOutOrder = readCSV_EI_ALLOC_RESULT(filepath
                    + "/matsuTest/order_result.csv");
            checkOrders(expectedOutOrder, out);

            // OCF予測結果
            OCFDailyList exptectedOcf = readCSV_OCF_DAILY_RESULT(filepath
                    + "/matsuTest/ocf_result.csv");
            checkOCF(exptectedOcf, ocfs);

            System.out.println("====> "
                    + new Throwable().getStackTrace()[0].getMethodName()
                    + " run end");
            ksession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            fail("An exception has occured.");
        }
    }

    /************************************
     * CSVファイルを読み込み、テストデータを作成する
     * 
     * @throws Exception
     ************************************/
    // InOrder
    public static InOrderList readCSV_EI_ALLOC(String filename)
            throws Exception {
        InOrderList list = new InOrderList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            i++;
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String data[] = line.split(",", -1);
            // System.out.println(String.format("index = %d", i));
            list.add(setEndItemReAlloc(data[0], // PLAN_YEAR_MONTH
                    data[1], // CAR_SERIES
                    data[2], // END_ITEM_MODEL_CODE
                    data[3], // END_ITEM_COLOR_CODE
                    Integer.parseInt(data[4]), // QTY
                    i));
        }
        filereader.close();
        return list;
    }

    // InOrder
    public static OutOrderList readCSV_EI_RESULT_ALLOC(String filename)
            throws Exception {
        OutOrderList list = new OutOrderList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        // int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            // i++;
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String[] data = line.split(",", -1);
            list.add(setOrderResult(data[0], // PLAN_YEAR_MONTH
                    data[1], // CAR_SERIES
                    data[2], // END_ITEM_MODEL_CODE
                    data[3], // END_ITEM_COLOR_CODE
                    data[4], // NEW_OFFLINE_DATE
                    data[5], // NEW_OFFLINE_WEEK
                    data[6], // NEW_FACTORY_CLASS
                    data[7]));// NEW_LINE_CLASS
        }
        filereader.close();
        return list;
    }

    /**
     * CSV読み込み（SpecOCF）
     * 
     * @param fileName
     * @throws Exception
     */
    public static SpecOCFList readCSV_SPEC_OCF(String filename)
            throws Exception {
        SpecOCFList list = new SpecOCFList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        int j = 0;
        while ((line = bufferedreader.readLine()) != null) {
            j++;
            // System.out.println("csv " + j + "行目");
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String data[] = line.split(",", -1);
            if (i > 0
                    && list.get(i - 1).getPlanYearMonth().equals(data[0])
                    && list.get(i - 1).getCarSeries().equals(data[1])
                    && list.get(i - 1).getPorCode().equals(data[2])
                    && list.get(i - 1).getProductionFamilyCode()
                            .equals(data[3])
                    && list.get(i - 1).getEndItemModelCode().equals(data[4])
                    && list.get(i - 1).getEndItemColorCode().equals(data[5])
                    && list.get(i - 1).getWeekNo().equals(data[6])) {
                // EIキーが同じ場合は、OCF情報のみを追加
                list.get(i - 1)
                        .getOcfList()
                        .add(setOcfInfo(data[7], data[8], data[9], data[10],
                                data[11]));
            } else {
                // 新規行追加
                list.add(setSpecOCF_CSV(data[0], // PLAN_YEAR_MONTH
                        data[1], // CAR_SERIES
                        data[2], // POR_CODE
                        data[3], // PRODUCTION_FAMILY_CODE
                        data[4], // END_ITEM_MODEL_CODE
                        data[5], // END_ITEM_COLOR_CODE
                        data[6], // WEEK_NO
                        data[7], // FRAME_SORT_CODE
                        data[8], // OCF_CLASSIFICATION_CODE
                        data[9], // LOCATION_IDENTIFICATION_CODE
                        data[10],// CAR_GROUP
                        data[11],// FRAME_CODE
                        j));
                i++;
            }
        }
        // System.out.println(i+"a");
        filereader.close();
        return list;
    }

    // OCF DAILY
    public static OCFDailyList readCSV_OCF_DAILY(String filename)
            throws Exception {
        OCFDailyList list = new OCFDailyList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        int i = 0;
        while ((line = bufferedreader.readLine()) != null) {
            i++;
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String data[] = line.split(",", -1);
            list.add(setOCFDaily(data[0], // PLAN_YEAR_MONTH
                    data[1], // CAR_SERIES
                    data[2], // FRAME_SORT_CODE(OCF INFO.)
                    data[3], // OCF_CLASSIFICATIONI_CODE(OCF INFO.)
                    data[4], // LOCATION_IDENTIFICATION_CODE(OCF INFO.)
                    data[5], // CAR_GROUP(OCF INFO.)
                    data[6], // FACTORY_CODE
                    data[7], // LINE_CLASS
                    data[8], // FRAME_CODE(OCF INFO.)
                    data[9], // WEEK_NO
                    data[10], // DATE
                    Integer.valueOf(data[11]).intValue(), // MAX_QTY
                    i));
        }
        filereader.close();

        return list;
    }

    public static OCFDailyList readCSV_OCF_DAILY_RESULT(String filename)
            throws Exception {
        OCFDailyList list = new OCFDailyList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        while ((line = bufferedreader.readLine()) != null) {
            // System.out.println("Start line at " + i);
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String data[] = line.split(",", -1);
            list.add(setOCFDaily_result(data[0], // PLAN_YEAR_MONTH
                    data[1], // CAR_SERIES
                    data[2], // FRAME_SORT_CODE(OCF INFO.)
                    data[3], // OCF_CLASSIFICATIONI_CODE(OCF INFO.)
                    data[4], // LOCATION_IDENTIFICATION_CODE(OCF INFO.)
                    data[5], // CAR_GROUP(OCF INFO.)
                    data[6], // FACTORY_CODE
                    data[7], // LINE_CLASS
                    data[8], // FRAME_CODE(OCF INFO.)
                    data[9], // WEEK_NO
                    data[10],// DATE
                    Integer.valueOf(data[11]).intValue(), // MAX_QTY
                    Integer.valueOf(data[12]).intValue())); // ACT_QTY
        }
        filereader.close();
        return list;
    }

    // EndItemReAlloc
    public static OutOrderList readCSV_EI_ALLOC_RESULT(String filename)
            throws Exception {
        OutOrderList list = new OutOrderList();
        FileReader filereader = new FileReader(filename);
        BufferedReader bufferedreader = new BufferedReader(filereader);

        String line;
        while ((line = bufferedreader.readLine()) != null) {
            // System.out.println("Start line at " + i);
            if (line.length() > 0 && line.charAt(0) == '#')
                continue; // '#' starts single line comments.
            String data[] = line.split(",", -1);
            list.add(setEndItemReAllocResult(data[0], // PLAN_YEAR_MONTH
                    data[1], // CAR_SERIES
                    data[2], // END_ITEM_MODEL_CODE
                    data[3], // END_ITEM_COLOR_CODE
                    data[4], // NEW_OFFLINE_DATE
                    data[5], // NEW_OFFLINE_WEEK
                    data[6], // NEW_FACTORY_CODE
                    data[7]));// NEW_LINE_CLASS
        }
        filereader.close();
        return list;
    }

    private static OCFDaily setOCFDaily(String ym, String car, String sort, // OCF
                                                                            // INFO
            String ocfClass, // OCF INFO
            String loc, // OCF INFO
            String group, // OCF INFO
            String factory, String line, String frame, // OCF INFO
            String week, String date, int max, int lineno) {
        OCFDaily ocfDaily = new OCFDaily();
        ocfDaily.setPlanYearMonth(ym);
        ocfDaily.setCarSeries(car);
        ocfDaily.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
        ocfDaily.setFactoryCode(factory);
        ocfDaily.setLineClass(line);
        ocfDaily.setWeekNo(week);
        ocfDaily.setDate(date);
        ocfDaily.setMaxQty(max);

        try {
            Class<?> ocfCls = OCFDaily.class;
        	// setLineno()メソッド(デバッグ用)があれば、CSVの行数をセットする
			Method setter = ocfCls.getMethod("setLineno", int.class);
			setter.invoke(ocfDaily, lineno);
		} catch (NoSuchMethodException e) {
			// setLineno()メソッドがなければ、なにもしない
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

        return ocfDaily;
    }

    private static OCFDaily setOCFDaily_result(String ym,
            String car,
            String sort, // OCF INFO
            String ocfClass, // OCF INFO
            String loc, // OCF INFO
            String group, // OCF INFO
            String factory, String line, String frame, String week, String day,
            int max, int actQty) {
        OCFDaily ocfDaily = new OCFDaily();
        ocfDaily.setPlanYearMonth(ym);
        ocfDaily.setCarSeries(car);
        ocfDaily.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
        ocfDaily.setFactoryCode(factory);
        ocfDaily.setLineClass(line);
        ocfDaily.setWeekNo(week);
        ocfDaily.setDate(day);
        ocfDaily.setMaxQty(max);
        ocfDaily.setActualQty(actQty);

        return ocfDaily;
    }

    private static OCFIdentificationInfo setOcfInfo(String sort,
            String ocfClass, String loc, String group, String frame) {

        OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
        ocfInfo.setFrameSortCode(sort);
        ocfInfo.setOcfClassificationCode(ocfClass);
        ocfInfo.setLocationIdentificationCode(loc);
        ocfInfo.setCarGroup(group);
        ocfInfo.setFrameCode(frame);

        return ocfInfo;
    }

    private static InOrder setEndItemReAlloc(String ym, String carSeries,
            String model, String color, int qty, int lineno) {
        InOrder order = new InOrder();
        order.setPlanYearMonth(ym);
        order.setCarSeries(carSeries);
        order.setEndItemModelCode(model);
        order.setEndItemColorCode(color);
        order.setQty(qty);

        try {
            Class<?> inOrderCls = InOrder.class;
        	// setLineno()メソッド(デバッグ用)があれば、CSVの行数をセットする
			Method setter = inOrderCls.getMethod("setLineno", int.class);
			setter.invoke(order, lineno);
		} catch (NoSuchMethodException e) {
			// setLineno()メソッドがなければ、なにもしない
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

        return order;
    }

    private static OutOrder setEndItemReAllocResult(String ym,
            String carSeries, String model, String color,
            String newOfflineDate, String newOfflineWeek,
            String newFactoryCode, String newLineClass) {
        OutOrder order = new OutOrder();
        order.setPlanYearMonth(ym);
        order.setCarSeries(carSeries);
        order.setEndItemModelCode(model);
        order.setEndItemColorCode(color);
        order.setNewOfflineDate(newOfflineDate);
        order.setNewOfflineWeek(newOfflineWeek);
        order.setNewFactoryCode(newFactoryCode);
        order.setNewLineClass(newLineClass);

        return order;
    }

    private static OutOrder setOrderResult(String ym, String carSeries,
            String model, String color, String newOfflineDate,
            String newOfflineWeek, String newFactoryCode, String newLineClass) {
        OutOrder order = new OutOrder();
        order.setPlanYearMonth(ym);
        order.setCarSeries(carSeries);
        order.setEndItemModelCode(model);
        order.setEndItemColorCode(color);
        order.setNewOfflineDate(newOfflineDate);
        order.setNewOfflineWeek(newOfflineWeek);
        order.setNewFactoryCode(newFactoryCode);
        order.setNewLineClass(newLineClass);

        return order;
    }

    // csv
    private static SpecOCF setSpecOCF_CSV(String ym, String car, String por,
            String family, String model, String color, String weekNo,
            String sort, String ocfClass, String loc, String group,
            String frame, int line) {
        SpecOCF spec = new SpecOCF();
        spec.setPlanYearMonth(ym);
        spec.setCarSeries(car);
        spec.setPorCode(por);
        spec.setProductionFamilyCode(family);
        spec.setEndItemModelCode(model);
        spec.setEndItemColorCode(color);
        spec.setWeekNo(weekNo);

        List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
        ocfList.add(setOcfInfo(sort, ocfClass, loc, group, frame));
        spec.setOcfList(ocfList);

//        spec.setLineno(line);
        
        try {
            Class<?> specCls = SpecOCF.class;
        	// setLineno()メソッド(デバッグ用)があれば、CSVの行数をセットする
			Method setter = specCls.getMethod("setLineno", int.class);
			setter.invoke(spec, line);
		} catch (NoSuchMethodException e) {
			// setLineno()メソッドがなければ、なにもしない
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

        return spec;
    }

    private void checkOrders(OutOrderList expected, OutOrderList actual) {
        assertEquals(expected.size(), actual.size()); // 結果と期待値のOrder数が異なる場合

        // Collections.sort(expected, new OrderComparator());
        // Collections.sort(actual, new OrderComparator());

        for (int i = 0; i < actual.size(); i++) {
            OutOrder order = actual.get(i);
            System.out.println("Actual OutOrder[" + i + "] = " + order);
            System.out.println("Expected OutOrder[" + i + "] = " + expected.get(i));
            assertEquals(expected.get(i).getPlanYearMonth(),
                    order.getPlanYearMonth());
            assertEquals(expected.get(i).getCarSeries(), order.getCarSeries());
            assertEquals(expected.get(i).getEndItemModelCode(),
                    order.getEndItemModelCode());
            assertEquals(expected.get(i).getEndItemColorCode(),
                    order.getEndItemColorCode());

            assertEquals(expected.get(i).getNewOfflineDate(),
                    order.getNewOfflineDate());
            assertEquals(expected.get(i).getNewOfflineWeek(),
                    order.getNewOfflineWeek());
            assertEquals(expected.get(i).getNewFactoryCode(),
                    order.getNewFactoryCode());
            assertEquals(expected.get(i).getNewLineClass(),
                    order.getNewLineClass());
        }
    }

    private void checkOCF(OCFDailyList expected, OCFDailyList actual) {
        for (int idx = 0; idx < expected.size(); idx++) {
            final OCFDaily ocf = expected.get(idx);
            System.out.println("Expected OCF[" + idx + "] = " + ocf);
            System.out.println("Accual OCF[" + idx + "] = " + actual.get(idx));
            assertEquals(ocf.getPlanYearMonth(), actual.get(idx)
                    .getPlanYearMonth());
            assertEquals(ocf.getCarSeries(), actual.get(idx).getCarSeries());
            assertEquals(ocf.getOcfInfo().getFrameSortCode(), actual.get(idx)
                    .getOcfInfo().getFrameSortCode());
            assertEquals(ocf.getOcfInfo().getOcfClassificationCode(), actual
                    .get(idx).getOcfInfo().getOcfClassificationCode());
            assertEquals(ocf.getOcfInfo().getLocationIdentificationCode(),
                    actual.get(idx).getOcfInfo()
                            .getLocationIdentificationCode());
            assertEquals(ocf.getOcfInfo().getCarGroup(), actual.get(idx)
                    .getOcfInfo().getCarGroup());
            assertEquals(ocf.getOcfInfo().getFrameCode(), actual.get(idx)
                    .getOcfInfo().getFrameCode());
            assertEquals(ocf.getMaxQty(), actual.get(idx).getMaxQty());
            assertEquals(ocf.getActualQty(), actual.get(idx).getActualQty());
        }
    }
}
