package test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.DanswerConstant;
import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.eibreakdown.EndItemRatio;
import com.nissan.danswer.model.eibreakdown.EndItemRatioList;
import com.nissan.danswer.model.eibreakdown.EndItemSlottingResult;
import com.nissan.danswer.model.eibreakdown.EndItemSlottingResultList;
import com.nissan.danswer.model.eibreakdown.MonthlyOCF;
import com.nissan.danswer.model.eibreakdown.MonthlyOCFList;
import com.nissan.danswer.model.eibreakdown.OCFSlottingResult;
import com.nissan.danswer.model.eibreakdown.SlotMethod;
import com.nissan.danswer.model.eibreakdown.MonthlySpecOCF;
import com.nissan.danswer.model.eibreakdown.MonthlySpecOCFList;

/**
 * EndItemBreakdown.drlのテストクラス
 * @author matsuda
 *
 */
public class EndItemBreakdownTest {
	
	// 最大fire件数
	private static int MAX_FIRE = 10000;
	
	// DRLファイル名
	private static String drlName = "EndItemBreakdown.drl";
	// テストデータ格納場所
	private static String filepath = "../d-answer-testdata/data/eibreakdown";
	
	// flowファイル名
	private static String rfName = "EndItemBreakdown.rf";
	// flowID
	private static String flowID = "com.nissan.danswer.flow.enditembreakdown";
	
	// knowledgeBase
	private static KnowledgeBase kbase = null;
	
	// knowledge session
	private StatefulKnowledgeSession ksession;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource(drlName),ResourceType.DRL);
    	kbuilder.add(ResourceFactory.newClassPathResource(rfName),ResourceType.DRF);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	}
	
	@Before
	public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();
	}
	
	@After
	public void tearDown() {
		// dispose a knowledge session
		if (ksession != null) {
			ksession.dispose();
		}
	}

	/**
	 * 強制スロット・単月
	 * END_ITEM_COLOR_CODE=NULL時のE/Iばらし
	 */
	@Test
	public void testCase9() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase9/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase9/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase9/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase9 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase9/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase9/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 強制スロット・単月
	 * 最大OCF枠取得のテスト
	 */
	@Test
	public void testCase8() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase8/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase8/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase8/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase8 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase8/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase8/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 強制スロット・単月
	 * 最大OCF枠取得のテスト
	 */
	@Test
	public void testCase7() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase7/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase7/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase7/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase7 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase7/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase7/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 通常スロット・単月
	 * 最小OCF枠取得のテスト
	 */
	@Test
	public void testCase6() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase6/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase6/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase6/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_USUAL));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase6 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase6/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase6/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 強制スロット・単月
	 * MAX_QTY=0がある場合
	 */
	@Test
	public void testCase5() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase5/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase5/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase5/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase5 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase5/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase5/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 強制スロット・単月
	 * EnditemRatio　RATIO = 0のデータがある場合
	 * MonthlyOCF  どのE/Iも使用していないOCF枠がある場合
	 */
	@Test
	public void testCase4() {

		MonthlyOCFList ocfList;
		EndItemSlottingResultList slotList;
		EndItemRatioList ratioList;
		MonthlySpecOCFList specList;
		
		try {
			ocfList = makeMonthlyOcfList(filepath + "/testCase4/ocf_monthly.csv");
			ratioList = makeEIRatioList(filepath + "/testCase4/ei_ratio.csv");
			specList = makeSpecOcfList(filepath + "/testCase4/spec_ocf.csv");
			slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase4 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly予測結果
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase4/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
	        
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase4/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 強制スロットも行う場合
	 * 複数年月データ
	 */
	@Test
	public void testCase3() {

		MonthlyOCFList ocfList;
		EndItemSlottingResultList slotList;
		EndItemRatioList ratioList;
		MonthlySpecOCFList specList;
		
		try {
			ocfList = makeMonthlyOcfList(filepath + "/testCase3/ocf_monthly.csv");
			ratioList = makeEIRatioList(filepath + "/testCase3/ei_ratio.csv");
			specList = makeSpecOcfList(filepath + "/testCase3/spec_ocf.csv");
			slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase3 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase3/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result_201304 = makeSlottingResultList(filepath + "/testCase3/slot_result_04.csv");
			EndItemSlottingResultList result_201305 = makeSlottingResultList(filepath + "/testCase3/slot_result_05.csv");
			
			// 結果件数チェック
			assertTrue(slotList.size() > 0);
	
			// 201304と201305のデータに分ける
			EndItemSlottingResultList list_201304 = new EndItemSlottingResultList();
			EndItemSlottingResultList list_201305 = new EndItemSlottingResultList();
			
			for (EndItemSlottingResult slottingResult : slotList) {
				if (slottingResult.getPlanYearMonth().equals("201304")) {
					list_201304.add(slottingResult);
				} else if (slottingResult.getPlanYearMonth().equals("201305")) {
					list_201305.add(slottingResult);
				}
			}
			
			// 201304の結果チェック
			checkSlottingResult(result_201304, list_201304);
			// 201305の結果チェック
			checkSlottingResult(result_201305, list_201305);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 通常スロットのみ・単月
	 * SpecOCFに含まれるが、OCF枠制約のないOCFがある場合
	 */
	@Test
	public void testCase2() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase2/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase2/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase2/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_USUAL));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase2 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase2/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase2/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * 車系枠のQTYより大きいQTYのOCF枠が存在する場合のテスト
	 */
	@Test
	public void testCase1() {
		try {
			MonthlyOCFList ocfList = makeMonthlyOcfList(filepath + "/testCase1/ocf_monthly.csv");
			EndItemRatioList ratioList = makeEIRatioList(filepath + "/testCase1/ei_ratio.csv");
			MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testCase1/spec_ocf.csv");
			EndItemSlottingResultList slotList = new EndItemSlottingResultList();
			
			ksession.insert(ratioList);	// 1.
			ksession.insert(ocfList);	// 2.
			ksession.insert(specList);	// 3.
			ksession.insert(slotList);	// 4.
			ksession.insert(makeSlotMethod(DanswerConstant.SLOT_METHOD_FORCE));	// 5.
			
			ksession.startProcess(flowID);
			Date startDate = new Date();
			// fire
			int fireCnt = ksession.fireAllRules(MAX_FIRE);
	
			Date endDate = new Date();
			System.out.println("====> testCase1 run end");
			
			BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
			
			System.out.println("start : " + startDate);
			System.out.println("end   : " + endDate);
			System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
			System.out.println("fireCnt : " + fireCnt);
			
			if (fireCnt == MAX_FIRE) {
				System.out.println("WARNING! rule loops");
			}
			/*** 結果確認 ****/
			// 0件以上fireされたこと
			assertTrue(fireCnt > 0);
			// OCFMonthly
			MonthlyOCFList resultOcf = makeMonthlyOcfList(filepath + "/testCase1/result_ocf.csv");
			// 予測と実際を比較
			checkOcfResult(resultOcf, ocfList);
					
			// EndItemSlottingResult予測結果
			EndItemSlottingResultList result = makeSlottingResultList(filepath + "/testCase1/slot_result.csv");
			
			// 結果チェック
			checkSlottingResult(result, slotList);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	private void checkOcfResult(MonthlyOCFList resultOcf, MonthlyOCFList ocfList) {
		
		assertTrue(ocfList.size() > 0);
		
		assertEquals(resultOcf.size(), ocfList.size());
		
		for (int idx = 0; idx < ocfList.size(); idx++) {
			MonthlyOCF monthlyOCF = ocfList.get(idx);
			assertEquals(resultOcf.get(idx).getPlanYearMonth(), monthlyOCF.getPlanYearMonth());
			assertEquals(resultOcf.get(idx).getCarSeries(), monthlyOCF.getCarSeries());
			assertEquals(resultOcf.get(idx).getOcfInfo().getFrameSortCode(), monthlyOCF.getOcfInfo().getFrameSortCode());
			assertEquals(resultOcf.get(idx).getOcfInfo().getOcfClassificationCode(), monthlyOCF.getOcfInfo().getOcfClassificationCode());
			assertEquals(resultOcf.get(idx).getOcfInfo().getLocationIdentificationCode(), monthlyOCF.getOcfInfo().getLocationIdentificationCode());
			assertEquals(resultOcf.get(idx).getOcfInfo().getCarGroup(), monthlyOCF.getOcfInfo().getCarGroup());
			assertEquals(resultOcf.get(idx).getOcfInfo().getFrameCode(), monthlyOCF.getOcfInfo().getFrameCode());
			assertEquals(resultOcf.get(idx).getMaxQty(), monthlyOCF.getMaxQty());
			assertEquals(resultOcf.get(idx).getActualQty(), monthlyOCF.getActualQty());
		}
	}
	
	private void checkSlottingResult(EndItemSlottingResultList result, EndItemSlottingResultList actual) {
		
		assertTrue(actual.size() > 0);
		
		assertEquals(result.size(), actual.size());
		
		for (int idx = 0; idx < actual.size(); idx++) {
			assertEquals(result.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
			assertEquals(result.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
			assertEquals(result.get(idx).getPorCode(), actual.get(idx).getPorCode());
			assertEquals(result.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
			assertEquals(result.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
			assertEquals(result.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
			assertEquals(result.get(idx).getOcfSlottingList(), actual.get(idx).getOcfSlottingList());
		}
	}
	
	/************************************
	 * CSVファイルを読み込み、テストデータを作成する
	 * @throws Exception 
	 ************************************/
	// SPEC_OCF
	public static MonthlySpecOCFList makeSpecOcfList(String filename) throws Exception {
		String data[]=new String[11];
		MonthlySpecOCFList list = new MonthlySpecOCFList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			int i = 0;
			while((line = bufferedreader.readLine()) != null) {
				//System.out.println("Start line at " + i);
				data = line.split(",", -1);
				if (i > 0 &&
						list.get(i-1).getPlanYearMonth().equals(data[0]) &&
						list.get(i-1).getCarSeries().equals(data[1]) &&
						list.get(i-1).getPorCode().equals(data[2]) &&
						list.get(i-1).getProductionFamilyCode().equals(data[3]) &&
						list.get(i-1).getEndItemModelCode().equals(data[4]) &&
						list.get(i-1).getEndItemColorCode().equals(data[5])) {
					// EIキーが同じ場合は、OCF情報のみを追加
					list.get(i-1).getOcfList().add(setOcfInfo(data[6], data[7], data[8], data[9], data[10]));					
				} else {
					// 新規行追加
					list.add(setSpecOCF(
							data[0], data[1], data[2], data[3],
							data[4], data[5], data[6], data[7],
							data[8], data[9], data[10]));
					i++;
				}
			}
			//System.out.println(i+"a");	
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	// MONTHLY_OCF
	public static MonthlyOCFList makeMonthlyOcfList(String filename) throws Exception {
		String data[]=new String[9];
		MonthlyOCFList list = new MonthlyOCFList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setOCFMonthly(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], Integer.valueOf(data[7]).intValue(), Integer.valueOf(data[8]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}
	
	// EI_RATIO
	public static EndItemRatioList makeEIRatioList(String filename) throws Exception {
		String data[]=new String[7];
		EndItemRatioList list = new EndItemRatioList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setEndItemRatio(
						data[0], data[1], data[2], data[3],
						data[4], data[5], Double.valueOf(data[6]).doubleValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	private static EndItemRatio setEndItemRatio(String ym, String car, String por, String family, String model, String color, double ratio) {
		
		EndItemRatio eiRatio = new EndItemRatio();
		eiRatio.setPlanYearMonth(ym);
		eiRatio.setCarSeries(car);
		eiRatio.setPorCode(por);
		eiRatio.setProductionFamilyCode(family);
		eiRatio.setEndItemModelCode(model);
		eiRatio.setEndItemColorCode(color);
		eiRatio.setRatio(ratio);
		
		return eiRatio;
	}
	
	private static MonthlyOCF setOCFMonthly(String ym, String car, String sort, String ocfClass, String loc, String group, String frame, 
			int maxQty, int actualQty) {
		
		MonthlyOCF ocfMonthly = new MonthlyOCF();
		ocfMonthly.setPlanYearMonth(ym);
		ocfMonthly.setCarSeries(car);
		ocfMonthly.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
		ocfMonthly.setMaxQty(maxQty);
		ocfMonthly.setActualQty(actualQty);
		
		return ocfMonthly;
	}

	private static OCFIdentificationInfo setOcfInfo(String sort,
			String ocfClass, String loc, String group, String frame) {
		
		OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
		ocfInfo.setFrameSortCode(sort);
		ocfInfo.setOcfClassificationCode(ocfClass);
		ocfInfo.setLocationIdentificationCode(loc);
		ocfInfo.setCarGroup(group);
		ocfInfo.setFrameCode(frame);
		
		return ocfInfo;
	}
	
	private static MonthlySpecOCF setSpecOCF(String ym, String car, String por, String family, String model, String color, String sort, 
			String ocfclass, String loc, String group, String frame) {
		
		MonthlySpecOCF spec = new MonthlySpecOCF();
		spec.setPlanYearMonth(ym);
		spec.setCarSeries(car);
		spec.setPorCode(por);
		spec.setProductionFamilyCode(family);
		spec.setEndItemModelCode(model);
		spec.setEndItemColorCode(color);
		
		List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
		ocfList.add(setOcfInfo(sort, ocfclass, loc, group, frame));
		
		spec.setOcfList(ocfList);
		
		return spec;
	}
	
	// SlotMethod(IN)
	public static SlotMethod makeSlotMethod(int flg) {
		
		SlotMethod slotMethod = new SlotMethod();
		
		// 1:usual slot,2:usual slot + force slot
		slotMethod.setSlotMethodFlg(flg);
		
		return slotMethod;
	}

	
//	// EndItemSlottingResult 強制スロット後の予測結果
//	private EndItemSlottingResultList resultSlottingResult_201304_force() {
//		
//		// 通常スロット結果
//		EndItemSlottingResultList list = resultSlottingResult_201304();
//		
//		// 強制スロット結果を追加
//		list.add(setSlottingResult("201304", "K01", "P", "F", "A", "X1", new String[][]{{"00","TRUE"},{"20","TRUE"},{"90","FALSE"}}));
//		list.add(setSlottingResult("201304", "K01", "P", "F", "A", "X1", new String[][]{{"00","TRUE"},{"20","TRUE"},{"90","FALSE"}}));
//		list.add(setSlottingResult("201304", "K01", "P", "F", "C", "X1", new String[][]{{"00","TRUE"},{"30","FALSE"},{"50","FALSE"},{"90","FALSE"}}));
//		list.add(setSlottingResult("201304", "K01", "P", "F", "B", "X1", new String[][]{{"00","TRUE"},{"30","FALSE"},{"40","TRUE"},{"90","FALSE"}}));
//		
//		return list;
//	}
//	
//	// EndItemSlottingResult 強制スロット後の予測結果
//	private EndItemSlottingResultList resultSlottingResult_201305_force() {
//		
//		EndItemSlottingResultList list = resultSlottingResult_201305();
//		
//		list.add(setSlottingResult("201305", "K01", "P", "F", "C", "X1", new String[][]{{"00","TRUE"},{"30","TRUE"},{"40","FALSE"},{"90","TRUE"}}));
//		list.add(setSlottingResult("201305", "K01", "P", "F", "B", "X1", new String[][]{{"00","TRUE"},{"30","TRUE"},{"40","FALSE"},{"9A","TRUE"}}));
//		list.add(setSlottingResult("201305", "K01", "P", "F", "C", "X1", new String[][]{{"00","TRUE"},{"30","TRUE"},{"40","FALSE"},{"90","TRUE"}}));
//		list.add(setSlottingResult("201305", "K01", "P", "F", "B", "X1", new String[][]{{"00","TRUE"},{"30","TRUE"},{"40","FALSE"},{"9A","TRUE"}}));		
//		list.add(setSlottingResult("201305", "K01", "P", "F", "C", "X1", new String[][]{{"00","TRUE"},{"30","TRUE"},{"40","FALSE"},{"90","TRUE"}}));
//		list.add(setSlottingResult("201305", "K01", "P", "F", "B", "X1", new String[][]{{"00","TRUE"},{"30","TRUE"},{"40","FALSE"},{"9A","TRUE"}}));
//		list.add(setSlottingResult("201305", "K01", "P", "F", "C", "X1", new String[][]{{"00","TRUE"},{"30","FALSE"},{"40","FALSE"},{"90","TRUE"}}));
//		list.add(setSlottingResult("201305", "K01", "P", "F", "B", "X1", new String[][]{{"00","TRUE"},{"30","FALSE"},{"40","FALSE"},{"9A","TRUE"}}));
//		
//		return list;
//	}
	
	/************************************
	 * 予測結果データ作成
	 * @throws Exception 
	 ************************************/
	private EndItemSlottingResultList makeSlottingResultList(String filename) throws Exception {
		String data[]=new String[12];
		EndItemSlottingResultList list = new EndItemSlottingResultList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			int i = 0;
			while((line = bufferedreader.readLine()) != null) {
				//System.out.println("Start line at " + i);
				data = line.split(",", -1);
				if (!"00".equals(data[10])) {
//						list.get(i-1).getPlanYearMonth().equals(data[0]) &&
//						list.get(i-1).getCarSeries().equals(data[1]) &&
//						list.get(i-1).getPorCode().equals(data[2]) &&
//						list.get(i-1).getProductionFamilyCode().equals(data[3]) &&
//						list.get(i-1).getEndItemModelCode().equals(data[4]) &&
//						list.get(i-1).getEndItemColorCode().equals(data[5])) {
					// 車系枠の場合、次のE/Iとみなす
					list.get(i-1).getOcfSlottingList().add(setOcfSlotResult(data[0], data[1],
							setOcfInfo(data[6], data[7], data[8], data[9], data[10]), data[11]));					
				} else {
					// 新規行追加
					list.add(setEISlotResult(
							data[0], data[1], data[2], data[3],
							data[4], data[5], data[6], data[7],
							data[8], data[9], data[10], data[11]));
					i++;
				}
			}
			//System.out.println(i+"a");	
			filereader.close();
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(filename + ":err");
			throw e;
		}	
		
		return list;
	}

	private EndItemSlottingResult setEISlotResult(String ym, String car, String por, String family, String model,
			String color, String sort, String ocfClass, String loc, String group, String frame, String slotOkFlg) {
		
		EndItemSlottingResult eiResult = new EndItemSlottingResult();
		eiResult.setPlanYearMonth(ym);
		eiResult.setCarSeries(car);
		eiResult.setPorCode(por);
		eiResult.setProductionFamilyCode(family);
		eiResult.setEndItemModelCode(model);
		eiResult.setEndItemColorCode(color);
		
		List<OCFSlottingResult> ocfSlottingList = new ArrayList<OCFSlottingResult>();
		OCFSlottingResult ocfSlotResult = new OCFSlottingResult();
		ocfSlotResult.setPlanYearMonth(ym);
		ocfSlotResult.setCarSeries(car);
		ocfSlotResult.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
		ocfSlotResult.setSlotOkFlg("true".equals(slotOkFlg) ? true : false);
		ocfSlottingList.add(ocfSlotResult);
		
		eiResult.setOcfSlottingList(ocfSlottingList);

		return eiResult;
	}

	private OCFSlottingResult setOcfSlotResult(String ym, String car,
			OCFIdentificationInfo ocfInfo, String slotOkFlg) {
		
		OCFSlottingResult slotResult = new OCFSlottingResult();
		slotResult.setPlanYearMonth(ym);
		slotResult.setCarSeries(car);
		slotResult.setOcfInfo(ocfInfo);
		slotResult.setSlotOkFlg("true".equals(slotOkFlg) ? true : false);
		
		return slotResult;
	}
}
