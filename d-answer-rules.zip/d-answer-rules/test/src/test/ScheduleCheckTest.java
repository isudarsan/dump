package test;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
// import org.drools.logger.KnowledgeRuntimeLogger;
// import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.schedulecheck.SpecOCFList;
import com.nissan.danswer.model.schedulecheck.SpecOCF;
import com.nissan.danswer.model.schedulecheck.DailyOCFList;
import com.nissan.danswer.model.schedulecheck.DailyOCF;
import com.nissan.danswer.model.schedulecheck.MatchingResultList;
import com.nissan.danswer.model.schedulecheck.MatchingResult;
import com.nissan.danswer.model.schedulecheck.OrderList;
import com.nissan.danswer.model.schedulecheck.Order;
import com.nissan.danswer.model.schedulecheck.OrderOnlyList;
import com.nissan.danswer.model.schedulecheck.ScheduleList;
import com.nissan.danswer.model.schedulecheck.Schedule;
import com.nissan.danswer.model.schedulecheck.ScheduleOnlyList;

public class ScheduleCheckTest {

    // 最大fire件数
    private static int MAX_FIRE = 60000;

    // DRLファイル名
    private static String drlName = "ScheduleCheck.drl";
    // テストデータ格納場所
    private static String filepath = "../d-answer-testdata/data/schedulecheck";

    // DRFファイル名
    private static String rfName = "ScheduleCheck.rf";
    // flowID
    private static String flowID = "com.nissan.danswer.flow.schedulecheck";

    // knowledgeBase
    private static KnowledgeBase kbase = null;

    // knowledge session
    private StatefulKnowledgeSession ksession;

    // logger
    private KnowledgeRuntimeLogger logger = null;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {

        // knowledgeBuilder
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();

        // add resources to KnowledgeBuilder
        kbuilder.add(ResourceFactory.newClassPathResource(drlName), ResourceType.DRL);
        kbuilder.add(ResourceFactory.newClassPathResource(rfName), ResourceType.DRF);

        // knowledgeBuilderErrors
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error : errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }

        // knowledgeBase
        kbase = KnowledgeBaseFactory.newKnowledgeBase();

        // add knowledgePackages to knowledgeBase
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
    }

    @Before
    public void setUp() {
        // creates a knowledge session
        ksession = kbase.newStatefulKnowledgeSession();

        // logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/ScheduleCheckTest");
    }

    @After
    public void tearDown() {
        if (logger != null) {
            logger.close();
        }
        // dispose a knowledge session
        if (ksession != null) {
            ksession.dispose();
        }
    }

    /**
     * 単なる実行用
     */
    // @Test
    public void simpleExecute() {
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/performanceTest/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/performanceTest/schedule.csv");
            DailyOCFList ocfList = makeDailyOcfList(filepath + "/performanceTest/daily_ocf.csv");
            SpecOCFList specList = makeSpecOcfList(filepath + "/performanceTest/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            ksession.insert(specList); // IN
            ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly);
            ksession.insert(scheduleOnly);

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules();

            Date endDate = new Date();
            System.out.println("====> simpleExecute run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);

            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }

            // System.out.println("==== result ====");
            // for (MatchingResult result : resultList) {
            // System.out.println(result.toString());
            // }
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * 月次処理
     */
    // @Test
    public void testMonthly() {
        String csvFile = "brms_monthly.csv";
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/testMonthly1/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/testMonthly1/schedule.csv");
            DailyOCFList ocfList = makeDailyOcfList(filepath + "/testMonthly1/daily_ocf.csv");
            SpecOCFList specList = makeSpecOcfList(filepath + "/testMonthly1/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            ksession.insert(specList); // IN
            ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly); // OUT
            ksession.insert(scheduleOnly); // OUT

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            Date endDate = new Date();
            // System.out.println("====> testMonthly run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            // System.out.println("start : " + startDate);
            // System.out.println("end : " + endDate);
            // System.out.println("time : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            // System.out.println("fireCnt : " + fireCnt);
            //
            if (fireCnt == MAX_FIRE) {
                // System.out.println("WARNING! rule loops");
            }

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            //
            // // DailyOCF予測結果
            DailyOCFList expectedOcf = makeDailyOcfList(filepath + "/testMonthly1/result_ocf.csv");
            // // 予測と実際を比較
            checkOcfResult(expectedOcf, ocfList);
            //
            //
            //
            // // MatchingResult予測結果
            MatchingResultList expectedResult = makeMatchingResultList(filepath + "/testMonthly1/result_matching.csv");
            // // 予測と実際を比較

            FileWriter writer = new FileWriter(csvFile);
            for (MatchingResult matchingResult : resultList) {
                List<String> list = new ArrayList<String>();

                list.add(matchingResult.getPlanYearMonth());
                list.add(matchingResult.getCarSeries());
                list.add(matchingResult.getPorCode());
                list.add(matchingResult.getProductionFamilyCode());
                list.add(matchingResult.getEndItemModelCode());
                list.add(matchingResult.getEndItemColorCode());
                list.add(matchingResult.getProductionOrderNo());
                list.add(matchingResult.getDealerCode());
                list.add(matchingResult.getOrderType());
                list.add(matchingResult.getAccountNo());
                list.add(matchingResult.getAllocationPriority());
                list.add(matchingResult.getInputDateOfOrder());
                list.add(matchingResult.getWeekOfDueDateForDelivery());
                list.add(matchingResult.getDealerReplyFlg());
                list.add(String.valueOf(matchingResult.getRandomNo()));
                list.add(matchingResult.getDistributionNo());
                list.add(matchingResult.getWeekNo());
                list.add(matchingResult.getFactoryCode());
                list.add(matchingResult.getLineClass());
                list.add(matchingResult.getNewProductionOrderNo());
                list.add(matchingResult.getOffDatePlan());

                list.add(matchingResult.getDay());

                CSVParser.writeLine(writer, list);
            }

            writer.flush();
            writer.close();

            checkMatchingResult(expectedResult, resultList);

            // Order予測結果
            // OrderList expectedOrder = makeOrderList(filepath + "/testMonthly1/result_order.csv");
            // // 予測と実際を比較
            // checkOrderResult(expectedOrder, orderOnly);

            // // Schedule予測結果
            // ScheduleList expectedSchedule = makeScheduleList(filepath + "/testMonthly1/result_schedule.csv");
            // // 予測と実際を比較
            // checkSheduleResult(expectedSchedule, scheduleOnly);

        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }

    /**
     * 月次処理(複数基準車系）
     */
    // @Test
    public void testMonthlySomeCarSeries() {
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/testMonthlySomeCarSeries/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/testMonthlySomeCarSeries/schedule.csv");
            DailyOCFList ocfList = makeDailyOcfList(filepath + "/testMonthlySomeCarSeries/daily_ocf.csv");
            SpecOCFList specList = makeSpecOcfList(filepath + "/testMonthlySomeCarSeries/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            ksession.insert(specList); // IN
            ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly); // OUT
            ksession.insert(scheduleOnly); // OUT

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            Date endDate = new Date();
            System.out.println("====> testMonthlySomeCarSeries run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);

            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // DailyOCF予測結果
            DailyOCFList expectedOcf = makeDailyOcfList(filepath + "/testMonthlySomeCarSeries/result_ocf.csv");
            // 予測と実際を比較
            checkOcfResult(expectedOcf, ocfList);

            // MatchingResult予測結果
            MatchingResultList expectedResult = makeMatchingResultList(filepath + "/testMonthlySomeCarSeries/result_matching.csv");
            // 予測と実際を比較
            checkMatchingResult(expectedResult, resultList);

            // Order予測結果
            OrderList expectedOrder = makeOrderList(filepath + "/testMonthlySomeCarSeries/result_order.csv");
            // 予測と実際を比較
            checkOrderResult(expectedOrder, orderOnly);

            // Schedule予測結果
            ScheduleList expectedSchedule = makeScheduleList(filepath + "/testMonthlySomeCarSeries/result_schedule.csv");
            // 予測と実際を比較
            checkSheduleResult(expectedSchedule, scheduleOnly);

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * 週次処理テスト
     */
    @Test
    public void testWeekly() {
        String csvFile = "brms_weekly_subset.csv";
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/testWeekly1/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/testWeekly1/schedule.csv");
            // DailyOCFList ocfList = makeDailyOcfList(filepath + "/testWeekly/daily_ocf.csv");
            // SpecOCFList specList = makeSpecOcfList(filepath + "/testWeekly/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            // ksession.insert(specList); // IN
            // ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly); // OUT
            ksession.insert(scheduleOnly); // OUT

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            Date endDate = new Date();
            System.out.println("====> testWeekly run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);

            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // DailyOCF予測結果
            // DailyOCFList expectedOcf = makeDailyOcfList(filepath + "/testWeekly/result_ocf.csv");
            // 予測と実際を比較
            // checkOcfResult(expectedOcf, ocfList);

            // MatchingResult予測結果
            MatchingResultList expectedResult = makeMatchingResultList(filepath + "/testWeekly1/result_matching.csv");

            // 予測と実際を比較
            checkMatchingResult(expectedResult, resultList);
            
            
//            Collections.sort(resultList, new MatchingResultComparator());
//            FileWriter writer = new FileWriter(csvFile);
//            for (MatchingResult matchingResult : resultList) {
//                List<String> list = new ArrayList<String>();
//
//                list.add(matchingResult.getPlanYearMonth());
//                list.add(matchingResult.getCarSeries());
//                list.add(matchingResult.getPorCode());
//                list.add(matchingResult.getProductionFamilyCode());
//                list.add(matchingResult.getEndItemModelCode());
//                list.add(matchingResult.getEndItemColorCode());
//                list.add(matchingResult.getProductionOrderNo());
//                list.add(matchingResult.getDealerCode());
//                list.add(matchingResult.getOrderType());
//                list.add(matchingResult.getAccountNo());
//                list.add(matchingResult.getAllocationPriority());
//                list.add(matchingResult.getInputDateOfOrder());
//                list.add(matchingResult.getWeekOfDueDateForDelivery());
//                list.add(matchingResult.getDealerReplyFlg());
//                list.add(String.valueOf(matchingResult.getRandomNo()));
//                list.add(matchingResult.getDistributionNo());
//                list.add(matchingResult.getWeekNo());
//                list.add(matchingResult.getFactoryCode());
//                list.add(matchingResult.getLineClass());
//                list.add(matchingResult.getNewProductionOrderNo());
//                list.add(matchingResult.getOffDatePlan());
//
//                list.add(matchingResult.getDay());
//
//                CSVParser.writeLine(writer, list);
//            }
//
//            writer.flush();
//            writer.close();

            // Order予測結果
            // OrderList expectedOrder = makeOrderList(filepath + "/testWeekly1/result_order.csv");
            // 予測と実際を比較
            // checkOrderResult(expectedOrder, orderOnly);

            // Schedule予測結果
            // ScheduleList expectedSchedule = makeScheduleList(filepath + "/testWeekly1/result_schedule.csv");
            // 予測と実際を比較
            // checkSheduleResult(expectedSchedule, scheduleOnly);
        } catch (Exception e) {
            fail(e.getMessage());
        }

    }

    /**
     * 日次処理テスト
     */
    // @Test
    public void testDaily() {
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/testDaily/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/testDaily/schedule.csv");
            // DailyOCFList ocfList = makeDailyOcfList(filepath + "/testDaily/daily_ocf.csv");
            // SpecOCFList specList = makeSpecOcfList(filepath + "/testDaily/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            // ksession.insert(specList); // IN
            // ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly); // OUT
            ksession.insert(scheduleOnly); // OUT

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            Date endDate = new Date();
            System.out.println("====> testDaily run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);

            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // DailyOCF予測結果
            // DailyOCFList expectedOcf = makeDailyOcfList(filepath + "/testDaily/result_ocf.csv");
            // 予測と実際を比較
            // checkOcfResult(expectedOcf, ocfList);

            // MatchingResult予測結果
            MatchingResultList expectedResult = makeMatchingResultList(filepath + "/testDaily/result_matching.csv");
            // 予測と実際を比較
            checkMatchingResult(expectedResult, resultList);

            // Order予測結果
            OrderList expectedOrder = makeOrderList(filepath + "/testDaily/result_order.csv");
            // 予測と実際を比較
            checkOrderResult(expectedOrder, orderOnly);

            // Schedule予測結果
            ScheduleList expectedSchedule = makeScheduleList(filepath + "/testDaily/result_schedule.csv");
            // 予測と実際を比較
            checkSheduleResult(expectedSchedule, scheduleOnly);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * 週次処理テスト(OCF,SpecOCFがINデータとして渡されない場合）
     */
    // @Test
    public void testWeeklyNoOcf() {
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/testWeeklyNoOcf/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/testWeeklyNoOcf/schedule.csv");
            // DailyOCFList ocfList = makeDailyOcfList(filepath + "/testWeeklyNoOcf/daily_ocf.csv");
            // MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testWeeklyNoOcf/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            // ksession.insert(specList); // IN
            // ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly); // OUT
            ksession.insert(scheduleOnly); // OUT

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            Date endDate = new Date();
            System.out.println("====> testWeeklyNoOcf run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);

            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // MatchingResult予測結果
            MatchingResultList expectedResult = makeMatchingResultList(filepath + "/testWeeklyNoOcf/result_matching.csv");
            // 予測と実際を比較
            checkMatchingResult(expectedResult, resultList);

            // Order予測結果
            OrderList expectedOrder = makeOrderList(filepath + "/testWeeklyNoOcf/result_order.csv");
            // 予測と実際を比較
            checkOrderResult(expectedOrder, orderOnly);

            // Schedule予測結果
            ScheduleList expectedSchedule = makeScheduleList(filepath + "/testWeeklyNoOcf/result_schedule.csv");
            // 予測と実際を比較
            checkSheduleResult(expectedSchedule, scheduleOnly);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * 日次処理テスト(OCF,SpecOCFがINデータとして渡されない場合）
     */
    // @Test
    public void testDailyNoOcf() {
        try {
            // input Fact list
            OrderList orderList = makeOrderList(filepath + "/testDailyNoOcf/order.csv");
            ScheduleList scheduleList = makeScheduleList(filepath + "/testDailyNoOcf/schedule.csv");
            // DailyOCFList ocfList = makeDailyOcfList(filepath + "/testDailyNoOcf/daily_ocf.csv");
            // MonthlySpecOCFList specList = makeSpecOcfList(filepath + "/testDailyNoOcf/spec_ocf.csv");
            MatchingResultList resultList = new MatchingResultList();
            OrderOnlyList orderOnly = new OrderOnlyList();
            ScheduleOnlyList scheduleOnly = new ScheduleOnlyList();

            ksession.insert(orderList); // IN/OUT
            ksession.insert(scheduleList); // IN/OUT
            // ksession.insert(specList); // IN
            // ksession.insert(ocfList); // IN/OUT
            ksession.insert(resultList); // OUT
            ksession.insert(orderOnly); // OUT
            ksession.insert(scheduleOnly); // OUT

            ksession.startProcess(flowID);

            Date startDate = new Date();

            // fire
            int fireCnt = ksession.fireAllRules(MAX_FIRE);

            Date endDate = new Date();
            System.out.println("====> testDailyNoOcf run");

            BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());

            System.out.println("start : " + startDate);
            System.out.println("end   : " + endDate);
            System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
            System.out.println("fireCnt : " + fireCnt);

            if (fireCnt == MAX_FIRE) {
                System.out.println("WARNING! rule loops");
            }

            /*** 結果確認 ****/
            // 0件以上fireされたこと
            assertTrue(fireCnt > 0);

            // MatchingResult予測結果
            MatchingResultList expectedResult = makeMatchingResultList(filepath + "/testDailyNoOcf/result_matching.csv");
            // 予測と実際を比較
            checkMatchingResult(expectedResult, resultList);

            // Order予測結果
            OrderList expectedOrder = makeOrderList(filepath + "/testDailyNoOcf/result_order.csv");
            // 予測と実際を比較
            checkOrderResult(expectedOrder, orderOnly);

            // Schedule予測結果
            ScheduleList expectedSchedule = makeScheduleList(filepath + "/testDailyNoOcf/result_schedule.csv");
            // 予測と実際を比較
            checkSheduleResult(expectedSchedule, scheduleOnly);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /************************************
     * CSVファイルを読み込み、テストデータを作成する
     * 
     * @throws Exception
     ************************************/
    public static DailyOCFList makeDailyOcfList(String filename) throws Exception {
        String data[] = new String[13];
        DailyOCFList list = new DailyOCFList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setDailyOCF(
                    data[0], data[1], data[2], data[3],
                    data[4], data[5], data[6], data[7],
                    data[8], data[9], data[10],
                    Integer.valueOf(data[11]).intValue(), Integer.valueOf(data[12]).intValue()));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    // Schedule
    public static ScheduleList makeScheduleList(String filename) throws Exception {
        String data[] = new String[11];
        ScheduleList list = new ScheduleList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setSchedule(
                    data[0], data[1], data[2], data[3],
                    data[4], data[5], data[6], data[7],
                    data[8], data[9], data[10]));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    // SPEC_OCF
    public static SpecOCFList makeSpecOcfList(String filename) throws Exception {
        String data[] = new String[12];
        SpecOCFList list = new SpecOCFList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            int i = 0;
            while ((line = bufferedreader.readLine()) != null) {
                // System.out.println("Start line at " + i);
                data = line.split(",", -1);
                if (i > 0 &&
                    list.get(i - 1).getPlanYearMonth().equals(data[0]) &&
                    list.get(i - 1).getCarSeries().equals(data[1]) &&
                    list.get(i - 1).getPorCode().equals(data[2]) &&
                    list.get(i - 1).getProductionFamilyCode().equals(data[3]) &&
                    list.get(i - 1).getEndItemModelCode().equals(data[4]) &&
                    list.get(i - 1).getEndItemColorCode().equals(data[5]) &&
                    list.get(i - 1).getWeekNo().equals(data[11])) {
                    // EIキーが同じ場合は、OCF情報のみを追加
                    list.get(i - 1).getOcfList().add(setOcfInfo(data[6], data[7], data[8], data[9], data[10]));
                } else {
                    // 新規行追加
                    list.add(setSpecOCF(
                        data[0], data[1], data[2], data[3],
                        data[4], data[5], data[6], data[7],
                        data[8], data[9], data[10], data[11]));
                    i++;
                }
            }
            // System.out.println(i+"a");
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    // ORDER_INFO
    public static OrderList makeOrderList(String filename) throws Exception {
        String data[] = new String[18];
        OrderList list = new OrderList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setOrder(
                    data[0], data[1], data[2], data[3],
                    data[4], data[5], data[6], data[7],
                    data[8], data[9], data[10], data[11],
                    data[12], data[13], Integer.valueOf(data[14]).intValue(), data[15],
                    data[16], data[17]));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    // 引当結果
    private MatchingResultList makeMatchingResultList(String filename) throws Exception {
        String data[] = new String[22];
        MatchingResultList list = new MatchingResultList();
        try {
            FileReader filereader = new FileReader(filename);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            while ((line = bufferedreader.readLine()) != null) {
                data = line.split(",", -1);
                list.add(setResult(
                    data[0], data[1], data[2], data[3],
                    data[4], data[5], data[6], data[7],
                    data[8], data[9], data[10], data[11],
                    data[12], data[13], Integer.valueOf(data[14]).intValue(), data[15],
                    data[16], data[17], data[18], data[19], data[20], data[21]));
            }
            filereader.close();
        } catch (Exception e) {
            System.out.println(filename + ":err");
            throw e;
        }

        return list;
    }

    private MatchingResult setResult(String ym, String car, String por, String family, String model, String color,
        String productionOrderNo, String dealerCode, String orderType, String accountNo, String allocationPriority,
        String inputDateOfOrder, String weekOfDue, String dealerReplyFlg, int randomNo, String distributionNo,
        String weekNo, String day, String factory, String line, String newNo, String offDatePlan) {

        MatchingResult result = new MatchingResult();
        result.setPlanYearMonth(ym);
        result.setCarSeries(car);
        result.setPorCode(por);
        result.setProductionFamilyCode(family);
        result.setEndItemModelCode(model);
        result.setEndItemColorCode(color);
        result.setProductionOrderNo(productionOrderNo);
        result.setDealerCode(dealerCode);
        result.setOrderType(orderType);
        result.setAccountNo(accountNo);
        result.setAllocationPriority(allocationPriority);
        result.setInputDateOfOrder(inputDateOfOrder);
        result.setWeekOfDueDateForDelivery(weekOfDue);
        result.setDealerReplyFlg(dealerReplyFlg);
        result.setRandomNo(randomNo);
        result.setDistributionNo(distributionNo);
        result.setFactoryCode(day);
        result.setLineClass(factory);
        result.setNewProductionOrderNo(line);
        result.setOffDatePlan(newNo);
        result.setWeekNo(weekNo);
        result.setDay(offDatePlan);

        return result;
    }

    public static DailyOCF setDailyOCF(String ym, String car, String weekNo, String day,
        String factory, String line,
        String sort, String ocfClass, String loc, String group, String frame,
        int maxQty, int actualQty) {

        DailyOCF ocf = new DailyOCF();
        ocf.setPlanYearMonth(ym);
        ocf.setCarSeries(car);
        ocf.setWeekNo(weekNo);
        ocf.setDay(day);
        ocf.setFactoryCode(factory);
        ocf.setLineClass(line);
        ocf.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
        ocf.setMaxQty(maxQty);
        ocf.setActualQty(actualQty);

        return ocf;
    }

    public static OCFIdentificationInfo setOcfInfo(String sort, String ocfClass, String loc, String group, String frame) {

        OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
        ocfInfo.setFrameSortCode(sort);
        ocfInfo.setOcfClassificationCode(ocfClass);
        ocfInfo.setLocationIdentificationCode(loc);
        ocfInfo.setCarGroup(group);
        ocfInfo.setFrameCode(frame);

        return ocfInfo;
    }

    public static SpecOCF setSpecOCF(String ym, String car, String por, String family, String model, String color, String sort,
        String ocfclass, String loc, String group, String frame, String weekNo) {

        SpecOCF spec = new SpecOCF();
        spec.setPlanYearMonth(ym);
        spec.setCarSeries(car);
        spec.setPorCode(por);
        spec.setProductionFamilyCode(family);
        spec.setEndItemModelCode(model);
        spec.setEndItemColorCode(color);
        spec.setWeekNo(weekNo);

        List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
        ocfList.add(setOcfInfo(sort, ocfclass, loc, group, frame));

        spec.setOcfList(ocfList);

        return spec;
    }

    public static Order setOrder(String ym, String car, String por, String family, String model, String color,
        String productionOrderNo, String dealerCode, String orderType,
        String accountNo, String allocationPriority, String inputDateOfOrder, String weekOfDue,
        String dealerReplyFlg, int randomNo, String distributionNo, String weekNo, String day) {

        Order orderInfo = new Order();
        orderInfo.setPlanYearMonth(ym);
        orderInfo.setCarSeries(car);
        orderInfo.setPorCode(por);
        orderInfo.setProductionFamilyCode(family);
        orderInfo.setEndItemModelCode(model);
        orderInfo.setEndItemColorCode(color);
        orderInfo.setProductionOrderNo(productionOrderNo);
        orderInfo.setDealerCode(dealerCode);
        orderInfo.setOrderType(orderType);
        orderInfo.setAccountNo(accountNo);
        orderInfo.setAllocationPriority(allocationPriority);
        orderInfo.setInputDateOfOrder(inputDateOfOrder);
        orderInfo.setWeekOfDueDateForDelivery(weekOfDue);
        orderInfo.setDealerReplyFlg(dealerReplyFlg);
        orderInfo.setRandomNo(randomNo);
        orderInfo.setDistributionNo(distributionNo);
        orderInfo.setWeekNo(weekNo);
        orderInfo.setDay(day);

        return orderInfo;
    }

    private static Schedule setSchedule(String ym, String car, String por, String family, String model, String color,
        String factoy, String line, String newNo, String offDatePlan,
        String weekNo) {

        Schedule schedule = new Schedule();
        schedule.setPlanYearMonth(ym);
        schedule.setCarSeries(car);
        schedule.setProductionFamilyCode(family);
        schedule.setPorCode(por);
        schedule.setEndItemModelCode(model);
        schedule.setEndItemColorCode(color);
        schedule.setFactoryCode(factoy);
        schedule.setLineClass(line);
        schedule.setNewProductionOrderNo(newNo);
        schedule.setOffDatePlan(offDatePlan);
        schedule.setWeekNo(weekNo);

        return schedule;
    }

    /* 結果確認用 */
    private void checkOcfResult(DailyOCFList expected, DailyOCFList actual) {

        assertTrue(actual.size() > 0);

        assertEquals(expected.size(), actual.size());

        for (int idx = 0; idx < actual.size(); idx++) {
            assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
            assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
            assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
            assertEquals(expected.get(idx).getDay(), actual.get(idx).getDay());
            assertEquals(expected.get(idx).getFactoryCode(), actual.get(idx).getFactoryCode());
            assertEquals(expected.get(idx).getLineClass(), actual.get(idx).getLineClass());
            assertEquals(expected.get(idx).getOcfInfo().getFrameSortCode(), actual.get(idx).getOcfInfo().getFrameSortCode());
            assertEquals(expected.get(idx).getOcfInfo().getOcfClassificationCode(),
                actual.get(idx).getOcfInfo().getOcfClassificationCode());
            assertEquals(expected.get(idx).getOcfInfo().getLocationIdentificationCode(),
                actual.get(idx).getOcfInfo().getLocationIdentificationCode());
            assertEquals(expected.get(idx).getOcfInfo().getCarGroup(), actual.get(idx).getOcfInfo().getCarGroup());
            assertEquals(expected.get(idx).getOcfInfo().getFrameCode(), actual.get(idx).getOcfInfo().getFrameCode());
            assertEquals(expected.get(idx).getMaxQty(), actual.get(idx).getMaxQty());
            assertEquals(expected.get(idx).getActualQty(), actual.get(idx).getActualQty());
        }
    }

    private class MatchingResultComparator implements Comparator<Object> {

        @Override
        public int compare(Object o1, Object o2) {
            try {
                MatchingResult lhs = (MatchingResult)o1;
                MatchingResult rhs = (MatchingResult)o2;
                if (lhs.getCarSeries().compareTo(rhs.getCarSeries()) == 0) {
                    return lhs.getProductionOrderNo().compareTo(rhs.getProductionOrderNo());
                } else {
                    return lhs.getCarSeries().compareTo(rhs.getCarSeries());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }

    }

    private void checkMatchingResult(MatchingResultList expected, MatchingResultList actual) {

        assertTrue(actual.size() > 0);

        assertEquals(expected.size(), actual.size());

        Collections.sort(expected, new MatchingResultComparator());
        Collections.sort(actual, new MatchingResultComparator());

        for (int idx = 0; idx < actual.size(); idx++) {
            // System.out.println(expected.get(idx));
            // System.out.println(actual.get(idx));

            assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
            assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
            assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
            assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
            assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
            assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
            assertEquals(expected.get(idx).getProductionOrderNo(), actual.get(idx).getProductionOrderNo());
            assertEquals(expected.get(idx).getDealerCode(), actual.get(idx).getDealerCode());
            assertEquals(expected.get(idx).getOrderType(), actual.get(idx).getOrderType());
            assertEquals(expected.get(idx).getAccountNo(), actual.get(idx).getAccountNo());
            assertEquals(expected.get(idx).getAllocationPriority(), actual.get(idx).getAllocationPriority());
            assertEquals(expected.get(idx).getInputDateOfOrder(), actual.get(idx).getInputDateOfOrder());
            assertEquals(expected.get(idx).getWeekOfDueDateForDelivery(), actual.get(idx).getWeekOfDueDateForDelivery());
            assertEquals(expected.get(idx).getDealerReplyFlg(), actual.get(idx).getDealerReplyFlg());
            assertEquals(expected.get(idx).getRandomNo(), actual.get(idx).getRandomNo());
            assertEquals(expected.get(idx).getFactoryCode(), actual.get(idx).getFactoryCode());
            assertEquals(expected.get(idx).getLineClass(), actual.get(idx).getLineClass());
            assertEquals(expected.get(idx).getNewProductionOrderNo(), actual.get(idx).getNewProductionOrderNo());
            assertEquals(expected.get(idx).getOffDatePlan(), actual.get(idx).getOffDatePlan());
            assertEquals(expected.get(idx).getDistributionNo(), actual.get(idx).getDistributionNo());
            assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
            assertEquals(expected.get(idx).getDay(), actual.get(idx).getDay());
        }

    }

    // 格納順序は保証しないため、一致を確かめるために、CAR_SERIES,PRODUCTION_ORDER_NOの昇順にソート
    private class OrderComparator implements Comparator<Object> {

        @Override
        public int compare(Object o1, Object o2) {
            try {
                Order lhs = (Order)o1;
                Order rhs = (Order)o2;
                if (lhs.getCarSeries().compareTo(rhs.getCarSeries()) == 0) {
                    return lhs.getProductionOrderNo().compareTo(rhs.getProductionOrderNo());
                } else {
                    return lhs.getCarSeries().compareTo(rhs.getCarSeries());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }

    }

    private void checkOrderResult(OrderList expected, OrderOnlyList actual) {

        // assertTrue(actual.size() > 0);

        Collections.sort(expected, new OrderComparator());
        Collections.sort(actual, new OrderComparator());

        for (int idx = 0; idx < actual.size(); idx++) {
            assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
            assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
            assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
            assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
            assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
            assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
            assertEquals(expected.get(idx).getProductionOrderNo(), actual.get(idx).getProductionOrderNo());
            assertEquals(expected.get(idx).getDealerCode(), actual.get(idx).getDealerCode());
            assertEquals(expected.get(idx).getOrderType(), actual.get(idx).getOrderType());
            assertEquals(expected.get(idx).getAccountNo(), actual.get(idx).getAccountNo());
            assertEquals(expected.get(idx).getAllocationPriority(), actual.get(idx).getAllocationPriority());
            assertEquals(expected.get(idx).getInputDateOfOrder(), actual.get(idx).getInputDateOfOrder());
            assertEquals(expected.get(idx).getWeekOfDueDateForDelivery(), actual.get(idx).getWeekOfDueDateForDelivery());
            assertEquals(expected.get(idx).getDealerReplyFlg(), actual.get(idx).getDealerReplyFlg());
            assertEquals(expected.get(idx).getRandomNo(), actual.get(idx).getRandomNo());
            assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
            assertEquals(expected.get(idx).getDay(), actual.get(idx).getDay());
        }

    }

    // 格納順序は保証しないため、一致を確かめるために、CAR_SERIES,NEW_PRODUCTION_ORDER_NOの昇順にソート
    private class ScheduleComparator implements Comparator<Object> {

        @Override
        public int compare(Object o1, Object o2) {
            try {
                Schedule lhs = (Schedule)o1;
                Schedule rhs = (Schedule)o2;
                if (lhs.getCarSeries().compareTo(rhs.getCarSeries()) == 0) {
                    return lhs.getNewProductionOrderNo().compareTo(rhs.getNewProductionOrderNo());
                } else {
                    return lhs.getCarSeries().compareTo(rhs.getCarSeries());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        }

    }

    private void checkSheduleResult(ScheduleList expected, ScheduleOnlyList actual) {

        // assertTrue(actual.size() > 0);

        Collections.sort(expected, new ScheduleComparator());
        Collections.sort(actual, new ScheduleComparator());

        for (int idx = 0; idx < actual.size(); idx++) {
            assertEquals(expected.get(idx).getPlanYearMonth(), actual.get(idx).getPlanYearMonth());
            assertEquals(expected.get(idx).getCarSeries(), actual.get(idx).getCarSeries());
            assertEquals(expected.get(idx).getProductionFamilyCode(), actual.get(idx).getProductionFamilyCode());
            assertEquals(expected.get(idx).getPorCode(), actual.get(idx).getPorCode());
            assertEquals(expected.get(idx).getEndItemModelCode(), actual.get(idx).getEndItemModelCode());
            assertEquals(expected.get(idx).getEndItemColorCode(), actual.get(idx).getEndItemColorCode());
            assertEquals(expected.get(idx).getFactoryCode(), actual.get(idx).getFactoryCode());
            assertEquals(expected.get(idx).getLineClass(), actual.get(idx).getLineClass());
            assertEquals(expected.get(idx).getNewProductionOrderNo(), actual.get(idx).getNewProductionOrderNo());
            assertEquals(expected.get(idx).getOffDatePlan(), actual.get(idx).getOffDatePlan());
            assertEquals(expected.get(idx).getWeekNo(), actual.get(idx).getWeekNo());
        }

    }

}
