package com.nissan.danswer.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.reallocation.EndItemReAlloc;
import com.nissan.danswer.model.reallocation.EndItemReAllocList;
import com.nissan.danswer.model.reallocation.FactoryLine;
import com.nissan.danswer.model.reallocation.FactoryLineList;
import com.nissan.danswer.model.reallocation.OCFDaily;
import com.nissan.danswer.model.reallocation.OCFDailyList;
import com.nissan.danswer.model.reallocation.SpecOCF;
import com.nissan.danswer.model.reallocation.SpecOCFList;

public class TestReAllocation {

//    // パフォーマンス試験用データ (600OK-600NG / 1,200Order)
//	static final String EI_REALLOC_FILENAME      = "../d-answer-testdata/data/endItemRealloc/order600-600.csv";
//    static final String SPEC_OCF_FILENAME		 = "../d-answer-testdata/data/endItemRealloc/spec_ocf1200.csv";
//    static final String OCF_DAILY_FILENAME		 = "../d-answer-testdata/data/endItemRealloc/ocf300.csv";
    
//    // パフォーマンス試験用データ (6,000OK / 6,000Order)
//	static final String EI_REALLOC_FILENAME      = "../d-answer-testdata/data/endItemRealloc/order6000.csv";
//    static final String SPEC_OCF_FILENAME		 = "../d-answer-testdata/data/endItemRealloc/spec_ocf1200.csv";
//    static final String OCF_DAILY_FILENAME		 = "../d-answer-testdata/data/endItemRealloc/ocf300.csv";
    
//    // パフォーマンス試験用データ (300OK-3000NG / 6,000Order)
//	static final String EI_REALLOC_FILENAME      = "../d-answer-testdata/data/endItemRealloc/order3000-3000.csv";
//    static final String SPEC_OCF_FILENAME		 = "../d-answer-testdata/data/endItemRealloc/spec_ocf1200.csv";
//    static final String OCF_DAILY_FILENAME		 = "../d-answer-testdata/data/endItemRealloc/ocf300.csv";

    // パフォーマンス試験用データ (1,000OK / 1,000Order)
    // 月次・週次         : 970
    // 納期指定           : 10
    // 再引当て対象外: 10
    // 生産未確定       : 10
    static final String EI_REALLOC_FILENAME = "../d-answer-testdata/data/endItemRealloc/TestCasePF1/order1000.csv";
    static final String SPEC_OCF_FILENAME = "../d-answer-testdata/data/endItemRealloc/TestCasePF1/spec_ocf1200.csv";
    static final String OCF_DAILY_FILENAME = "../d-answer-testdata/data/endItemRealloc/TestCasePF1/ocf300.csv";

    public static void main(String[] args) throws Exception {

        KnowledgeBase kbase = readKnowledgeBase();

//      final StatelessKnowledgeSession ksession =
//              kbase.newStatelessKnowledgeSession();
        final StatefulKnowledgeSession ksession = kbase
                .newStatefulKnowledgeSession();

//      KnowledgeRuntimeLogger logger =
//              KnowledgeRuntimeLoggerFactory.newFileLogger(ksession,
//                "log/TestEndItemAlloc");

        // input Fact list
//      List<Object> list = makeInputFact();
        EndItemReAllocList eiList = readCSV_EI_ALLOC();

//      List<Object> specList = new ArrayList<Object>();
//      specList.add(makeSpecOcfList());
        SpecOCFList specList = readCSV_SPEC_OCF();
        OCFDailyList ocfList = readCSV_OCF_DAILY();
//      OCFDailySortTBLList ocfSortList = readCSV_OCF_SORT();
        FactoryLineList flList = makeFactoryLineSortList();

        Date startDate = new Date();
        startDate = new Date(startDate.getTime());

        // rule execute
        System.out.println("====== execute rule ======");
//      ksession.execute(list);

        // statefull
        ksession.insert(flList);
        ksession.insert(eiList);
        ksession.insert(specList);
        ksession.insert(ocfList);
//      ksession.insert(ocfSortList);
//      ksession.insert(makeOCFSortList());
        ksession.startProcess("com.nissan.danswer.flow.reallocation");
        int fireCnt = ksession.fireAllRules();

        Date endDate = new Date();
        endDate = new Date(endDate.getTime());


        // STDOUT
        System.out.println("====== result ======");
//      sysOutResult(list);
        System.out.println("[EndItemReAllocList] ------------------------------------");
//        for (EndItemReAlloc endItemReAlloc : eiList) {
//            System.out.println(endItemReAlloc.toString());
//        }
//      for (EndItemReAlloc endItemReAlloc : eiList) {
//      System.out.println(endItemReAlloc.toString());
//  }

//        for (OCFDaily ocf : ocfList) {
//            System.out.println(ocf);
//        }

        System.out.println("start : " + startDate);
        System.out.println("end   : " + endDate);

        System.out.println("fireCnt : " + fireCnt);

        // close auditlog
//      logger.close();

        ksession.dispose();

    }

    private static FactoryLineList makeFactoryLineSortList() {
        FactoryLineList l = new FactoryLineList();
        l.add(new FactoryLine("A", "A")); // A工場、Aライン
        l.add(new FactoryLine("A", "B")); // A工場、Bライン
        l.add(new FactoryLine("A", "C")); // A工場、Cライン
//        l.add(new FactoryLine("B", "D")); // B工場、Dライン
//        l.add(new FactoryLine("B", "E")); // B工場、Eライン
//        l.add(new FactoryLine("B", "F")); // B工場、Fライン
        return l;
    }
	
	/**
	 * 
	 * @param rulesFile
	 * @return
	 * @throws Exception
	 */
	private static KnowledgeBase readKnowledgeBase() throws Exception {
    	
    	// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource("ReAllocation.drl"),ResourceType.DRL);
        kbuilder.add(ResourceFactory.newClassPathResource("ReAllocation.rf"),ResourceType.DRF);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());    
                
    	return kbase;
    }
	


    private static EndItemReAlloc setEndItemReAlloc(
            String ym,
            String carSeries,
            String distNo,
            String model,
            String color,
            String factory,
            String lineClass,
            String order,
            String reallocPri,
            String reallocScope,
            String input,
            String week,
            String fix,
            String reply,
            String random,
            String bolsa,
            String offDate,
            String offWeek,
            int i)
    {
        EndItemReAlloc endItemReAlloc = new EndItemReAlloc();
        endItemReAlloc.setPlanYearMonth(ym);
        endItemReAlloc.setCarSeries(carSeries);
        endItemReAlloc.setDistributionNo(distNo);
        endItemReAlloc.setEndItemModelCode(model);
        endItemReAlloc.setEndItemColorCode(color);
        endItemReAlloc.setFactoryCode(factory);
        endItemReAlloc.setLineClass(lineClass);
        endItemReAlloc.setOrderType(order);
        endItemReAlloc.setReallocationPriorityNo(reallocPri);
        endItemReAlloc.setReallocationScopeFlg(reallocScope);
        endItemReAlloc.setInputDateOfOrder(input);
        endItemReAlloc.setWeekOfDueDateForDelivery(week);
        endItemReAlloc.setFixFlg(fix);
        endItemReAlloc.setDealerReplyFlg(reply);
        endItemReAlloc.setRandomNo(random);
        endItemReAlloc.setBolsaOrNot(bolsa);
        endItemReAlloc.setOfflineDate(offDate);
        endItemReAlloc.setOfflineWeekNo(offWeek);
//        endItemReAlloc.setLineNo(i);

        return endItemReAlloc;
    }

    private static OCFDaily setOCFDaily(
            String ym,
            String car,
            String sort,        // OCF INFO
            String ocfClass,    // OCF INFO
            String loc,         // OCF INFO
            String group,       // OCF INFO
            String factory,
            String line,
            String frame,
            String week,
            String day,
            int max, int index)
    {
        OCFDaily ocfDaily = new OCFDaily();
        ocfDaily.setPlanYearMonth(ym);
        ocfDaily.setCarSeries(car);
        ocfDaily.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
//      ocfDaily.setFrameSortCode(sort);
//      ocfDaily.setOcfClassificationCode(ocfClass);
//      ocfDaily.setLocationIdentificationCode(loc);
//      ocfDaily.setCarGroup(group);
        ocfDaily.setFrameCode(frame);
        ocfDaily.setFactoryCode(factory);
        ocfDaily.setLineClass(line);
        ocfDaily.setWeekNo(week);
        ocfDaily.setDate(day);
        ocfDaily.setMaxQty(max);
        return ocfDaily;
    }

	private static OCFIdentificationInfo setOcfInfo(
	                                        String sort,
	                                        String ocfClass,
	                                        String loc,
	                                        String group,
	                                        String frame)
	{
		OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
		ocfInfo.setFrameSortCode(sort);
		ocfInfo.setOcfClassificationCode(ocfClass);
		ocfInfo.setLocationIdentificationCode(loc);
		ocfInfo.setCarGroup(group);
		ocfInfo.setFrameCode(frame);
		return ocfInfo;
	}



//	private static OCFDailySortTBL setSortTBL(
//									String targetWeekNo,
//									String targetDate,
//									String targetYearMonth,
//									String ocfSortKey,
//									String offlineDate,
//									String offlineWeekNo,
//									String offlineYearMonth
//	) {
//		OCFDailySortTBL sortTbl = new OCFDailySortTBL();
//		sortTbl.setTargetWeekNo(targetWeekNo);
//		sortTbl.setTargetDate(targetDate);
//		sortTbl.setTargetYearMonth(targetYearMonth);
//		sortTbl.setOcfSortKey(Long.parseLong(ocfSortKey));
//		sortTbl.setOfflineDate(offlineDate);
//		sortTbl.setOfflineWeekNo(offlineWeekNo);
//		sortTbl.setOfflineYearMonth(offlineYearMonth);
//		return sortTbl;
//	}
 
    // EndItemReAlloc
    public static EndItemReAllocList readCSV_EI_ALLOC() {
        String data[] = new String[21];
        EndItemReAllocList list = new EndItemReAllocList();
        try {
            FileReader filereader = new FileReader(EI_REALLOC_FILENAME);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
          int i = 0;
          while ((line = bufferedreader.readLine()) != null) {
              i++;
              if (line.length() > 0 && line.charAt(0) == '#') continue; // '#' starts single line comments.
              data = line.split(",", -1);
              list.add(setEndItemReAlloc(
                      data[0],  // PLAN_YEAR_MONTH
                      data[1],  // CAR_SERIES
                      data[2],  // DISTRIBUTION_NO
                      data[3],  // END_ITEM_MODEL_CODE
                      data[4],  // END_ITEM_COLOR_CODE
                      data[5],  // FACTORY_CODE
                      data[6],  // LINE_CLASS
                      data[7],  // ORDER_TYPE
                      data[8],  // RE_ALLOCATION_PRIORITY_NO
                      data[9],  // RE_ALLOCATION_SCOPE_FLG
                      data[10], // INPUT_DATE_OF_ORDER
                      data[11], // WEEK_OF_DUE_DATE_FOR_DELIVERY
                      data[12], // FIX_FLG
                      data[13], // DEALER_REPLY_FLG
                      data[14], // RANDOM_NO
                      data[15], // BOLSA_OR_NOT
                      data[16], // OFFLINE_DATE
                      data[17], // OFFLINE_WEEK_NO
                      i         // CSVの行数
                      ));
          }
            filereader.close();
        } catch (Exception e) {
            System.err.println("err readCSV_EI_ALLOC");
            e.printStackTrace();
        }

        return list;
    }

	// csv
	private static SpecOCF setSpecOCF_CSV(String ym, String car, 
			String model, String color, String weekNo,
			String sort, String ocfClass, String loc, String group, String frame,
			int index) {

		SpecOCF spec = new SpecOCF();
		spec.setPlanYearMonth(ym);
		spec.setCarSeries(car);
//		spec.setPorCode(por);
//		spec.setProductionFamilyCode(family);
		spec.setEndItemModelCode(model);
		spec.setEndItemColorCode(color);
		spec.setWeekNo(weekNo);

		List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
		ocfList.add(setOcfInfo(sort, ocfClass, loc, group, frame));
		spec.setOcfList(ocfList);

		return spec;
	}
	
	
    /**
     * CSV読み込み（SpecOCF）
     * @param fileName
     */
    public static SpecOCFList readCSV_SPEC_OCF() {
        String data[] = new String[12];
        SpecOCFList list = new SpecOCFList();
        try {
            FileReader filereader = new FileReader(SPEC_OCF_FILENAME);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            int i = 0;
            int j = 0;
            while ((line = bufferedreader.readLine()) != null) {
                j++;
//              System.out.println("csv " + j + "行目");
              if (line.length() > 0 && line.charAt(0) == '#') continue; // '#' starts single line comments.
              data = line.split(",", -1);
              if (i > 0
                      && list.get(i - 1).getPlanYearMonth().equals(data[0])
                      && list.get(i - 1).getCarSeries().equals(data[1])
//                      && list.get(i - 1).getPorCode().equals(data[2])
//                      && list.get(i - 1).getProductionFamilyCode()
//                              .equals(data[3])
                      && list.get(i - 1).getEndItemModelCode()
                              .equals(data[4])
                      && list.get(i - 1).getEndItemColorCode()
                              .equals(data[5])
                      && list.get(i - 1).getWeekNo().equals(data[6])) {
                  // EIキーが同じ場合は、OCF情報のみを追加
                  list.get(i - 1)
                          .getOcfList()
                          .add(setOcfInfo(data[7], data[8], data[9],
                                  data[10], data[11]));
              } else {
                  // 新規行追加
                  list.add(setSpecOCF_CSV(data[0], data[1], 
      //                  data[2], data[3],
                          data[4], data[5], data[6], data[7], data[8],
                          data[9], data[10], data[11], j));
                  i++;
              }
            }
            // System.out.println(i+"a");
            filereader.close();
        } catch (Exception e) {
            System.err.println("err readCSV_SPEC_OCF");
            e.printStackTrace();
        }

        return list;

    }

    // OCF DAILY
    public static OCFDailyList readCSV_OCF_DAILY() {
        String data[] = new String[12];
        OCFDailyList list = new OCFDailyList();
        try {
            FileReader filereader = new FileReader(OCF_DAILY_FILENAME);
            BufferedReader bufferedreader = new BufferedReader(filereader);

            String line;
            int i = 0;
            while ((line = bufferedreader.readLine()) != null) {
                i++;
                if (line.length() > 0 && line.charAt(0) == '#') continue; // '#' starts single line comments.
                data = line.split(",", -1);
                list.add(setOCFDaily(data[0], data[1], data[2], data[3],
                        data[4], data[5], data[6], data[7], data[8], data[9],
                        data[10], Integer.valueOf(data[11]).intValue(), i));
            }
            filereader.close();
        } catch (Exception e) {
            System.err.println("err readCSV_OCF_DAILY");
            e.printStackTrace();
        }

        return list;
    }
}
