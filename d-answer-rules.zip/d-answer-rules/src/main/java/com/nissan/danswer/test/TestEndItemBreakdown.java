package com.nissan.danswer.test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import test.EndItemBreakdownTest;

import com.nissan.danswer.model.eibreakdown.EndItemRatioList;
import com.nissan.danswer.model.eibreakdown.EndItemSlottingResult;
import com.nissan.danswer.model.eibreakdown.EndItemSlottingResultList;
import com.nissan.danswer.model.eibreakdown.MonthlyOCF;
import com.nissan.danswer.model.eibreakdown.MonthlyOCFList;
import com.nissan.danswer.model.eibreakdown.OCFSlottingResult;
import com.nissan.danswer.model.eibreakdown.SlotMethod;
import com.nissan.danswer.model.eibreakdown.MonthlySpecOCFList;


/**
 * E/I Breakdown Test
 * EndItemBreakdown.drlのテスト実行用クラス
 * @author matsuda
 *
 */
public class TestEndItemBreakdown {
	
	// DRLファイル名
	private static String drlName = "EndItemBreakdown.drl";
	// テストデータ格納場所
	private static String filepath = "../d-answer-testdata/data/eibreakdown/drltest/";
	
	static final String OCF_MONTHLY_FILENAME = filepath + "ocf_monthly.csv";
	static final String EI_RATIO_FILENAME    = filepath + "ei_ratio.csv";
	static final String SPEC_OCF_FILENAME    = filepath + "spec_ocf.csv";

	/*
	 * distinction_ocf.xls
	 * シートインデックス0:出力シートテンプレート（非表示にしてある）
	 * シートインデックス1:データ入力
	 * シートインデックス2:出力結果(毎回削除して、出力シートテンプレートのコピーによって再作成)
	 */
	/** Input-Output Excel filename **/
	static final String fileName = filepath + "eibreakdown.xls";
	/** Output Sheet Template Index **/
	static final int outputTemplateIdx_ocf = 0;
	static final int outputTemplateIdx_ei  = 1;
	/** Data Row Number **/
	static final int dataRowNum = 5;
	
	
	/**
	 * main
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
	
		// read KnowledgeBase
		KnowledgeBase kbase = readKnowledgeBase(drlName);

        // creates a knowledge session
        final StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
		
    	// auditlog
		//KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/TestEndItemBreakdown");	
						
		// rule execute
		System.out.println("====== execute rule ======");		

		// input Fact list
		MonthlyOCFList ocfList;
		EndItemSlottingResultList slotList;
		EndItemRatioList ratioList;
		MonthlySpecOCFList specList;

		// テストデータセットメソッド
		ocfList = EndItemBreakdownTest.makeMonthlyOcfList(OCF_MONTHLY_FILENAME);
		ratioList = EndItemBreakdownTest.makeEIRatioList(EI_RATIO_FILENAME);
		specList = EndItemBreakdownTest.makeSpecOcfList(SPEC_OCF_FILENAME);

		slotList = new EndItemSlottingResultList();
		
		ksession.insert(ratioList);	// 1.
		ksession.insert(ocfList);	// 2.
		ksession.insert(specList);	// 3.
		ksession.insert(slotList);	// 4.
		ksession.insert(makeSlotMethod(1));	// 5.通常 or 強制

		Date startDate = new Date();
		startDate = new Date(startDate.getTime());
		
		// fire!
		int fireCnt = ksession.fireAllRules();
		
		Date endDate = new Date();
		endDate = new Date(endDate.getTime());
		
		BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
		
		System.out.println("start : " + startDate);
		System.out.println("end   : " + endDate);
		System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
		System.out.println("fireCnt : " + fireCnt);

		// STDOUT
//		System.out.println("====== result ======");
//		System.out.println("[MonthlyOCFList] ------------------------------------");
//		for (MonthlyOCF monthlyOCF : ocfList) {
//			System.out.println(monthlyOCF.toString());
//		}
//		System.out.println("[EndItemSlottingResult] ---------------------------------");
//		for (EndItemSlottingResult endItemSlottingResult : slotList) {
//			System.out.println(endItemSlottingResult.toString());
//		}
		
		// close auditlog 
		//logger.close();
	
		ksession.dispose();

		// Excel出力準備
//		removeSheet();
//		outputExcelOCF(ocfList, "OCF_OUTPUT");
//		outputExcelEI(slotList, "ENDITEM_OUTPUT");		
		
	}

	/**
	 * 
	 * @param drlName
	 * @return
	 * @throws Exception
	 */
	private static KnowledgeBase readKnowledgeBase(String drlName) throws Exception {
    	
    	// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource(drlName),ResourceType.DRL);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());    
                
    	return kbase;
    }

	// ----------------------------↓ making test data ↓---------------------------------- //
	// SlotMethod(IN)
	private static Object makeSlotMethod(int flg) {
		
		SlotMethod slotMethod = new SlotMethod();
		
		// 1:usual slot,2:usual slot + force slot
		slotMethod.setSlotMethodFlg(flg);
		
		return slotMethod;
	}
	
	/**
	 * Output Excel
	 * @return
	 * @throws Exception
	 * @author m 
	 */
    private static void outputExcelOCF(MonthlyOCFList list, String outSheetName) throws Exception {
    	
    	Workbook wb = ExcelUtil.getWorkbook(fileName);
		// Clone output template sheet
		Sheet shInput = wb.cloneSheet(outputTemplateIdx_ocf);
    	// Remove output sheet
    	
    	// set Output sheet name
		wb.setSheetName(wb.getSheetIndex(shInput), outSheetName);
		
    	//Sheet shInput = wb.createSheet(outSheetName);
    	
		int idx = dataRowNum;
		// Base Row
		Row rowTemplate = shInput.getRow(idx);
		
		Row rowResult;
		Cell cellResult;
		
		// Set Cell Value.
		for (MonthlyOCF item:list) {
			
			// ocf not exist, add only one row
			rowResult = shInput.createRow(idx);
			
			int cellidx = 0;
			cellResult = getIndexCellStyle(rowResult, rowTemplate, cellidx);
			cellResult.setCellValue(idx-4);

			// Put Cell Value(Car Series Name).
			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getPlanYearMonth());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getCarSeries());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getOcfInfo().getFrameSortCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getOcfInfo().getOcfClassificationCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getOcfInfo().getLocationIdentificationCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getOcfInfo().getCarGroup());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getOcfInfo().getFrameCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getMaxQty());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getActualQty());

			idx++;
		}
		
		// write Excel
		ExcelUtil.writeWorkbook(fileName, wb);
		
		return;
	}
    
	/**
	 * Output Excel
	 * @return
	 * @throws Exception
	 * @author m 
	 */
    private static void outputExcelEI(EndItemSlottingResultList list, String outSheetName) throws Exception {
    	
    	Workbook wb = ExcelUtil.getWorkbook(fileName);
		// Clone output template sheet
		Sheet shInput = wb.cloneSheet(outputTemplateIdx_ei);
    	
    	// set Output sheet name
		wb.setSheetName(wb.getSheetIndex(shInput), outSheetName);
		
		int idx = dataRowNum;
		// Base Row
		Row rowTemplate = shInput.getRow(idx);
		
		Row rowResult;
		Cell cellResult;
		
		// Set Cell Value.
		for (EndItemSlottingResult item:list) {
			
			// ocf not exist, add only one row
			rowResult = shInput.createRow(idx);
			
			int cellidx = 0;
			cellResult = getIndexCellStyle(rowResult, rowTemplate, cellidx);
			cellResult.setCellValue(idx-4);

			// Put Cell Value(Car Series Name).
			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getPlanYearMonth());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getCarSeries());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getPorCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getProductionFamilyCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getEndItemModelCode());

			cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
			cellResult.setCellValue(item.getEndItemColorCode());

			for (int j = 0; j < item.getOcfSlottingList().size(); j++) {
				
				cellidx = 7;
				
				OCFSlottingResult slot = item.getOcfSlottingList().get(j);
				
				if (j > 0) {
					idx++;
					rowResult = shInput.createRow(idx);
					cellResult = getIndexCellStyle(rowResult, rowTemplate, 0);
					cellResult.setCellValue(idx-4);
				}
				
				cellResult = getIndexCellStyle(rowResult, rowTemplate, cellidx);
				cellResult.setCellValue(slot.getOcfInfo().getFrameSortCode());

				cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
				cellResult.setCellValue(slot.getOcfInfo().getOcfClassificationCode());
				
				cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
				cellResult.setCellValue(slot.getOcfInfo().getLocationIdentificationCode());
				
				cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
				cellResult.setCellValue(slot.getOcfInfo().getCarGroup());
				
				cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
				cellResult.setCellValue(slot.getOcfInfo().getFrameCode());
				
				cellResult = getIndexCellStyle(rowResult, rowTemplate, ++cellidx);
				cellResult.setCellValue(slot.isSlotOkFlg());
			}
			idx++;
		}
		
		// write Excel
		ExcelUtil.writeWorkbook(fileName, wb);
		
		return;
	}
    
    /**
     * Set CellStyle from TemplateRow
     * @param row
     * @param templateRow
     * @param cellIdx
     * @return
     */
    private static Cell getIndexCellStyle(Row row, Row templateRow, int cellIdx) {
    	Cell cellResult = null;
    	
    	cellResult = row.createCell(cellIdx);
    	
    	return cellResult;
    }
    
	/**
	 * get input sheet
	 * @return
	 * @throws Exception
	 */
	private static void removeSheet() throws Exception {
		
    	// Get Workbook
    	Workbook wb = ExcelUtil.getWorkbook(fileName);
    	
    	// Remove output sheet
    	if (wb.getNumberOfSheets() > 4) {
        	
    		for (int i = wb.getNumberOfSheets()-1; i > 2;  i--) {
    			wb.removeSheetAt(i);
    		}
        	ExcelUtil.writeWorkbook(fileName, wb);
    	}
    	
		return;
	}
}
