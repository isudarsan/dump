package com.nissan.danswer.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


/**
 * ExcelUtil
 * @author SCSK
 *
 */
public class ExcelUtil {

	// Path of Input File.
	static final String sInputFilePath = "";

	/**
	 * get sheet by sheetindex
	 * @param filename
	 * @param sheetIdx
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 */
	public static Sheet getSheet(String filename, int sheetIdx) throws Exception {

		Workbook wb = getWorkbook(filename);
		
		// Select Target Sheet.
		Sheet sheet = wb.getSheetAt(sheetIdx);
		
		System.out.println("sheetname=" +sheet.getSheetName());
		
		return sheet;
	}
	
	/**
	 * get sheet by sheetname
	 * @param filename
	 * @param sheetname
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 */
	public static Sheet getSheet(String filename, String sheetname) throws Exception {

		Workbook wb = getWorkbook(filename);
		
		// Select Target Sheet.
		Sheet sheet = wb.getSheet(sheetname);
		
		System.out.println("sheetname=" +sheet.getSheetName());
		
		return sheet;
	}
	
	/**
	 * 
	 * @param filename
	 * @return
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 */
	public static Workbook getWorkbook(String fileName) throws IOException, InvalidFormatException {
		
		FileInputStream in = null;
		Workbook wb = null;
		
		// Open an Input File.
		try{
			in = new FileInputStream(sInputFilePath + fileName);
			wb = WorkbookFactory.create(in);
		}catch(IOException e){
			System.out.println(e.toString());
			throw e;
		}catch(InvalidFormatException e){
			System.out.println(e.toString());
			throw e;
		}finally{
			try{
				in.close();
			}catch (IOException e){
				System.out.println(e.toString());
			}
		}
		
		return wb;
	}
	
	/**
	 * 
	 * @param filename
	 * @param wb
	 * @throws Exception
	 */
	public static void writeWorkbook(String filename, Workbook wb) throws Exception {
		
		// Save File.
		FileOutputStream out = null;
		try{
			out = new FileOutputStream(sInputFilePath + filename);
			wb.write(out);
		}catch(IOException e){
			System.out.println(e.toString());
			throw e;
		}finally{
			try {
				out.close();
			}catch(IOException e){
				System.out.println(e.toString());
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//
	}
	
	
	/**
	 * @param args
	 */
	public static HashMap<String, Object> getCellVal(Cell clParam) {

		// Get Cell Value.
		if (clParam == null) {
			return null;
		}

		HashMap<String, Object> mapRet = new HashMap<String, Object>();

		switch(clParam.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			System.out.println("String:" + clParam.getStringCellValue());
			mapRet.put(Integer.toString(Cell.CELL_TYPE_STRING), clParam.getStringCellValue());
			break;
		case Cell.CELL_TYPE_NUMERIC:
			if(DateUtil.isCellDateFormatted(clParam)) {
				System.out.println("Date:" + clParam.getDateCellValue());
				mapRet.put(Integer.toString(Cell.CELL_TYPE_NUMERIC), clParam.getDateCellValue());
			} else {
				System.out.println("Numeric:" + clParam.getNumericCellValue());
				mapRet.put(Integer.toString(Cell.CELL_TYPE_NUMERIC), clParam.getNumericCellValue());
			}
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			System.out.println("Boolean:" + clParam.getBooleanCellValue());
			mapRet.put(Integer.toString(Cell.CELL_TYPE_BOOLEAN), clParam.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_FORMULA:
			System.out.println("Formula:" + clParam.getCellFormula());
			mapRet.put(Integer.toString(Cell.CELL_TYPE_FORMULA), clParam.getCellFormula());
			break;
		case Cell.CELL_TYPE_ERROR :
			System.out.println("Error:" + clParam.getErrorCellValue());
			mapRet.put(Integer.toString(Cell.CELL_TYPE_ERROR), clParam.getErrorCellValue());
			break;
		case Cell.CELL_TYPE_BLANK  :
			System.out.println("Blank:");
			mapRet.put(Integer.toString(Cell.CELL_TYPE_BLANK), "");
			break;
		}
		return mapRet;
	}
	
	

}
