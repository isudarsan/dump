package com.nissan.danswer.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.nissan.danswer.model.colorbreakdown.BestSellingColor;
import com.nissan.danswer.model.colorbreakdown.ColorBreakdownResult;
import com.nissan.danswer.model.colorbreakdown.ColorBreakdownResultList;
import com.nissan.danswer.model.colorbreakdown.ColorRatio;
import com.nissan.danswer.model.colorbreakdown.ColorRatioList;
import com.nissan.danswer.model.OCFIdentificationInfo;
import com.nissan.danswer.model.colorbreakdown.MonthlyOCF;
import com.nissan.danswer.model.colorbreakdown.MonthlyOCFList;
import com.nissan.danswer.model.colorbreakdown.ProductionOrderImport;
import com.nissan.danswer.model.colorbreakdown.ProductionOrderImportList;
import com.nissan.danswer.model.colorbreakdown.RecommendedOrder;
import com.nissan.danswer.model.colorbreakdown.RecommendedOrderList;
import com.nissan.danswer.model.colorbreakdown.MonthlySpecOCF;
import com.nissan.danswer.model.colorbreakdown.MonthlySpecOCFList;


/**
 * Color Breakdown Test
 * The class for running ColorBreakdown.drl
 * @author matsuda
 *
 */
public class TestColorBreakdown {
	
	
//	static final String DRL_NAME = "ColorBreakdownNational.drl";
//	static final String FILEPATH = "../d-answer-testdata/data/colorbreakdown/drltest/";

	static final String DRL_NAME = "ColorBreakdownImport.drl";
	static final String FILEPATH = "../d-answer-testdata/data/colorbreakdownimport/drltest/";

	/*
	 * CSV filename
	 */
	static final String OCF_MONTHLY_FILENAME    = FILEPATH + "ocf_monthly.csv";
	static final String COLOR_RATIO_FILENAME    = FILEPATH + "color_ratio.csv";
	static final String SPEC_OCF_FILENAME       = FILEPATH + "spec_ocf.csv";
	static final String RECOMMENDED_FILENAME    = FILEPATH + "recommended.csv";
	static final String ORDER_IMPORT_FILENAME   = FILEPATH + "order_import.csv";

	/**
	 * main
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
	
		// read KnowledgeBase
		KnowledgeBase kbase = readKnowledgeBase(DRL_NAME);

        // creates a knowledge session
        final StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
		
    	// auditlog
		//KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "log/TestEndItemBreakdown");	
						
		// rule execute
		System.out.println("====== execute rule ======");		

		// input Fact list
		ColorRatioList ratioList;
		RecommendedOrderList recommendedList;
		ProductionOrderImportList importOrderList;
		MonthlyOCFList ocfList;
		MonthlySpecOCFList specList;
		ColorBreakdownResultList resultList;
		
		// set test data
		ratioList = makeColorRatioList(COLOR_RATIO_FILENAME);
		recommendedList = makeRecommendedList(RECOMMENDED_FILENAME);
		resultList = new ColorBreakdownResultList();
		
		ksession.insert(ratioList);	
		ksession.insert(recommendedList);
		ksession.insert(resultList);
		
		// 国産車用 >>
//		ocfList = makeMonthlyOcfList(OCF_MONTHLY_FILENAME);
//		specList = makeSpecOcfList(SPEC_OCF_FILENAME);
//		BestSellingColorList bestColorList = makeBestSellingColor(FILEPATH + "best_color.csv");	// TODO
//		ksession.insert(ocfList);			// for National	
//		ksession.insert(specList);			// for National
//		ksession.insert(bestColorList);   // for National TODO
		// 国産車用 <<
		
		// 輸入車用 >>
		importOrderList = makeImportOrderList(ORDER_IMPORT_FILENAME);
		ksession.insert(importOrderList);	// for Imported
		// 輸入車用 <<

		Date startDate = new Date();
		startDate = new Date(startDate.getTime());
		
		// fire!
		int fireCnt = ksession.fireAllRules();
		
		Date endDate = new Date();
		endDate = new Date(endDate.getTime());
		
		BigDecimal bdTime = new BigDecimal(endDate.getTime() - startDate.getTime());
		
		System.out.println("start : " + startDate);
		System.out.println("end   : " + endDate);
		System.out.println("time  : " + bdTime.divide(new BigDecimal(1000.0), 2, RoundingMode.HALF_UP) + "s");
		System.out.println("fireCnt : " + fireCnt);

		// STDOUT
		System.out.println("====== result ======");

		// 国産車用 >>
//		System.out.println("[MonthlyOCFList] ------------------------------------");
//		for (OCFMonthly monthlyOCF : ocfList) {
//			System.out.println(monthlyOCF.toString());
//		}
		// 国産車用 <<
		// for test >>
		System.out.println("[ColorRatio] ---------------------------------");
		for (ColorRatio colorRatio : ratioList) {
			System.out.println(colorRatio.toString());
		}
		// for test <<
		System.out.println("[ColorBreakdownResultList] ---------------------------------");
		for (ColorBreakdownResult breakdownResult : resultList) {
			System.out.println(breakdownResult.toString());
		}

		// close auditlog 
		//logger.close();
	
		ksession.dispose();

	}

	/**
	 * create KnowledgeBase
	 * @param drlName
	 * @return
	 * @throws Exception
	 */
	private static KnowledgeBase readKnowledgeBase(String drlName) throws Exception {
    	
    	// knowledgeBuilder
    	KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
    	
    	// add resources to KnowledgeBuilder
    	kbuilder.add(ResourceFactory.newClassPathResource("ColorBreakdown.drl"),ResourceType.DRL);
    	kbuilder.add(ResourceFactory.newClassPathResource(drlName), ResourceType.DRL);
    	
    	// knowledgeBuilderErrors    	
    	KnowledgeBuilderErrors errors = kbuilder.getErrors();
    	if (errors.size() > 0) {
    		for (KnowledgeBuilderError error: errors) {
    			System.err.println(error);
    		}
    		throw new IllegalArgumentException("Could not parse knowledge.");
    	}
        
    	// knowledgeBase
    	KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
    	
    	// add knowledgePackages to knowledgeBase
    	kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());    
                
    	return kbase;
    }

	// ----------------------------↓ making test data ↓---------------------------------- //
	private static MonthlySpecOCF setSpecOCF(String ym, String car, String por, String family, String model, String color, String sort, 
			String ocfclass, String loc, String group, String frame) {
		
		MonthlySpecOCF spec = new MonthlySpecOCF();
		spec.setPlanYearMonth(ym);
		spec.setCarSeries(car);
		spec.setPorCode(por);
		spec.setProductionFamilyCode(family);
		spec.setEndItemModelCode(model);
		spec.setEndItemColorCode(color);
		
		List<OCFIdentificationInfo> ocfList = new ArrayList<OCFIdentificationInfo>();
		ocfList.add(setOcfInfo(sort, ocfclass, loc, group, frame));
		
		spec.setOcfList(ocfList);
		
		return spec;
	}
	
	private static OCFIdentificationInfo setOcfInfo(String sort, String ocfClass, String loc, String group, String frame) {
		
		OCFIdentificationInfo ocfInfo = new OCFIdentificationInfo();
		ocfInfo.setFrameSortCode(sort);
		ocfInfo.setOcfClassificationCode(ocfClass);
		ocfInfo.setLocationIdentificationCode(loc);
		ocfInfo.setCarGroup(group);
		ocfInfo.setFrameCode(frame);
		
		return ocfInfo;
	}

	private static ColorRatio setColorRatio(String ym, String car, String por, String family, String dealer, 
			String model, String color, double ratio) {
		
		ColorRatio colorRatio = new ColorRatio();
		colorRatio.setPlanYearMonth(ym);
		colorRatio.setCarSeries(car);
		colorRatio.setPorCode(por);
		colorRatio.setProductionFamilyCode(family);
		colorRatio.setDealerCode(dealer);
		colorRatio.setEndItemModelCode(model);
		colorRatio.setEndItemColorCode(color);
		colorRatio.setRatio(ratio);
		
		return colorRatio;
	}
	
	private static MonthlyOCF setOCFMonthly(String ym, String car, String sort, String ocfClass, String loc, String group, String frame, 
			int maxQty, int actualQty) {
		
		MonthlyOCF ocfMonthly = new MonthlyOCF();
		ocfMonthly.setPlanYearMonth(ym);
		ocfMonthly.setCarSeries(car);
		ocfMonthly.setOcfInfo(setOcfInfo(sort, ocfClass, loc, group, frame));
		ocfMonthly.setMaxQty(maxQty);
		ocfMonthly.setActualQty(actualQty);
		
		return ocfMonthly;
	}
	
	private static ProductionOrderImport setImportOrder(String ym, String car, String por, String family, String model,
			String color, int qty) {
		
		ProductionOrderImport orderImport = new ProductionOrderImport();
		orderImport.setPlanYearMonth(ym);
		orderImport.setCarSeries(car);
		orderImport.setPorCode(por);
		orderImport.setProductionFamilyCode(family);
		orderImport.setEndItemModelCode(model);
		orderImport.setEndItemColorCode(color);
		orderImport.setQty(qty);

		return orderImport;
	}
	
	private static RecommendedOrder setRecommendedOrder(String ym, String car, String por, String family, String dealer, String model,
			int qty) {
		
		RecommendedOrder recommended = new RecommendedOrder();
		recommended.setPlanYearMonth(ym);
		recommended.setCarSeries(car);
		recommended.setPorCode(por);
		recommended.setProductionFamilyCode(family);
		recommended.setDealerCode(dealer);
		recommended.setEndItemModelCode(model);
		recommended.setQty(qty);

		return recommended;
	}
	
	private static BestSellingColor setBestColor(String ym, String car, String por, String family, String model,
			String color) {
		
		BestSellingColor bestColor = new BestSellingColor();
		bestColor.setPlanYearMonth(ym);
		bestColor.setCarSeries(car);
		bestColor.setPorCode(por);
		bestColor.setProductionFamilyCode(family);
		bestColor.setEndItemModelCode(model);
		bestColor.setEndItemColorCode(color);
		
		return bestColor;
	}

	
	/**
	 * read CSV
	 */
	// SPEC_OCF
	private static MonthlySpecOCFList makeSpecOcfList(String filename) {
		String data[]=new String[11];
		MonthlySpecOCFList list = new MonthlySpecOCFList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			int i = 0;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				if (i > 0 &&
						list.get(i-1).getPlanYearMonth().equals(data[0]) &&
						list.get(i-1).getCarSeries().equals(data[1]) &&
						list.get(i-1).getPorCode().equals(data[2]) &&
						list.get(i-1).getProductionFamilyCode().equals(data[3]) &&
						list.get(i-1).getEndItemModelCode().equals(data[4]) &&
						list.get(i-1).getEndItemColorCode().equals(data[5])) {
					// EIキーが同じ場合は、OCF情報のみを追加
					list.get(i-1).getOcfList().add(setOcfInfo(data[6], data[7], data[8], data[9], data[10]));					
				} else {
					// add new line
					list.add(setSpecOCF(
							data[0], data[1], data[2], data[3],
							data[4], data[5], data[6], data[7],
							data[8], data[9], data[10]));
					i++;
				}
			}
			//System.out.println(i+"a");	
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
		}	
		
		return list;
	}

	// MONTHLY_OCF
	private static MonthlyOCFList makeMonthlyOcfList(String filename) {
		String data[]=new String[9];
		MonthlyOCFList list = new MonthlyOCFList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setOCFMonthly(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], Integer.valueOf(data[7]).intValue(), Integer.valueOf(data[8]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
		}	
		
		return list;
	}
	
	// IMPORT_ORDER
	private static ProductionOrderImportList makeImportOrderList(String filename) {
		String data[]=new String[7];
		ProductionOrderImportList list = new ProductionOrderImportList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setImportOrder(
						data[0], data[1], data[2], data[3],
						data[4], data[5], Integer.valueOf(data[6]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
		}	
		
		return list;
	}
	
	// RECOMMENDED_ORDER
	private static RecommendedOrderList makeRecommendedList(String filename) {
		String data[]=new String[7];
		RecommendedOrderList list = new RecommendedOrderList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setRecommendedOrder(
						data[0], data[1], data[2], data[3],
						data[4], data[5], Integer.valueOf(data[6]).intValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
		}	
		
		return list;
	}

	// COLOR_RATIO
	private static ColorRatioList makeColorRatioList(String filename) {
		String data[]=new String[8];
		ColorRatioList list = new ColorRatioList();
		try{
			FileReader filereader = new FileReader(filename);
			BufferedReader bufferedreader = new BufferedReader(filereader);

			String line;
			while((line = bufferedreader.readLine()) != null) {
				data = line.split(",", -1);
				list.add(setColorRatio(
						data[0], data[1], data[2], data[3],
						data[4], data[5], data[6], Double.valueOf(data[7]).doubleValue()));
			}
			filereader.close();
		}catch(Exception e){
			System.out.println(filename + ":err");
		}	
		
		return list;
	}
	
}
