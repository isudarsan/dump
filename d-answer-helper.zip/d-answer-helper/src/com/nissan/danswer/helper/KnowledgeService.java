package com.nissan.danswer.helper;

import org.apache.log4j.Logger;

import org.drools.KnowledgeBase;
import org.drools.agent.KnowledgeAgent;
import org.drools.agent.KnowledgeAgentFactory;
import org.drools.agent.impl.DoNothingSystemEventListener;
import org.drools.agent.impl.PrintStreamSystemEventListener;
import org.drools.event.rule.DebugKnowledgeAgentEventListener;
import org.drools.event.rule.DefaultKnowledgeAgentEventListener;
import org.drools.io.ResourceFactory;

/**
 * KnowledgeService
 * @author SCSK
 *
 */
public class KnowledgeService {

	private KnowledgeAgent agent = null;
	
	public KnowledgeBase getKnowledgeBase(String xmlName) {
		
			// setup agent ---------------------------------------------------------
			//System.out.println(">> setup agent.");
			//Logger.getLogger(this.getClass()).info(">> BRMS setup agent start.");
			
			agent = KnowledgeAgentFactory.newKnowledgeAgent("MyAgent");
//			agent.setSystemEventListener(new PrintStreamSystemEventListener());
			agent.setSystemEventListener(new DoNothingSystemEventListener()); // log isn't printed out 
//			agent.addEventListener(new DebugKnowledgeAgentEventListener());
			agent.addEventListener(new DefaultKnowledgeAgentEventListener()); // log isn't printed out
			agent.applyChangeSet(ResourceFactory.newClassPathResource(xmlName));
			
			//System.out.println(">> setup agent end.");
			//Logger.getLogger(this.getClass()).info(">> BRMS setup agent end.");
		
			return agent.getKnowledgeBase();
	}

	public void destroy() {
		
		agent.dispose();
		agent = null;
	}
}
