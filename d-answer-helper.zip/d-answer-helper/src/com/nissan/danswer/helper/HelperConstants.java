package com.nissan.danswer.helper;

/**
 * 定数クラス
 * @author matsuda
 *
 */
public final class HelperConstants {
	
	/** Fire limit count (common) */
	public static int FIRE_LIMIT_COMMON = 1000000;
	
	/** Fire limit count (each rule) below values are temporary */
	public static int FIRE_LIMIT_EI_BREAKDOWN = 5000000; 
	public static int FIRE_LIMIT_OCF_SLOTTING = 5000000; 
	public static int FIRE_LIMIT_RE_ALLOCATION = 1000000;
	public static int FIRE_LIMIT_COLOR_BREAKDOWN_IMPORT = 3000000;
	public static int FIRE_LIMIT_COLOR_BREAKDOWN_NATIONAL = 1000000;
	public static int FIRE_LIMIT_INVENTORY_ALLOCATION = 1000000;
	public static int FIRE_LIMIT_PRODUCTION_SCHEDULE_CHECK = 1000000;
	public static int FIRE_LIMIT_STOCK_COVER = 7000000;
	public static int FIRE_LIMIT_DEALER_ALLOCATION = 1000000;

	// Singleton
	private HelperConstants() {}
}
