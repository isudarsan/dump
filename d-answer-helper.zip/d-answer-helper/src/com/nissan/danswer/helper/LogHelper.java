package com.nissan.danswer.helper;

import org.apache.log4j.Logger;
import org.drools.spi.KnowledgeHelper;

/**
 * Fuctions for use in DRL rules
 * 
 * @author matsuda
 *
 */
public class LogHelper {

	/**
	 * Log a debug message from a rule, using the rule’s package and name as the
	 * Log4J category.
	 */
	public static void debug(final KnowledgeHelper drools, final String message, final Object... parameters) {

		final String category = drools.getRule().getPackageName() + "." + drools.getRule().getName();

		final String formattedMessage = String.format(message, parameters);
		// Logger.getLogger(category).debug(formattedMessage);
		System.out.println(category + " " + formattedMessage);
	}

	/**
	 * Log a debug message from a rule, using the rule’s package and name as the
	 * Log4J category.
	 */
	public static void info(final KnowledgeHelper drools, final String message, final Object... parameters) {

		final String category = drools.getRule().getPackageName() + "." + drools.getRule().getName();

		final String formattedMessage = String.format(message, parameters);
		//Logger.getLogger(category).info(formattedMessage);
		System.out.println(category + " " + formattedMessage);
	}

	/**
	 * Log a error message from a rule, using the rule’s package and name as the
	 * Log4J category.
	 */
	public static void error(final KnowledgeHelper drools, final String message, final Object... parameters) {

		final String category = drools.getRule().getPackageName() + "." + drools.getRule().getName();

		final String formattedMessage = String.format(message, parameters);
		//Logger.getLogger(category).error(formattedMessage);
		System.out.println(category + " " + formattedMessage);
	}
}
