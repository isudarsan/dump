import 'package:flutter/material.dart';
import '../widgets/patient_registartion.dart';

class AdminDashBoardPage extends StatelessWidget {
  Future navigateToPatientRegistrationPage(context) async {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => PatientRegistrationPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            Container(
              child: RaisedButton(
                color: Colors.blue,
                child: Text(
                  'Patient Registration',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  navigateToPatientRegistrationPage(context);
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
