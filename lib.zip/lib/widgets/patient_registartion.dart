import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../domain/patient_registration.dart';

class PatientRegistrationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Patient Registration'),
      ),
      body: _PatientRegistrationWidget(),
    );
  }
}

class _PatientRegistrationWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _PatientRegistrationState();
  }
}

class _PatientRegistrationState extends State<_PatientRegistrationWidget> {
  List<String> _genders = <String>['', 'Male', 'Female'];
  List<String> _maritalStatusList = <String>['', 'Married', 'Un Married'];
  List<String> _idproofTypes = <String>['', 'Aadhar', 'PAN', 'Driving Licence'];

  String _idproofType = '';
  String _maritalStatus = '';
  String _gender = '';

  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  final TextEditingController _controller = new TextEditingController();
  PatientRegistration _patientRegistration = PatientRegistration();

  Future _chooseDate(BuildContext context, String initialDateString) async {
    var now = DateTime.now();
    var initialDate = _convertToDate(initialDateString) ?? now;
    initialDate = (initialDate.year >= 1900 && initialDate.isBefore(now)
        ? initialDate
        : now);

    var result = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: new DateTime(1900),
        lastDate: new DateTime.now());

    if (result == null) return;

    setState(() {
      _controller.text = new DateFormat.yMd().format(result);
    });
  }

  DateTime _convertToDate(String input) {
    try {
      var d = new DateFormat.yMd().parseStrict(input);
      return d;
    } catch (e) {
      return null;
    }
  }

  void _submitForm() {
    final FormState form = _formKey.currentState;
    form.save();

    print(_patientRegistration.firstName);
    print(_patientRegistration.lastName);
    print(_patientRegistration.gender);
    print(_patientRegistration.maritalStatus);
    print(_patientRegistration.idProofType);
    print(_patientRegistration.idProofNumber);
    print(_patientRegistration.mobile);
    print(_patientRegistration.pinCode);
    print(_patientRegistration.address);
    print(_patientRegistration.dateofBirth);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Form(
          key: _formKey,
          autovalidate: true,
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: <Widget>[
                TextFormField(
                    decoration: InputDecoration(
                        labelText: 'First Name',
                        hintText: 'Enter First Name',
                        icon: Icon(Icons.person)),
                    validator: (val) =>
                        val.isEmpty ? 'First Name is required' : null,
                    onSaved: (val) {
                      setState(() {
                        _patientRegistration.firstName = val;
                      });
                    }),
                TextFormField(
                    decoration: InputDecoration(
                        labelText: 'Last Name',
                        hintText: 'Enter Last Name',
                        icon: Icon(Icons.person)),
                    validator: (val) =>
                        val.isEmpty ? 'Last Name is required' : null,
                    onSaved: (val) {
                      setState(() {
                        _patientRegistration.lastName = val;
                      });
                    }),
                Row(children: <Widget>[
                  Expanded(
                      child: TextFormField(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.calendar_today),
                            hintText: 'Enter Date of Birth',
                            labelText: 'Date of Birth',
                          ),
                          controller: _controller,
                          keyboardType: TextInputType.datetime,
                          onSaved: (val) {
                            setState(() {
                              _patientRegistration.dateofBirth =
                                  _convertToDate(val);
                            });
                          })),
                  IconButton(
                    icon: Icon(Icons.more_horiz),
                    tooltip: 'Choose Date',
                    onPressed: (() {
                      _chooseDate(context, _controller.text);
                    }),
                  )
                ]),
                FormField<String>(
                  builder: (FormFieldState state) {
                    return InputDecorator(
                      decoration: InputDecoration(
                          icon: Icon(Icons.grade), labelText: 'Gender'),
                      isEmpty: _gender == '',
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton(
                          value: _gender,
                          isDense: true,
                          onChanged: (String newValue) {
                            setState(() {
                              _patientRegistration.gender = newValue;
                              _gender = newValue;
                              state.didChange(newValue);
                            });
                          },
                          items: _genders.map((String value) {
                            return DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                ),
                FormField<String>(
                  builder: (FormFieldState state) {
                    return InputDecorator(
                      decoration: InputDecoration(
                          icon: Icon(Icons.person_outline),
                          labelText: 'Marital Status'),
                      isEmpty: _maritalStatus == '',
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton(
                          value: _maritalStatus,
                          isDense: true,
                          onChanged: (String newValue) {
                            setState(() {
                              _patientRegistration.maritalStatus = newValue;
                              _maritalStatus = newValue;
                              state.didChange(newValue);
                            });
                          },
                          items: _maritalStatusList.map((String value) {
                            return DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                ),
                FormField<String>(
                  builder: (FormFieldState state) {
                    return InputDecorator(
                      decoration: InputDecoration(
                          icon: Icon(Icons.assignment_ind),
                          labelText: 'ID Proof Type'),
                      isEmpty: _idproofType == '',
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton(
                          value: _idproofType,
                          isDense: true,
                          onChanged: (String newValue) {
                            setState(() {
                              _patientRegistration.idProofType = newValue;
                              _idproofType = newValue;
                              state.didChange(newValue);
                            });
                          },
                          items: _idproofTypes.map((String value) {
                            return DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                ),
                TextFormField(
                    decoration: InputDecoration(
                        labelText: 'ID Proof Number',
                        hintText: 'Enter ID Proof Number',
                        icon: Icon(Icons.person)),
                    onSaved: (val) {
                      setState(() {
                        _patientRegistration.idProofNumber = val;
                      });
                    }),
                TextFormField(
                    keyboardType: TextInputType.phone,
                    inputFormatters: [
                      WhitelistingTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(10)
                    ],
                    decoration: InputDecoration(
                        labelText: 'Mobile Number',
                        hintText: 'Enter Mobile Number',
                        icon: Icon(Icons.phone)),
                    onSaved: (val) {
                      setState(() {
                        _patientRegistration.mobile = val;
                      });
                    }),
                TextFormField(
                    maxLines: 3,
                    decoration: InputDecoration(
                        labelText: 'Address',
                        hintText: 'Enter Address',
                        icon: Icon(Icons.location_city)),
                    onSaved: (val) {
                      setState(() {
                        _patientRegistration.address = val;
                      });
                    }),
                TextFormField(
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      WhitelistingTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(6)
                    ],
                    decoration: InputDecoration(
                        labelText: 'Pin Code',
                        hintText: 'Enter Pin Code',
                        icon: Icon(Icons.fiber_pin)),
                    onSaved: (val) {
                      setState(() {
                        _patientRegistration.pinCode = val;
                      });
                    }),
                Container(
                    padding: const EdgeInsets.only(left: 40.0, top: 20.0),
                    child: RaisedButton(
                      color: Colors.blue,
                      child: const Text(
                        'Register',
                        style: TextStyle(color: Colors.white),
                      ),
                      onPressed: () {
                        _submitForm();
                      },
                    )),
              ],
            ),
          ),
        ));
  }
}
