import 'package:flutter/material.dart';
import '../widgets/admin_dashboard_page.dart';

class LoginPage extends StatelessWidget {
  Future navigateToAdminDashBoard(context) async {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => AdminDashBoardPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        RaisedButton(
          color: Colors.blue,
          child: Text(
            'Login',
            style: TextStyle(color: Colors.white),
          ),
          onPressed: () {
            navigateToAdminDashBoard(context);
          },
        )
      ],
    );
  }
}
