import 'package:flutter/material.dart';
import './widgets/login_page.dart';

//https://codingwithjoe.com/building-forms-with-flutter/
void main() {
  runApp(AppMain());
}

class AppMain extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('CareRecord'),
        ),
        body: Container(
          child: Column(
            children: <Widget>[LoginPage()],
          ),
        ),
      ),
    );
  }
}
